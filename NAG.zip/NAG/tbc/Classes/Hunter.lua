local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version
local WoWAPI = ns.WoWAPI
local IsUsableSpell = C_Spell and C_Spell.IsSpellUsable or _G.IsUsableSpell
local UnitAura = _G.UnitAura
local UnitBuff = _G.UnitBuff
local UnitDebuff = _G.UnitDebuff

-- Safe aura check to avoid missing spell errors on clients without the aura
local function AuraActiveKnown(spellId)
    if not spellId then return false end
    local name = WoWAPI.GetSpellInfo(spellId)
    if not name then return false end
    if not NAG:SpellIsKnown(spellId) then return false end
    return NAG:AuraIsActive(spellId)
end

-- Name-based aura check (fallback when ID matching fails)
local function AuraActiveByName(unit, auraName)
    unit = unit or "player"
    if not auraName then return false end

    local function scan(filter)
        local i = 1
        while true do
            local aura = UnitAura(unit, i, filter)
            if not aura then
                break
            end
            -- WoWAPI may return a table (APICompat) or multiple returns (classic)
            local name
            if type(aura) == "table" then
                name = aura.name or aura[1]
            else
                name = select(1, aura)
            end
            if name == auraName then
                return true
            end
            i = i + 1
        end
        return false
    end

    return scan("HELPFUL|PLAYER") or scan("HELPFUL")
end

local function AuraActiveByIds(unit, ids)
    unit = unit or "player"
    if not ids then return false end
    local function scan(filter)
        local i = 1
        while true do
            local aura = UnitAura(unit, i, filter)
            if not aura then break end
            local spellId
            if type(aura) == "table" then
                spellId = aura.spellId or aura.id or aura[10]
            else
                spellId = select(10, aura)
            end
            if spellId then
                for _, id in ipairs(ids) do
                    if spellId == id then
                        return true
                    end
                end
            end
            i = i + 1
        end
        return false
    end
    return scan("HELPFUL|PLAYER") or scan("HELPFUL")
end

local function KillCommandUsable()
    if not IsUsableSpell then
        return false
    end
    local usable = select(1, IsUsableSpell(34026))
    if usable == nil then
        return false
    end
    return usable == true or usable == 1
end

-- Expose Kill Command usability helper to rotation-string sandbox
_G.KillCommandUsable = KillCommandUsable

-- Aspect rank lists (rank-agnostic checks to avoid re-suggesting active aspects)
local HAWK_IDS = {13165, 14318, 14319, 14320, 14321, 14322, 25296, 27044}
local VIPER_IDS = {34074}
local CHEETAH_IDS = {5118}
local PACK_IDS = {13159}

local function AuraActiveAny(ids)
    for _, id in ipairs(ids) do
        local name = WoWAPI.GetSpellInfo(id)
        if name and NAG:AuraIsActive(id) then
            return true
        end
    end
    return false
end

local function AspectHawkActive()
    if AuraActiveAny(HAWK_IDS) then return true end
    if AuraActiveByIds("player", HAWK_IDS) then return true end
    local hawkName = select(1, WoWAPI.GetSpellInfo(27044))
    return AuraActiveByName("player", hawkName)
end

local function AspectViperActive()
    if AuraActiveAny(VIPER_IDS) then return true end
    if AuraActiveByIds("player", VIPER_IDS) then return true end
    local viperName = select(1, WoWAPI.GetSpellInfo(34074))
    return AuraActiveByName("player", viperName)
end

local function AspectCheetahActive() return AuraActiveAny(CHEETAH_IDS) end
local function AspectPackActive() return AuraActiveAny(PACK_IDS) end

-- Expose for rotation-string execution (loadstring runs in global env)
_G.AuraActiveKnown = AuraActiveKnown
_G.AspectHawkActive = AspectHawkActive
_G.AspectViperActive = AspectViperActive
_G.AspectCheetahActive = AspectCheetahActive
_G.AspectPackActive = AspectPackActive

-- ============================ TBC HUNTER COMMON FUNCTIONS ============================
--- Updates the stable pets information for the Hunter class.
--- TBC only has 1 active pet slot, so this is a simple stub.
--- @function ns.HUNTER_UpdateStablePets
function ns.HUNTER_UpdateStablePets()
    -- TBC Hunter only has 1 pet slot (Call Pet = spell ID 883)
    -- No multiple pet slots like later expansions
end

local defaults = ns.InitializeClassDefaults()

-- TBC Hunter spec spell locations
defaults.class.specSpellLocations = {
    [1] = { -- Beast Mastery
        -- ABOVE spells (Aspects & Debuffs)
        [27044] = NAG.SPELL_POSITIONS.ABOVE,   -- Aspect of the Hawk (Rank 8)
        [34074] = NAG.SPELL_POSITIONS.ABOVE,   -- Aspect of the Viper
        [5118] = NAG.SPELL_POSITIONS.ABOVE,    -- Aspect of the Cheetah
        [13159] = NAG.SPELL_POSITIONS.ABOVE,   -- Aspect of the Pack
        [14325] = NAG.SPELL_POSITIONS.ABOVE,   -- Hunter's Mark (Rank 4)
        [3043] = NAG.SPELL_POSITIONS.ABOVE,    -- Scorpid Sting

        -- LEFT spells (Cooldowns)
        [19574] = NAG.SPELL_POSITIONS.LEFT,    -- Bestial Wrath
        [3045] = NAG.SPELL_POSITIONS.LEFT,     -- Rapid Fire

        -- RIGHT spells (Melee weaving)
        [27014] = NAG.SPELL_POSITIONS.RIGHT,   -- Raptor Strike (Rank 9)

    },
    [2] = { -- Marksmanship
        -- ABOVE spells (Aspects & Debuffs)
        [27044] = NAG.SPELL_POSITIONS.ABOVE,   -- Aspect of the Hawk (Rank 8)
        [34074] = NAG.SPELL_POSITIONS.ABOVE,   -- Aspect of the Viper
        [5118] = NAG.SPELL_POSITIONS.ABOVE,    -- Aspect of the Cheetah
        [13159] = NAG.SPELL_POSITIONS.ABOVE,   -- Aspect of the Pack
        [14325] = NAG.SPELL_POSITIONS.ABOVE,   -- Hunter's Mark (Rank 4)
        [3043] = NAG.SPELL_POSITIONS.ABOVE,    -- Scorpid Sting

        -- LEFT spells (Cooldowns)
        [3045] = NAG.SPELL_POSITIONS.LEFT,     -- Rapid Fire
        [27065] = NAG.SPELL_POSITIONS.LEFT,    -- Aimed Shot (Rank 7)
        [23989] = NAG.SPELL_POSITIONS.LEFT,    -- Readiness

        -- RIGHT spells (Melee weaving)
        [27014] = NAG.SPELL_POSITIONS.RIGHT,   -- Raptor Strike (Rank 9)

        -- AOE spells
        [27021] = NAG.SPELL_POSITIONS.AOE,     -- Multi-Shot (Rank 6)
    },
    [3] = { -- Survival
        -- ABOVE spells (Aspects & Debuffs)
        [27044] = NAG.SPELL_POSITIONS.ABOVE,   -- Aspect of the Hawk (Rank 8)
        [34074] = NAG.SPELL_POSITIONS.ABOVE,   -- Aspect of the Viper
        [5118] = NAG.SPELL_POSITIONS.ABOVE,    -- Aspect of the Cheetah
        [13159] = NAG.SPELL_POSITIONS.ABOVE,   -- Aspect of the Pack
        [14325] = NAG.SPELL_POSITIONS.ABOVE,   -- Hunter's Mark (Rank 4)
        [3043] = NAG.SPELL_POSITIONS.ABOVE,    -- Scorpid Sting

        -- LEFT spells (Cooldowns)
        [3045] = NAG.SPELL_POSITIONS.LEFT,     -- Rapid Fire
        [23989] = NAG.SPELL_POSITIONS.LEFT,    -- Readiness

        -- RIGHT spells (Melee weaving)
        [27014] = NAG.SPELL_POSITIONS.RIGHT,   -- Raptor Strike (Rank 9)

        -- AOE spells
        [27021] = NAG.SPELL_POSITIONS.AOE,     -- Multi-Shot (Rank 6)
    },
}

if UnitClassBase('player') ~= "HUNTER" then return end

-- ============================ BEAST MASTERY ROTATION ============================
local beastMasteryRotation = {
    -- Core identification
    name = "Beast Mastery",
    specIndex = 1,
    class = "HUNTER",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,

    prePull = {
        { time = -3.0, action = "NAG:Cast(14325)" },  -- Hunter's Mark (Rank 4)
        { time = -1.5, action = "NAG:Cast(27044)" },  -- Aspect of the Hawk (Rank 8)
    },

    lastModified = "12/10/2025",
    -- TBC uses function-based execution (validation skipped for TBC)
    -- Aspects first, then Kill Command > Bestial Wrath > Steady Shot
    rotationString = [[
-- BM Hunter (TBC) - test rotation for SS/MS/AR timing with Auto Shot warm-up + queue-zone rules.
-- Rules encoded:
-- 1) Always start/warm-up Auto Shot first (if not auto-shooting, prompt Auto Shot and do nothing else).
-- 2) Simple priority: Auto > SS (queue in wind-up / cast if safe) > MS (safe) > AR (safe) > SS HOLD.
--    Note: advanced helpers (extra-gap, while-casting predictors) are kept but not used right now.

-- 0) Ensure Auto Shot is ON (blocks the rest until true)
NAG:HunterUpdateAutoShotState()
or NAG:HunterEnsureAutoShot()
-- Pet check: warn if pet is not attacking while in combat
or (NAG:PetIsActive() and NAG:InCombat() and NAG:UnitExists("target")
    and ((not NAG:UnitExists("pettarget")) or (not NAG:InCombat("pet"))))
    and NAG:ShowCustomOverlay("Pet Not Attacking")
-- NOTE: temporary debug line to confirm HunterSafeToCast is actually being evaluated in-game.
-- It will never stop the APL (ends with `and false`), but should trigger prints if HunterSafeToCast runs.
--or (NAG:HunterIsAutoShooting() and NAG:HunterSafeToCast(34120) and false)


-- Simple 6-step APL
-- 1) Auto Shot (handled above)
-- 2) SS in wind-up (queues) if not already queued
or (NAG:HunterInWarmUp() and (not NAG:HunterSSQueued()) and NAG:Cast(34120))
-- 3) SS if safe-to-finish before Auto (and not queued)
or (NAG:HunterSafeToCast(34120) and (not NAG:HunterInWarmUp()) and (not NAG:HunterSSQueued()) and NAG:Cast(34120))
-- 4) MS if safe (and only as filler while we're already in a GCD/cast recovery window)
or (not NAG:HunterInWarmUp()) and not(NAG:HunterMSQueued()) and NAG:HunterSafeToCast(27021) and NAG:IsGCDOrCastingRecently(0.200, 34120) and NAG:Cast(27021)
-- 4) AR if safe, MS not ready, and allowed
or  not(NAG:SpellIsReady(27021)) and (not NAG:HunterInWarmUp()) and NAG:HunterSafeToCast(27019) and NAG:IsGCDOrCastingRecently(0.200, 34120) and NAG:Cast(27019)

-- 6) HOLD: show Steady swipe until it's time to start spamming Steady (wind-up start)
or NAG:HunterSteadyHold()
]],
    aplProto = {},  -- Empty proto to skip schema-based parsing

    -- Tracked IDs for optimization (TBC max ranks)
    spells = {
        75,     -- Auto Shot (all hunters)
        14325,  -- Hunter's Mark (Rank 4)
        27044,  -- Aspect of the Hawk (Rank 8)
        34074,  -- Aspect of the Viper
        5118,   -- Aspect of the Cheetah
        13159,  -- Aspect of the Pack
        3043,   -- Scorpid Sting
        27019,  -- Arcane Shot (Rank 9)
        27021,  -- Multi-Shot (Rank 6)
        34120,  -- Steady Shot
        34026,  -- Kill Command
        19574,  -- Bestial Wrath
        3045,   -- Rapid Fire
        27014,  -- Raptor Strike (Rank 9)
    },
    items = {},
    auras = {},
    runes = {},

    -- Optional metadata
    guide = [[
Beast Mastery Hunter Rotation Guide (TBC)

Core Mechanics:
- Pet is your primary damage source. Best pet: Ravager.
- Kill Command procs when your pet crits - use immediately!
- Auto Shot timing is CRITICAL - never clip autos with casts.
- Melee Weaving: Use Raptor Strike between ranged attacks for extra DPS.

Rotation Priority (Single Target):
1. Aspect of the Hawk (switch to Viper when low mana)
2. Hunter's Mark (if assigned)
3. Scorpid Sting (if assigned for raid debuff)
4. Rapid Fire + Bestial Wrath + on-use effects
5. Kill Command (when it procs)
6. Multi-Shot OR Steady Shot + Auto Shot (don't clip autos)
7. Raptor Strike (melee weave for extra damage)

Cooldowns:
- Bestial Wrath: 2min CD. Major pet damage boost + immunity.
- Rapid Fire: 5min CD. Haste buff. Sync with Bestial Wrath.

Mana Management:
- Aspect of the Viper: Switch below 20% mana.
- Aspect of the Hawk: Switch back above 50% mana.

Pet:
- Best pet: Ravager (highest DPS with Gore ability)
- Keep pet alive and on target at all times
- Hunter Weave Bar: enable in options to see French/melee cues
    ]],
    author = "Smufrik",
}

-- ============================ MARKSMANSHIP ROTATION ============================
local marksmanshipRotation = {
    -- Core identification
    name = "Marksmanship",
    specIndex = 2,
    class = "HUNTER",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,

    prePull = {
        { time = -3.0, action = "NAG:Cast(14325)" },  -- Hunter's Mark (Rank 4)
        { time = -2.5, action = "NAG:Cast(27065)" },  -- Aimed Shot (Rank 7) pre-cast
        { time = -1.0, action = "NAG:Cast(27044)" },  -- Aspect of the Hawk (Rank 8)
    },

    lastModified = "12/10/2025",
    -- TBC uses function-based execution - bypass Proto AST conversion
    -- Aspects first, then Rapid Fire > Aimed Shot > Steady Shot > Arcane Shot
    rotationString = [[
-- Aspects - Priority 0 (similar to MoP logic)
(NAG:GetClassSetting('recommendAspects', true) and (
    -- Out of combat + moving: suggest Pack (group) or Cheetah (solo)
    (NAG:UnitIsMoving() and (not NAG:InCombat()) and (
        (NAG:GetNumGroupMembers() > 0 and NAG:SpellIsKnown(13159) and not AspectPackActive() and NAG:Cast(13159, nil, NAG.SPELL_POSITIONS.ABOVE))
        or (NAG:GetNumGroupMembers() == 0 and NAG:SpellIsKnown(5118) and not AspectCheetahActive() and NAG:Cast(5118, nil, NAG.SPELL_POSITIONS.ABOVE))
    ))
    -- In combat or not moving: manage Hawk/Viper based on mana
    or ((not NAG:UnitIsMoving() or NAG:InCombat()) and (
        -- Low mana (<30%): suggest Viper if not active
        (NAG:CurrentManaPercent() < 0.30 and NAG:SpellIsKnown(34074) and not AspectViperActive() and NAG:Cast(34074, nil, NAG.SPELL_POSITIONS.ABOVE))
        -- Good mana (>70%): suggest Hawk if not active and Viper is active (switch back)
        or (NAG:CurrentManaPercent() > 0.70 and AspectViperActive() and NAG:SpellIsKnown(27044) and not AspectHawkActive() and NAG:Cast(27044, nil, NAG.SPELL_POSITIONS.ABOVE))
        -- No aspect active: suggest Hawk
        or (not AspectHawkActive() and not AspectViperActive() and NAG:SpellIsKnown(27044) and NAG:Cast(27044, nil, NAG.SPELL_POSITIONS.ABOVE))
    ))
))

-- Pet check: warn if pet is not attacking while in combat
or (NAG:PetIsActive() and NAG:InCombat() and NAG:UnitExists("target")
    and ((not NAG:UnitExists("pettarget")) or (not NAG:InCombat("pet"))))
    and NAG:ShowCustomOverlay("Pet Not Attacking")

-- Cooldowns (LEFT position) - use when available
or (NAG:SpellIsKnown(3045) and NAG:SpellIsReady(3045) and NAG:Cast(3045, nil, NAG.SPELL_POSITIONS.LEFT))    -- Rapid Fire (5min CD)
or (NAG:SpellIsKnown(23989) and NAG:SpellIsReady(23989) and NAG:Cast(23989, nil, NAG.SPELL_POSITIONS.LEFT)) -- Readiness (5min CD, resets CDs)
or (NAG:SpellIsKnown(27065) and NAG:SpellIsReady(27065) and NAG:Cast(27065, nil, NAG.SPELL_POSITIONS.LEFT)) -- Aimed Shot (main nuke)

-- Main rotation
-- Kill Command only when proc/usable and ready
or (KillCommandUsable() and NAG:SpellIsReady(34026) and NAG:Cast(34026))
-- French weave (slow, no major haste)
or (NAG.HunterFrenchMultiReady and NAG:HunterFrenchMultiReady()) and NAG:Cast(27021, nil, NAG.SPELL_POSITIONS.AOE)
or (NAG.HunterFrenchArcaneReady and NAG:HunterFrenchArcaneReady()) and NAG:Cast(27019)

-- General Multi-Shot for cleave only (single-target handled by French weave if active)
or (NAG:SpellIsReady(27021) and NAG:NumberTargets() >= 2) and NAG:Cast(27021, nil, NAG.SPELL_POSITIONS.AOE)

-- Melee weaving
or (NAG.HunterMeleeReady and NAG:HunterMeleeReady()) and NAG:Cast(27014, nil, NAG.SPELL_POSITIONS.RIGHT)

-- Avoid clipping Steady during very fast autos
or ((NAG.HunterWaitForAuto and NAG:HunterWaitForAuto() > 0) and NAG:Wait(NAG:HunterWaitForAuto()))

-- Steady filler with safety
or (NAG.HunterSafeSteady and NAG:HunterSafeSteady()) and NAG:Cast(34120)
or NAG:Cast(34120)
or NAG:Cast(27019)  -- Arcane Shot (fallback)
]],
    aplProto = {},  -- Empty proto to skip schema-based parsing

    -- Tracked IDs for optimization (TBC max ranks)
    spells = {
        14325,  -- Hunter's Mark (Rank 4)
        27044,  -- Aspect of the Hawk (Rank 8)
        34074,  -- Aspect of the Viper
        5118,   -- Aspect of the Cheetah
        13159,  -- Aspect of the Pack
        3043,   -- Scorpid Sting
        27065,  -- Aimed Shot (Rank 7)
        27019,  -- Arcane Shot (Rank 9)
        27021,  -- Multi-Shot (Rank 6)
        34120,  -- Steady Shot
        34026,  -- Kill Command
        3045,   -- Rapid Fire
        23989,  -- Readiness
        27014,  -- Raptor Strike (Rank 9)
    },
    items = {},
    auras = {},
    runes = {},

    -- Optional metadata
    guide = [[
Marksmanship Hunter Rotation Guide (TBC)

Core Mechanics:
- Trueshot Aura provides raid-wide AP buff.
- Aimed Shot for high burst damage at pull and during fight.
- Auto Shot timing is CRITICAL - never clip autos with casts.
- Melee Weaving: Use Raptor Strike between ranged attacks.

Rotation Priority (Single Target):
1. Aspect of the Hawk (switch to Viper when low mana)
2. Hunter's Mark (if assigned)
3. Misdirection on tank (threat management)
4. Aimed Shot at pull
5. Rapid Fire + on-use effects
6. Kill Command (when it procs)
7. Steady Shot + Auto Shot in 1:1 rotation (don't clip autos)
8. Multi-Shot (weave in when available)
9. Raptor Strike (melee weave)

Cooldowns:
- Rapid Fire: 5min CD. Haste buff.
- Readiness: 5min CD. Resets all Hunter cooldowns - use strategically!

Mana Management:
- Aspect of the Viper: Switch below 20% mana.
- Aspect of the Hawk: Switch back above 50% mana.

Pet:
- Best pet: Ravager (highest DPS)
- Kill Command works for all specs!
    ]],
    author = "Smufrik",
}

-- ============================ SURVIVAL ROTATION ============================
-- Note: SV Hunter in TBC is primarily a SUPPORT spec with Expose Weakness for raid utility
local survivalRotation = {
    -- Core identification
    name = "Survival",
    specIndex = 3,
    class = "HUNTER",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,

    prePull = {
        { time = -3.0, action = "NAG:Cast(14325)" },  -- Hunter's Mark (Rank 4)
        { time = -1.5, action = "NAG:Cast(27044)" },  -- Aspect of the Hawk (Rank 8)
    },

    lastModified = "12/10/2025",
    -- TBC uses function-based execution - bypass Proto AST conversion
    -- Aspects first, then Rapid Fire > Steady Shot > Arcane Shot
    -- Survival focuses on Expose Weakness uptime (passive proc on crit)
    rotationString = [[
-- Aspects - Priority 0 (similar to MoP logic)
(NAG:GetClassSetting('recommendAspects', true) and (
    -- Out of combat + moving: suggest Pack (group) or Cheetah (solo)
    (NAG:UnitIsMoving() and (not NAG:InCombat()) and (
        (NAG:GetNumGroupMembers() > 0 and NAG:SpellIsKnown(13159) and not NAG:AuraIsActive(13159) and NAG:Cast(13159, nil, NAG.SPELL_POSITIONS.ABOVE))
        or (NAG:GetNumGroupMembers() == 0 and NAG:SpellIsKnown(5118) and not NAG:AuraIsActive(5118) and NAG:Cast(5118, nil, NAG.SPELL_POSITIONS.ABOVE))
    ))
    -- In combat or not moving: manage Hawk/Viper based on mana
    or ((not NAG:UnitIsMoving() or NAG:InCombat()) and (
        -- Low mana (<30%): suggest Viper if not active
        (NAG:CurrentManaPercent() < 0.30 and NAG:SpellIsKnown(34074) and not NAG:AuraIsActive(34074) and NAG:Cast(34074, nil, NAG.SPELL_POSITIONS.ABOVE))
        -- Good mana (>70%): suggest Hawk if not active and Viper is active (switch back)
        or (NAG:CurrentManaPercent() > 0.70 and NAG:AuraIsActive(34074) and NAG:SpellIsKnown(27044) and NAG:Cast(27044, nil, NAG.SPELL_POSITIONS.ABOVE))
        -- No aspect active: suggest Hawk
        or (not NAG:AuraIsActive(27044) and not NAG:AuraIsActive(34074) and NAG:SpellIsKnown(27044) and NAG:Cast(27044, nil, NAG.SPELL_POSITIONS.ABOVE))
    ))
))

-- Pet check: warn if pet is not attacking while in combat
or (NAG:PetIsActive() and NAG:InCombat() and NAG:UnitExists("target")
    and ((not NAG:UnitExists("pettarget")) or (not NAG:InCombat("pet"))))
    and NAG:ShowCustomOverlay("Pet Not Attacking")

-- Cooldowns (LEFT position) - use when available
or (NAG:SpellIsKnown(3045) and NAG:SpellIsReady(3045) and NAG:Cast(3045, nil, NAG.SPELL_POSITIONS.LEFT))    -- Rapid Fire (5min CD)
or (NAG:SpellIsKnown(23989) and NAG:SpellIsReady(23989) and NAG:Cast(23989, nil, NAG.SPELL_POSITIONS.LEFT)) -- Readiness (5min CD, resets CDs)

-- Main rotation
-- Kill Command only when proc/usable and ready
or (KillCommandUsable() and NAG:SpellIsReady(34026) and NAG:Cast(34026))
-- French weave (slow, no major haste)
or (NAG.HunterFrenchMultiReady and NAG:HunterFrenchMultiReady()) and NAG:Cast(27021, nil, NAG.SPELL_POSITIONS.AOE)
or (NAG.HunterFrenchArcaneReady and NAG:HunterFrenchArcaneReady()) and NAG:Cast(27019)

-- General Multi-Shot for cleave only (single-target handled by French weave if active)
or (NAG:SpellIsReady(27021) and NAG:NumberTargets() >= 2) and NAG:Cast(27021, nil, NAG.SPELL_POSITIONS.AOE)

-- Melee weaving
or (NAG.HunterMeleeReady and NAG:HunterMeleeReady()) and NAG:Cast(27014, nil, NAG.SPELL_POSITIONS.RIGHT)

-- Avoid clipping Steady during very fast autos
or ((NAG.HunterWaitForAuto and NAG:HunterWaitForAuto() > 0) and NAG:Wait(NAG:HunterWaitForAuto()))

-- Steady filler with safety
or (NAG.HunterSafeSteady and NAG:HunterSafeSteady()) and NAG:Cast(34120)
or NAG:Cast(34120)
or NAG:Cast(27019)  -- Arcane Shot (fallback)
]],
    aplProto = {},  -- Empty proto to skip schema-based parsing

    -- Tracked IDs for optimization (TBC max ranks)
    spells = {
        14325,  -- Hunter's Mark (Rank 4)
        27044,  -- Aspect of the Hawk (Rank 8)
        34074,  -- Aspect of the Viper
        5118,   -- Aspect of the Cheetah
        13159,  -- Aspect of the Pack
        3043,   -- Scorpid Sting
        27019,  -- Arcane Shot (Rank 9)
        27021,  -- Multi-Shot (Rank 6)
        34120,  -- Steady Shot
        34026,  -- Kill Command
        3045,   -- Rapid Fire
        23989,  -- Readiness
        27014,  -- Raptor Strike (Rank 9)
        34503,  -- Expose Weakness (aura - procs on crit)
    },
    items = {},
    auras = {},
    runes = {},

    -- Optional metadata
    guide = [[
Survival Hunter Rotation Guide (TBC)

IMPORTANT: SV Hunter in TBC is a SUPPORT spec!
- Expose Weakness talent gives raid-wide AP buff when you crit.
- Usually 1 SV Hunter per raid for the debuff.
- SV Hunter typically handles Hunter's Mark duty.

Core Mechanics:
- Expose Weakness: Procs on YOUR crits, adds 25% of your Agility as AP to raid.
- Auto Shot timing is CRITICAL - never clip autos with casts.
- Melee Weaving: Use Raptor Strike between ranged attacks.

Rotation Priority (Single Target):
1. Aspect of the Hawk (switch to Viper when low mana)
2. Hunter's Mark (SV usually assigned this)
3. Scorpid Sting (if assigned)
4. Rapid Fire + on-use effects
5. Kill Command (when it procs)
6. Multi-Shot OR Steady Shot + Auto Shot (don't clip autos)
7. Raptor Strike (melee weave)

Cooldowns:
- Rapid Fire: 5min CD. Haste buff.
- Readiness: 5min CD. Resets all Hunter cooldowns.

Mana Management:
- Aspect of the Viper: Switch below 20% mana.
- Aspect of the Hawk: Switch back above 50% mana.

Raid Utility:
- Expose Weakness: 25% of your Agility as AP to entire raid (7 sec duration)
- Keep critting to maintain high uptime on Expose Weakness!
- Hunter's Mark: Usually SV Hunter's responsibility

Pet:
- Best pet: Ravager (highest DPS)
    ]],
    author = "Smufrik",
}

--- @class Hunter : ClassBase
local Hunter = NAG:CreateClassModule("HUNTER", defaults)
if not Hunter then return end

function Hunter:SetupClassDefaults()
    --ns.AddRotationToDefaults(self.defaults, 1, beastMasteryRotation)  -- Beast Mastery
    --ns.AddRotationToDefaults(self.defaults, 2, marksmanshipRotation)  -- Marksmanship
    --ns.AddRotationToDefaults(self.defaults, 3, survivalRotation)  -- Survival
end

NAG.Class = Hunter

