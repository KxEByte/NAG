local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
local UnitGUID = _G.UnitGUID
local UnitIsUnit = _G.UnitIsUnit
local GetNumGroupMembers = _G.GetNumGroupMembers
local IsInRaid = _G.IsInRaid
local GetTime = _G.GetTime
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version

local defaults = ns.InitializeClassDefaults()

-- ============================ FERAL DETECTION CACHE ============================
local FERAL_FORM_ID = 768
local BEAR_FORM_ID = 5487
local DIRE_BEAR_FORM_ID = 9634
local FERAL_CONFIRM_SECONDS = 2.0 -- Require sustained Cat Form before tagging as feral
local FERAL_SCAN_INTERVAL = 2.0
local MANGLE_REFRESH_BUFFER_SECONDS = 3.0

local feralCache = {
    lastScanTime = 0,
    lastRosterKey = "",
    lastInCombat = false,
    feralPresent = false,
    guardianPresent = false,
    catFormSeenAtByGuid = {},
    bearFormSeenAtByGuid = {},
}

--- Update feral/guardian cache with a lightweight roster scan.
--- Cached and re-scanned on roster changes, combat start, or scan interval.
local function UpdateDruidGroupCache()
    local now = GetTime and GetTime() or 0
    local inCombat = NAG:InCombat() == true
    local memberCount = GetNumGroupMembers and (GetNumGroupMembers() or 0) or 0
    local inRaid = IsInRaid and IsInRaid() or false
    local rosterKey = string.format("%s:%d", inRaid and "raid" or "party", memberCount)

    if memberCount == 0 then
        feralCache.lastRosterKey = rosterKey
        feralCache.lastInCombat = inCombat
        feralCache.lastScanTime = now
        feralCache.feralPresent = false
        feralCache.guardianPresent = false
        feralCache.catFormSeenAtByGuid = {}
        feralCache.bearFormSeenAtByGuid = {}
        return
    end

    if rosterKey ~= feralCache.lastRosterKey or inCombat ~= feralCache.lastInCombat then
        feralCache.lastRosterKey = rosterKey
        feralCache.lastInCombat = inCombat
        feralCache.lastScanTime = 0
        feralCache.feralPresent = false
        feralCache.guardianPresent = false
        feralCache.catFormSeenAtByGuid = {}
        feralCache.bearFormSeenAtByGuid = {}
    end

    if now > 0 and (now - feralCache.lastScanTime) < FERAL_SCAN_INTERVAL then
        return
    end

    feralCache.lastScanTime = now
    feralCache.feralPresent = false
    feralCache.guardianPresent = false

    local function scanUnit(unit)
        if not unit or UnitIsUnit and UnitIsUnit(unit, "player") then
            return
        end
        if UnitClassBase and UnitClassBase(unit) ~= "DRUID" then
            return
        end

        local guid = UnitGUID and UnitGUID(unit) or unit
        if not guid then
            return
        end

        local hasCatForm = NAG:UnitAura(unit, FERAL_FORM_ID, "HELPFUL") ~= false
        if hasCatForm then
            local seenAt = feralCache.catFormSeenAtByGuid[guid]
            if not seenAt then
                feralCache.catFormSeenAtByGuid[guid] = now
            elseif (now - seenAt) >= FERAL_CONFIRM_SECONDS then
                feralCache.feralPresent = true
            end
        else
            feralCache.catFormSeenAtByGuid[guid] = nil
        end

        local hasBearForm = (NAG:UnitAura(unit, DIRE_BEAR_FORM_ID, "HELPFUL") ~= false)
            or (NAG:UnitAura(unit, BEAR_FORM_ID, "HELPFUL") ~= false)
        if hasBearForm then
            local seenAt = feralCache.bearFormSeenAtByGuid[guid]
            if not seenAt then
                feralCache.bearFormSeenAtByGuid[guid] = now
            elseif (now - seenAt) >= FERAL_CONFIRM_SECONDS then
                feralCache.guardianPresent = true
            end
        else
            feralCache.bearFormSeenAtByGuid[guid] = nil
        end
    end

    if inRaid then
        for i = 1, memberCount do
            scanUnit("raid" .. i)
            if feralCache.feralPresent and feralCache.guardianPresent then
                break
            end
        end
    else
        for i = 1, 4 do
            if memberCount == 0 then
                break
            end
            scanUnit("party" .. i)
            if feralCache.feralPresent and feralCache.guardianPresent then
                break
            end
        end
    end
end

--- Determine if another druid in the group/raid is actively feral (Cat Form sustained).
--- @return boolean True if a feral druid is detected, false otherwise
local function HasFeralDruidInGroup()
    UpdateDruidGroupCache()
    return feralCache.feralPresent
end

--- Determine if another druid in the group/raid is actively in Bear Form (sustained).
--- @return boolean True if a guardian druid is detected, false otherwise
local function HasGuardianDruidInGroup()
    UpdateDruidGroupCache()
    return feralCache.guardianPresent
end

--- Should refresh Mangle early to protect a feral's bleed damage.
--- Exposed as NAG method for use in rotation strings.
--- @return boolean
function NAG:ShouldRefreshMangleForFeral()
    UpdateDruidGroupCache()
    return feralCache.feralPresent
end

--- Should show Mangle in BELOW position for feral DPS.
--- Only when a guardian druid is present and another feral is detected.
--- @return boolean
local function ShouldShowMangleBelowForFeral()
    return HasGuardianDruidInGroup() or HasFeralDruidInGroup()
end

--- Get the display position for Feral Mangle based on group composition.
--- @return string
function NAG:GetFeralManglePosition()
    if ShouldShowMangleBelowForFeral() then
        return NAG.SPELL_POSITIONS.BELOW
    end
    return NAG.SPELL_POSITIONS.PRIMARY
end

--- Determine whether Feral should cast Mangle and where to show it.
--- Priority-style rules are based on WoWSims TBC feral rotation logic.
--- @return boolean shouldMangle True if Mangle should be cast
--- @return string|nil position Spell position for display when true
function NAG:ShouldMangle()
    if self:RemainingTime() < 12 then
        return false
    end

    local timeToTick = self:TimeToEnergyTickWithGCD()
    local energy = self:CurrentEnergyAtGCD()
    local mangleCost = self:IsKnownTierset(38447) and 35 or 40
    local manglePosition = self:GetFeralManglePosition()
    local comboPoints = self:CurrentComboPoints()

    if comboPoints >= 5 then
        if not self:DotIsActive(1079) or (self:DotRemainingTime(1079) <= 0.5) then
            return false
        end
    end

    local ripDue = (comboPoints >= 4) and
        (not self:DotIsActive(1079) or (self:DotRemainingTime(1079) <= timeToTick))

    -- Mangle down and Rip isn't due
    if (not self:DotIsActiveGlobal("target", 33876)) and (not ripDue) then
        return true, manglePosition
    end

    -- Mangle will drop before next energy tick and Rip isn't due
    if self:DotIsActiveGlobal("target", 33876) and (self:DotRemainingTime(33876) <= timeToTick) and (not ripDue) then
        return true, manglePosition
    end

    -- Mangle trick window (energy band depends on 2p T6)
    if self:IsKnownTierset(38447) then
        if (timeToTick <= 1.0) and (energy >= 50) and (energy < 57) then
            return true, self.SPELL_POSITIONS.PRIMARY
        end
    elseif (timeToTick <= 1.0) and (energy >= 60) and (energy < 62) then
        return true, self.SPELL_POSITIONS.PRIMARY
    end

    -- Enough energy for Mangle but not enough time to Shred before next tick
    if (energy >= mangleCost) and (energy < 42) and (timeToTick <= 1.0) then
        return true, self.SPELL_POSITIONS.PRIMARY
    end

    -- Can't Shred because we're tanking the target
    if self:UnitIsPrimaryTarget() and (energy >= mangleCost) then
        return true, self.SPELL_POSITIONS.PRIMARY
    end

    return false
end

function NAG:ManglePosition()
    local _, pos = NAG:ShouldMangle()
    return pos
end

--- Cast the Cat Form placeholder and show a Powershift overlay.
--- @return boolean True if placeholder was triggered, false otherwise
function NAG:CastPowershiftPlaceholder()
    local casted = self:CastPlaceholder(768)
    if casted then
        self:ShowCustomOverlay("Powershift")
    end
    return casted
end

--- Cast Mangle if rotation rules say we should.
--- @return boolean True if Mangle was triggered, false otherwise
function NAG:CastMangleIfNeeded()
    local shouldMangle, position = self:ShouldMangle()
    if shouldMangle then
        return self:Cast(33876, nil, position)
    end
    return false
end

-- TBC Druid spec spell locations
-- Note: TBC Druid uses indices 1, 2, 4 (index 3 is duplicate Feral in SpecializationCompat)
defaults.class.specSpellLocations = {
    [1] = { -- Balance
        -- ABOVE spells (Buffs, maintenance)
        [24858] = NAG.SPELL_POSITIONS.ABOVE,    -- Moonkin Form (maintain)

        -- BELOW spells (DoTs that should expire before reapplying)
        [8921] = NAG.SPELL_POSITIONS.BELOW,     -- Moonfire

        -- LEFT spells (Cooldowns)
        [33831] = NAG.SPELL_POSITIONS.LEFT,     -- Force of Nature

        -- RIGHT spells (Optional raid utility)
        [770] = NAG.SPELL_POSITIONS.RIGHT,      -- Faerie Fire (optional, melee group utility)
        [5570] = NAG.SPELL_POSITIONS.RIGHT,     -- Insect Swarm (optional, higher-level targets)

        -- AOE spells
        [16914] = NAG.SPELL_POSITIONS.AOE,      -- Hurricane

        -- PRIMARY spells (default, not explicitly set)
        -- Starfire (26986) - main filler
    },
    [2] = { -- Feral Combat (DPS)
        -- ABOVE spells (Buffs, maintenance, forms)
		--[16864] = NAG.SPELL_POSITIONS.ABOVE,     -- Omen of Clarity (Clearcasting proc) - TBC ID: 16864
		[99] = NAG.SPELL_POSITIONS.RIGHT,        -- Demo Roar
        [16857] = NAG.SPELL_POSITIONS.RIGHT,    -- Faerie Fire (Feral) (if assigned)
		--[16979] = NAG.SPELL_POSITIONS.ABOVE,    -- charge

        -- LEFT spells (Cooldowns, procs)
        [6807] = NAG.SPELL_POSITIONS.LEFT,      -- Maul

    },
    [4] = { -- Restoration
        -- ABOVE spells (Buffs, maintenance, forms)
        [5420] = NAG.SPELL_POSITIONS.ABOVE,     -- Tree of Life (maintain)

        -- BELOW spells (HoTs on tanks - focus unit)
        [33763] = NAG.SPELL_POSITIONS.BELOW,    -- Lifebloom (maintain 3 stacks on focus)
        [774] = NAG.SPELL_POSITIONS.BELOW,      -- Rejuvenation (maintain on focus)
        [8936] = NAG.SPELL_POSITIONS.BELOW,     -- Regrowth (maintain HoT on focus)

        -- LEFT spells (Cooldowns, emergency heals)
        [16188] = NAG.SPELL_POSITIONS.LEFT,     -- Nature's Swiftness
        [18562] = NAG.SPELL_POSITIONS.LEFT,     -- Swiftmend

        -- PRIMARY spells (default, not explicitly set)
        -- Rejuvenation (26982) - spot heal raid
        -- Regrowth (26980) - filler
        -- Healing Touch (26979) - with Nature's Swiftness
    },
}

-- Class assignments for raid coordination
defaults.class.classAssignments = {
    {
        id = "faerie_fire",
        name = "Faerie Fire",
        description = "Apply armor reduction debuff on targets (conflicts with Sunder Armor/Expose Armor)",
        spellIds = {770, 778, 9749, 9907, 26993}, -- All ranks (includes Feral version)
        category = "debuff",
    },
    {
        id = "mark_of_the_wild",
        name = "Mark of the Wild",
        description = "Provide stats buff to raid (coordinate with other Druids)",
        spellIds = {1126, 5232, 6756, 5234, 8907, 9884, 9885, 26990}, -- All ranks
        category = "buff",
    },
    {
        id = "innervate",
        name = "Innervate",
        description = "Provide mana regeneration (coordinate with other healers/Druids)",
        spellIds = {29166}, -- Innervate
        category = "utility",
    },
    {
        id = "faerie_fire_feral",
        name = "Faerie Fire (Feral)",
        description = "Apply armor reduction debuff on targets (usually done by Balance Druid, conflicts with Sunder Armor/Expose Armor)",
        spellIds = {16857, 17390, 17391, 17392, 27011}, -- All ranks of Faerie Fire (Feral)
        category = "debuff",
    },
    {
        id = "demoralizing_roar",
        name = "Demoralizing Roar",
        description = "Reduce enemy attack power (usually done by Arms Warrior, coordinate with other tanks)",
        spellIds = {99, 1735, 9490, 9747, 9898, 26998}, -- All ranks
        category = "debuff",
    },
}

if UnitClassBase('player') ~= "DRUID" then return end

-- Balance Rotation
local balanceRotation = {
    -- Core identification
    name = "Balance",
    specIndex = 1,
    class = "DRUID",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    lastModified = "12/30/2025",
    rotationString = [[
    -- Maintain Moonkin Form
    (not NAG:AuraIsActiveResolved(24858)) and NAG:SpellCanCastResolved(24858) and NAG:Cast(NAG:ResolveEffectiveSpellId(24858))
    -- AoE: Hurricane on 4+ targets when you can stand still
    or (NAG:NumberTargets() >= 4 and (not NAG:UnitIsMoving())) and NAG:NotSpamCast(16914)
    or (NAG:NumberTargets() >= 4 and (not NAG:UnitIsMoving()) and NAG:SpellCanCastResolved(16914)) and NAG:Cast(NAG:ResolveEffectiveSpellId(16914))
    -- Big CD: Force of Nature (left)
    or (NAG:SpellCanCastResolved(33831)) and NAG:CastWithOverlay(NAG:ResolveEffectiveSpellId(33831), "CD", NAG.SPELL_POSITIONS.LEFT)
    -- Optional: Faerie Fire for melee groups (refresh after it expires)
    or (NAG:ShouldUseFaerieFire() and (not NAG:DotIsActiveResolved(770)) and NAG:SpellCanCastResolved(770)) and
        NAG:Cast(NAG:ResolveEffectiveSpellId(770), nil, NAG.SPELL_POSITIONS.RIGHT)
    -- Maintain Moonfire (late refresh to avoid clipping)
    or (((not NAG:DotIsActiveResolved(8921)) or (NAG:DotRemainingTimeResolved(8921) <= 2)) and NAG:SpellCanCastResolved(8921)) and NAG:Cast(NAG:ResolveEffectiveSpellId(8921))
    -- Optional: Insect Swarm when in group and target is higher level (late refresh)
    or (NAG:PlayerIsInGroup() and (UnitLevel("target") or 0) > (UnitLevel("player") or 0) and
        ((not NAG:DotIsActiveResolved(5570)) or (NAG:DotRemainingTimeResolved(5570) <= 2)) and
        NAG:SpellCanCastResolved(5570)) and
        NAG:Cast(NAG:ResolveEffectiveSpellId(5570), nil, NAG.SPELL_POSITIONS.RIGHT)
    -- Movement filler: Moonfire or Insect Swarm when moving
    or (NAG:UnitIsMoving() and NAG:SpellCanCastResolved(8921) and (not NAG:DotIsActiveResolved(8921))) and NAG:Cast(NAG:ResolveEffectiveSpellId(8921))
    or (NAG:UnitIsMoving() and NAG:SpellCanCastResolved(5570) and (not NAG:DotIsActiveResolved(5570))) and NAG:Cast(NAG:ResolveEffectiveSpellId(5570))
    -- Cast Starfire (main filler)
    or NAG:NotSpamCast(2912)
    -- If a DoT will drop before Starfire finishes (or GCD ends), refresh it first
    or (NAG:DotIsActiveResolved(8921) and (NAG:DotRemainingTimeResolved(8921) <=
        ((NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(2912)) > NAG:GCDTimeValue()) and
        NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(2912)) or NAG:GCDTimeValue())))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(8921))
    or (NAG:PlayerIsInGroup() and (UnitLevel("target") or 0) > (UnitLevel("player") or 0) and
        NAG:DotIsActiveResolved(5570) and (NAG:DotRemainingTimeResolved(5570) <=
        ((NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(2912)) > NAG:GCDTimeValue()) and
        NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(2912)) or NAG:GCDTimeValue())))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(5570), nil, NAG.SPELL_POSITIONS.RIGHT)
    or (NAG:SpellCanCastResolved(2912)) and NAG:Cast(NAG:ResolveEffectiveSpellId(2912))
    -- Cast Wrath (fast/efficient filler)
    or (NAG:SpellCanCastResolved(5176)) and NAG:Cast(NAG:ResolveEffectiveSpellId(5176))
    ]],

    -- Tracked IDs for optimization
    spells = {24858, 8921, 5570, 2912, 5176, 33831, 770, 16914},
    items = {},
    auras = {24858, 8921, 5570, 770}, -- Moonkin Form, Moonfire, Insect Swarm, Faerie Fire

    -- Optional metadata
    guide = [[
Balance Druid Rotation Guide (TBC)

Core Mechanics:
- Balance Druids are ranged DPS casters focusing on arcane and nature damage.
- Moonkin Form provides spell crit and mana cost reduction - always maintain it.
- DoTs (Moonfire, Insect Swarm) should be refreshed late or after expiration to avoid clipping ticks.
- Starfire is the primary heavy filler; Wrath is the fast/efficient filler.
- TBC does not have Eclipse or Starfall for Balance.

Rotation Priority (Single Target):
1. Maintain Moonkin Form (provides spell crit and mana cost reduction).
2. Optional: Faerie Fire when grouped with melee (raid utility; refresh after it expires).
3. Cast Force of Nature on cooldown when the target will live for the full duration.
4. Maintain Moonfire (refresh after it expires; 12s duration).
5. Optional: Insect Swarm when grouped and the target is higher level (refresh after it expires; 12s duration).
6. Cast Starfire as the primary filler when you can stand still.
7. Cast Wrath as a faster filler or when conserving mana.

AoE Rotation:
2-3 targets:
- Multi-dot Moonfire/Insect Swarm on targets that will live long enough for full ticks.
- Proceed with single target rotation (favor Starfire/Wrath between refreshes).

4+ targets:
- Cast Hurricane when you can channel safely (primary AoE).
- Use Moonfire/Insect Swarm while moving or to finish stragglers.
- Proceed with single target rotation when AoE ends.

DoT Management:
- Avoid clipping DoTs; refresh at the end of their duration.
- Moonfire: 12 second duration with an initial hit.
- Insect Swarm: 12 second duration and reduces the target's hit chance.

Mana Management:
- Moonkin Form: Provides mana cost reduction
- Balance Druids can still run low on long fights - plan Innervate usage.
- Consider downranking if mana becomes a limiting factor.

Movement:
- Starfire and Wrath require standing still.
- Moonfire and Insect Swarm are instant and can be used while moving.
- Hurricane is channeled and requires standing still.

Raid Coordination:
- Faerie Fire: usually assigned to one Balance Druid for consistency.
- Insect Swarm: may be assigned for utility (hit reduction) or skipped to save mana.
- Mark of the Wild: Coordinate with other Druids for raid-wide stats buff
- Innervate: Coordinate with other healers/Druids for mana regeneration
- Usually 1-2 Balance Druids per raid for debuff coverage and DPS
    ]],
    author = "Rakizi",
}


local bearRotationEspi = {
    -- Core identification
    name = "Feral (Tank)",
    specIndex = 2, -- Feral
    class = "DRUID",

    -- Required parameters
    default = true,
    enabled = true,
    experimental = false,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,

    lastModified = "06/01/2025",

    -- Rotation Logic
    rotationString = [[
   NAG:AuraIsActive(768) and NAG:SelectRotation("Feral (DPS)")
    -- Self buffs / solo sustain (LEFT)
    or (not NAG:AuraIsActive(9885) and not NAG:AuraIsActive(21849)) and NAG:Cast(9885, nil, NAG.SPELL_POSITIONS.LEFT)
    or ((not NAG:InCombat()) and ((NAG:AuraIsActive(9885) and (NAG:AuraRemainingTime(9885) < 120)) or (NAG:AuraIsActive(21849) and (NAG:AuraRemainingTime(21849) < 120)))) and NAG:Cast(9885, nil, NAG.SPELL_POSITIONS.LEFT)
    or ((GetNumGroupMembers() == 0) and ((not NAG:AuraIsActive(26992)) or (NAG:AuraRemainingTime(26992) < 60))) and NAG:Cast(26992, nil, NAG.SPELL_POSITIONS.LEFT)
    or ((GetNumGroupMembers() == 0) and (NAG:CurrentHealthPercent() < 0.4)) and NAG:Cast(33763, nil, NAG.SPELL_POSITIONS.LEFT)
    or ((GetNumGroupMembers() == 0) and (NAG:CurrentHealthPercent() < 0.3)) and NAG:Cast(26980, nil, NAG.SPELL_POSITIONS.LEFT)

	-- Maul
	or (NAG:CurrentRage() >= 40 and not NAG:IsQueuedResolved(6807)) and NAG:Cast(6807)

    -- Utility
	-- Maintain Demoralizing Roar if assigned
    or (not NAG:DotIsActive(99) or NAG:DotRemainingTime(99) < 5) and NAG:UnitDistance("target") <= 8 and NAG:Cast(99)
	-- Maintain fff if assigned
    or (not NAG:DotIsActive(16857)) and NAG:Cast(16857)
	-- Maintain omen
    or not(NAG:InCombat()) and (not NAG:AuraIsActive(16864)) and NAG:Cast(16864)
	-- add taunt?

	-- charge if further than 8 yards
	or (NAG:UnitDistance("target") > 8) and NAG:Cast(16979)

    -- Always be in Bear Form (9634)
    or (not NAG:AuraIsActive(9634)) and NAG:Cast(9634)

	-- lacerate(<3s remaining)
    or (NAG:DotIsActive(33745) and (NAG:DotRemainingTime(33745) < 3)) and NAG:Cast(33745)

	-- mangle (refresh early if a feral is in the group)
	or (NAG:ShouldRefreshMangleForFeral() and NAG:DotIsActiveGlobal("target", 33876) and (NAG:DotRemainingTime(33876) <= 3.0)) and NAG:Cast(33878)
	-- mangle
	or NAG:Cast(33878)

    -- lacerate(<5 stacks or <5s remaining)
    or NAG:NumberTargets(5) < 3 and (not NAG:DotIsActive(33745) or (NAG:DotNumStacks(33745) < 5 or NAG:DotRemainingTime(33745) < 5)) and NAG:Cast(33745)

    -- swipe
    or (NAG:NumberTargets(5) > 1 or (NAG:DotIsActive(33745) and NAG:DotNumStacks(33745) == 5)) and NAG:Cast(769)

    -- pooling rage placeholder with auto attack
    or NAG:CastWithSwingOverlay(6603, "Pool\nRage")
    ]],

    -- Tracked IDs
    spells = {
	6807, -- Maul
	99, --demo Roar
	16857, -- faerie fire Feral
	16979, --charge
	9634, --bear form
	33878, --mangle
	33745, --lacerate
	769, --swipe
    },
    items = {
    },
    auras = {},
    runes = {},

	author = "espi",
}


local catRotationEspi = {
    -- Core identification
    name = "Feral (DPS)",
    specIndex = 2, -- Feral
    class = "DRUID",

    -- Required parameters
    default = true,
    enabled = true,
    experimental = false,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,

    lastModified = "06/01/2025",

    -- Rotation Logic
    rotationString = [[
    NAG:AuraIsActive(9634) and NAG:SelectRotation("Feral (Tank)")
    -- Self buffs / solo sustain (LEFT)
    or (not NAG:AuraIsActive(9885) and not NAG:AuraIsActive(21849)) and NAG:Cast(9885, nil, NAG.SPELL_POSITIONS.LEFT)
    or ((not NAG:InCombat()) and ((NAG:AuraIsActive(9885) and (NAG:AuraRemainingTime(9885) < 120)) or (NAG:AuraIsActive(21849) and (NAG:AuraRemainingTime(21849) < 120)))) and NAG:Cast(9885, nil, NAG.SPELL_POSITIONS.LEFT)
    or ((GetNumGroupMembers() == 0) and ((not NAG:AuraIsActive(26992)) or (NAG:AuraRemainingTime(26992) < 60))) and NAG:Cast(26992, nil, NAG.SPELL_POSITIONS.LEFT)
    or ((GetNumGroupMembers() == 0) and (NAG:CurrentHealthPercent() < 0.4)) and NAG:Cast(33763, nil, NAG.SPELL_POSITIONS.LEFT)
    or ((GetNumGroupMembers() == 0) and (NAG:CurrentHealthPercent() < 0.3)) and NAG:Cast(26980, nil, NAG.SPELL_POSITIONS.LEFT)

	-- Maintain ff if assigned
    -- If target is far, show FF in primary position
    or ((not NAG:UnitDebuffGlobal("target", 16857)) and (NAG:UnitDistance("target") >= 10)) and
        NAG:Cast(16857, nil, NAG.SPELL_POSITIONS.PRIMARY)
    or (not  NAG:UnitDebuffGlobal("target", 16857)) and NAG:Cast(16857)
	-- Maintain omen (refresh out of combat if less than 3 minutes remaining)
    or ((not NAG:AuraIsActive(16864)) or ((not NAG:InCombat()) and (NAG:AuraRemainingTime(16864) < 180))) and NAG:Cast(16864)

    -- dash if further than 10 yards (only in Cat Form)
    or (NAG:AuraIsActive(768) and NAG:UnitDistance("target") > 10) and NAG:Cast(33357, nil, NAG.SPELL_POSITIONS.AOE)

    -- Always be in Cat Form (768)
    or (not NAG:AuraIsActive(768)) and NAG:Cast(768)

    --shred with clearcasting always (only when not tanking the target)
    or (NAG:AuraIsActive(16864) and (not NAG:UnitIsPrimaryTarget())) and NAG:Cast(5221)

    -- if energy <=21 then powershift
	or (NAG:AuraIsActive(768) and NAG:CurrentManaPercentBase() > 0.35 and
        ((NAG:CurrentEnergyAtGCD() < 10) or
        (NAG:CurrentEnergyAtGCD() <= 21 and NAG:CurrentEnergyAtGCD() > 10 and NAG:TimeToEnergyTickWithGCD() > 1.0))) and NAG:CastPowershiftPlaceholder()

    -- If 5 CP and no Rip, apply Rip first
    or (NAG:CurrentComboPoints() >= 5 and (not NAG:DotIsActive(1079))
        and (NAG:RemainingTime() >= 10)
        and (NAG:RemainingTime() >= (NAG:DotBaseDuration(1079) * 0.8))) and NAG:Cast(1079)

    -- If 5 CP and Rip is active, use Ferocious Bite
    or (NAG:CurrentComboPoints() >= 5 and NAG:DotIsActive(1079)) and NAG:Cast(22568)

    -- Emergency: if target is dying soon, use Ferocious Bite immediately (if possible)
    or ((NAG:CurrentComboPoints() >= 1) and (NAG:RemainingTime() <= 3) and (not(NAG:HasEnergy(5221)) or NAG:UnitIsPrimaryTarget()) )and NAG:Cast(22568)

    or NAG:CastMangleIfNeeded()
    -- Shred (only when not tanking the target)
    or (not NAG:UnitIsPrimaryTarget()) and NAG:Cast(5221)
    ]],

    -- Tracked IDs
    spells = {
	16857, -- faerie fire Feral
	16979, --charge
	768, --cAT form
	33876, --mangle
	1079, --rip
	5221, --Shred
	22568, --bite
    },
    items = {
    },
    auras = {},
    runes = {},

	author = "espi",
}

-- Restoration Rotation (Experimental)
local restorationRotation = {
    -- Core identification
    name = "Restoration",
    specIndex = 4,
    class = "DRUID",
    default = true,
    enabled = false,
    experimental = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    lastModified = "12/30/2025",
    rotationString = [[
    -- Maintain Tree of Life
    (not NAG:AuraIsActive(5420)) and NAG:SpellCanCast(5420) and NAG:Cast(5420)
    -- Maintain 3 stacks of Lifebloom on focus (tank)
    or ((NAG:UnitExists("focus") and (NAG:AuraNumStacks(33763, "focus") < 3 or (not NAG:AuraIsActive(33763, "focus")))) and NAG:SpellCanCast(33763)) and NAG:Cast(33763)
    -- Maintain Rejuvenation on focus (tank)
    or ((NAG:UnitExists("focus") and (not NAG:AuraIsActive(774, "focus"))) and NAG:SpellCanCast(774)) and NAG:Cast(774)
    -- Maintain Regrowth HoT on focus (tank)
    or ((NAG:UnitExists("focus") and (not NAG:AuraIsActive(8936, "focus"))) and NAG:SpellCanCast(8936)) and NAG:Cast(8936)
    -- Cast Nature's Swiftness with Healing Touch for instant emergency heal (need to leave Tree of Life)
    or ((NAG:UnitExists("focus") and NAG:CurrentHealthPercent("focus") < 0.3 and NAG:SpellCanCast(16188) and (not NAG:AuraIsActive(16188, "player")) and NAG:SpellCanCast(5185)) and NAG:AuraIsActive(5420)) and NAG:Cast(16188)
    -- Cast Healing Touch with Nature's Swiftness (after casting Nature's Swiftness)
    or ((NAG:UnitExists("focus") and NAG:CurrentHealthPercent("focus") < 0.3 and NAG:AuraIsActive(16188, "player") and NAG:SpellCanCast(5185))) and NAG:Cast(5185)
    -- Cast Swiftmend for instant emergency heal
    or ((NAG:UnitExists("focus") and NAG:CurrentHealthPercent("focus") < 0.4 and NAG:SpellCanCast(18562))) and NAG:Cast(18562)
    -- Cast Rejuvenation to spot heal the raid (target)
    or ((NAG:UnitExists("target") and NAG:CurrentHealthPercent("target") < 0.8 and (not NAG:AuraIsActive(774, "target"))) and NAG:SpellCanCast(774)) and NAG:Cast(774)
    -- Cast Regrowth as filler (downrank if necessary for mana)
    or (NAG:SpellCanCast(8936)) and NAG:Cast(8936)
    ]],

    -- Tracked IDs for optimization
    spells = {5420, 33763, 774, 8936, 16188, 5185, 18562},
    items = {},
    auras = {5420, 33763, 774, 8936, 16188}, -- Tree of Life, Lifebloom, Rejuvenation, Regrowth, Nature's Swiftness

    -- Optional metadata
    guide = [[
Restoration Druid Rotation Guide (TBC) - EXPERIMENTAL

NOTE: This is an experimental rotation. Healing rotations are complex and may not work perfectly.
Set your focus to the tank you are assigned to heal. The rotation will prioritize healing the focus unit.

Core Mechanics:
- Restoration Druids are healers focusing on HoT (Heal over Time) maintenance and emergency healing.
- Tree of Life form provides healing bonuses and reduces mana costs - always maintain it.
- Lifebloom stacks up to 3 times and provides significant healing - maintain 3 stacks on tanks.
- Rejuvenation and Regrowth provide HoT healing - maintain on tanks.
- Nature's Swiftness + Healing Touch provides instant emergency healing (requires leaving Tree of Life).
- Swiftmend provides instant emergency healing without leaving Tree of Life.

Rotation Priority:
1. Maintain Tree of Life (provides healing bonuses and reduces mana costs - refresh before it expires)
2. Maintain 3 stacks of Lifebloom on focus (tank)
   - Lifebloom stacks up to 3 times
   - Maintain 3 stacks for maximum healing
   - 7 second duration per stack
   - Focus unit should be set to your assigned tank
3. Maintain Rejuvenation on focus (tank)
   - HoT healing spell
   - 12 second duration
   - Maintain on tanks for consistent healing
4. Maintain Regrowth HoT on focus (tank)
   - Provides both instant and HoT healing
   - 21 second duration
   - Maintain on tanks for consistent healing
5. Cast Nature's Swiftness with Healing Touch for instant emergency heal
   - Use when focus (tank) health is below 30%
   - Requires leaving Tree of Life form
   - Provides instant, high healing
   - Cast Nature's Swiftness first, then Healing Touch
6. Cast Swiftmend for instant emergency heal
   - Use when focus (tank) health is below 40%
   - Instant heal that consumes a Rejuvenation or Regrowth HoT
   - Does not require leaving Tree of Life
7. Cast Rejuvenation to spot heal the raid
   - Use on target when health is below 80%
   - Provides HoT healing for raid members
8. Cast Regrowth as filler
   - Use when other priorities are met
   - Downrank if necessary for mana efficiency
   - Provides both instant and HoT healing

Tank Healing (Focus Unit):
- Set your focus to the tank you are assigned to heal
- Maintain 3 stacks of Lifebloom on focus
- Maintain Rejuvenation on focus
- Maintain Regrowth HoT on focus
- Use emergency heals (Nature's Swiftness + Healing Touch or Swiftmend) when focus health is low

Raid Spot Healing:
- Use Rejuvenation on raid members (target) when health is below 80%
- Prioritize tanks (focus) over raid members
- Use Regrowth as filler when other priorities are met

Emergency Healing:
- Nature's Swiftness + Healing Touch: Instant, high healing (requires leaving Tree of Life)
  - Use when focus health is below 30%
  - Cast Nature's Swiftness first, then Healing Touch
- Swiftmend: Instant heal that consumes a HoT (does not require leaving Tree of Life)
  - Use when focus health is below 40%
  - Consumes a Rejuvenation or Regrowth HoT

Mana Management:
- Tree of Life: Reduces mana costs for healing spells
- Regrowth: Can be downranked for mana efficiency
- Use lower rank spells if mana becomes an issue
- Coordinate with other healers for mana regeneration (Innervate)

Form Management:
- Tree of Life: Maintain at all times for healing bonuses
- Nature's Swiftness + Healing Touch: Requires leaving Tree of Life temporarily
  - Cast Nature's Swiftness, then Healing Touch, then return to Tree of Life

Raid Coordination:
- Focus Unit: Set focus to your assigned tank
- Lifebloom: Maintain 3 stacks on your assigned tank
- Rejuvenation: Maintain on your assigned tank
- Regrowth: Maintain HoT on your assigned tank
- Mark of the Wild: Coordinate with other Druids for raid-wide stats buff
- Innervate: Coordinate with other healers/Druids for mana regeneration
- Usually 1-2 Restoration Druids per raid for healing and raid support

EXPERIMENTAL NOTES:
- This rotation is experimental and may not work perfectly
- Healing rotations are complex and require manual adjustment
- Set your focus to the tank you are assigned to heal
- The rotation assumes you have focus set correctly
- Some healing logic may need manual intervention
- Casting on focus may require macros or manual targeting
  - Consider using macros with [@focus] modifier for focus healing
  - Example: /cast [@focus] Lifebloom
  - The rotation will check focus health/auras, but actual casting may need macros
    ]],
    author = "Rakizi",
}

-- Feral DPS Macros
local feralDPSMacros = {
    {
        name = "Power Shift",
        body = "#showtooltip Cat Form\n/cast !Cat Form"
    },
}

--- @class Druid : ClassBase
local Druid = NAG:CreateClassModule("DRUID", defaults)
if not Druid then return end

function Druid:SetupClassDefaults()
    -- Attach macros to rotations
    --feralCombatRotation.macros = feralDPSMacros
    -- Note: For TBC Druid, SpecializationCompat uses indices 1, 2, 4 (index 3 is duplicate Feral)
    -- We use the actual spec indices from SpecializationCompat for consistency
    ns.AddRotationToDefaults(self.defaults, 1, balanceRotation)  -- Balance
    --ns.AddRotationToDefaults(self.defaults, 2, feralCombatRotation)  -- Feral Combat
    ns.AddRotationToDefaults(self.defaults, 2, catRotationEspi)  -- Feral DPS
    ns.AddRotationToDefaults(self.defaults, 2, bearRotationEspi)  -- Feral Tank
    ns.AddRotationToDefaults(self.defaults, 4, restorationRotation)  -- Restoration (index 4, not 3)
end

NAG.Class = Druid

