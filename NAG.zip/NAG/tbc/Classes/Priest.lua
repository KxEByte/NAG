local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version

local defaults = ns.InitializeClassDefaults()

-- TBC Priest spec spell locations
defaults.class.specSpellLocations = {
    [1] = {},  -- Discipline (not supported)
    [2] = {},  -- Holy (not supported)
    [3] = { -- Shadow
        -- BELOW spells (Pets)

        -- LEFT spells (Cooldowns)
        [14751] = NAG.SPELL_POSITIONS.LEFT,    -- Inner Focus
        [34433] = NAG.SPELL_POSITIONS.LEFT,   -- Shadowfiend (pet summon)

        -- PRIMARY spells (default, not explicitly set)
        -- Vampiric Touch (34914) - DoT debuff
        -- Shadow Word: Pain (589) - DoT debuff
        -- Mind Blast (8092) - main nuke
        -- Shadow Word: Death (32379) - execute phase
        -- Mind Flay (15407) - channeled filler
    },
}

-- Class assignments for raid coordination
defaults.class.classAssignments = {
    {
        id = "power_word_fortitude",
        name = "Power Word: Fortitude",
        description = "Provide stamina buff to raid (coordinate with other Priests)",
        spellIds = {1243, 1244, 1245, 2791, 10937, 10938, 25389}, -- All ranks
        category = "buff",
    },
    {
        id = "shadow_protection",
        name = "Shadow Protection / Prayer of Shadow Protection",
        description = "Provide shadow resistance buff to raid (coordinate with other Priests)",
        spellIds = {976, 10957, 10958, 25433, 27683}, -- All ranks
        category = "buff",
    },
}

if UnitClassBase('player') ~= "PRIEST" then return end

-- Discipline Rotation
local disciplineRotation = {
    -- Core identification
    name = "Discipline",
    specIndex = 1,
    class = "PRIEST",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    rotationString = "NAG:Cast(6603)",
}

-- Holy Rotation
local holyRotation = {
    -- Core identification
    name = "Holy",
    specIndex = 2,
    class = "PRIEST",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    rotationString = "NAG:Cast(6603)",
}

-- Shadow Rotation
local shadowRotation = {
    -- Core identification
    name = "Shadow",
    specIndex = 3,
    class = "PRIEST",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    lastModified = "12/17/2025",
    rotationString = [[
    -- NOTE: This APL intentionally uses LOWEST-RANK IDs (learned earliest) and relies on
    -- ResolveEffectiveSpellId / *Resolved helpers so the player still casts their best known rank.

    -- Shadowform (keep up)
    (NAG:SpellIsKnown(15473) and (not NAG:AuraIsActiveResolved(15473)) and NAG:SpellCanCastResolved(15473))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(15473))

    -- Mana cooldown: Shadowfiend (use when mana is meaningfully low, in combat)
    or (NAG:InCombat() and (NAG:CurrentManaPercent() <= 0.60) and NAG:SpellCanCastResolved(34433))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(34433), nil, NAG.SPELL_POSITIONS.BELOW)

    -- Multi-dot helper (TAB target) - only if targets live long enough for 3+ ticks (~9s)
    or ((NAG:NumberTargetsWithTTD(9, 30) >= 2)
        and NAG:ShouldMultidot(NAG:ResolveEffectiveSpellId(34914), NAG:NumberTargetsWithTTD(9, 30), (NAG:DotTickFrequency(NAG:ResolveEffectiveSpellId(34914)) or 3), 30)
        and NAG:SpellCanCastResolved(34914))
        and NAG:CastWithOverlay(NAG:ResolveEffectiveSpellId(34914), "TAB\nDOT", NAG.SPELL_POSITIONS.LEFT)
    or ((NAG:NumberTargetsWithTTD(9, 30) >= 2)
        and NAG:DotIsActiveResolved(34914)
        and NAG:ShouldMultidot(NAG:ResolveEffectiveSpellId(589), NAG:NumberTargetsWithTTD(9, 30), (NAG:DotTickFrequency(NAG:ResolveEffectiveSpellId(589)) or 3), 30)
        and NAG:SpellCanCastResolved(589))
        and NAG:CastWithOverlay(NAG:ResolveEffectiveSpellId(589), "TAB\nDOT", NAG.SPELL_POSITIONS.RIGHT)

    -- Maintain Vampiric Touch (34914 = VT rank 1)
    -- Refresh late: if missing OR will expire before a fresh cast would complete.
    or (((not NAG:DotIsActiveResolved(34914)) or (NAG:DotRemainingTimeResolved(34914) <= NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(34914))))
        and NAG:SpellCanCastResolved(34914))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(34914))

    -- Maintain Shadow Word: Pain (589 = SW:P rank 1)
    -- Refresh very late (avoid overwriting ticks): missing OR about to fall off.
    or (((not NAG:DotIsActiveResolved(589)) or (NAG:DotRemainingTimeResolved(589) <= (NAG:GCDTimeValue() + 0.10)))
        and NAG:SpellCanCastResolved(589))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(589))

    -- Inner Focus paired with Mind Blast (14751 = Inner Focus)
    or (NAG:SpellCanCastResolved(14751) and (not NAG:AuraIsActiveResolved(14751)) and NAG:SpellCanCastResolved(8092))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(14751))

    -- Mind Blast (8092 = Mind Blast rank 1)
    or (NAG:SpellCanCastResolved(8092))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(8092))

    -- Shadow Word: Death (32379 = SW:D rank 1) - situational due to backlash risk.
    -- Use primarily during execute and/or as a movement button, with a basic HP safety gate.
    or (((NAG:IsExecutePhase(20) or NAG:UnitIsMoving()) and (NAG:CurrentHealthPercent() >= 0.60))
        and NAG:SpellCanCastResolved(32379))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(32379))

    -- Filler: Mind Flay (15407 = Mind Flay rank 1)
    or (NAG:SpellCanCastResolved(15407))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(15407))
    ]],

    -- Tracked IDs for optimization
    spells = {589, 8092, 14751, 15407, 15473, 32379, 34433, 34914},
    items = {},
    auras = {14751, 15473}, -- Inner Focus, Shadowform

    -- Optional metadata
    guide = [[
Shadow Priest Rotation Guide (TBC)

Core Mechanics:
- Vampiric Touch is core for damage and group mana return; keep it up on the target.
- DoT management matters: aim for high uptime, but avoid overwriting DoTs too early (wastes ticks).
- Mind Blast is a priority nuke; Mind Flay is your filler and can be clipped for higher-priority spells.
- Shadow Word: Death has backlash if the target does not die; treat it as situational.

Rotation Priority (Single Target):
1. If Mana is low and Shadowfiend is ready, cast Shadowfiend.
2. If Vampiric Touch is missing OR will expire before your next VT cast would finish (remaining <= cast time), cast Vampiric Touch.
3. If Shadow Word: Pain is missing OR about to expire, cast Shadow Word: Pain.
4. If Mind Blast is ready soon/now and Inner Focus is ready and not active, cast Inner Focus.
5. If Mind Blast is ready, cast Mind Blast.
6. If you are moving AND Shadow Word: Death is safe for you (you can afford the backlash), cast Shadow Word: Death.
7. Otherwise, channel Mind Flay (clip/interrupt it if a higher-priority spell becomes ready).

AoE Rotation:
1. If there are multiple targets with TTD >= 9s, tab-dot VT/SW:P (use "TAB DOT" overlay).
2. Proceed with single target rotation on primary target.

DoT Management:
- Vampiric Touch: 15 second duration, 3 second tick interval
- Shadow Word: Pain: 18 second duration, 3 second tick interval
- Avoid refreshing very early (it wastes remaining ticks).
- Refresh as late as practical while maintaining strong uptime (near expiration).

Cooldowns:
- Shadowfiend: 5min CD. Summons pet that attacks and restores mana.
- Inner Focus: 3min CD. Makes next spell free and increases crit chance by 25%.

Mana Management:
- Shadowfiend: Use when mana is low (and a valid target will live long enough for it to connect).
- Inner Focus: Use with Mind Blast for free cast and crit bonus
- Vampiric Touch: Provides mana return to your party/raid while it is active on the target.
- Consider using mana potions during long fights

Raid Utility:
- Vampiric Touch: Mana return utility (commonly 1 Shadow Priest per raid for this).
- Vampiric Embrace: Healing utility.
- Coordinate buffs with other Priests (Power Word: Fortitude, Shadow Protection)

Talents:
- Standard build focuses on Shadow tree with some Discipline points
- Adjust Shadow Focus points if over spell hit cap (16%)
- Shadow Power and Shadow Weaving are key damage talents
    ]],
    author = "Rakizi",
}

--- @class Priest : ClassBase
local Priest = NAG:CreateClassModule("PRIEST", defaults)
if not Priest then return end

function Priest:SetupClassDefaults()
    ns.AddRotationToDefaults(self.defaults, 1, disciplineRotation)  -- Discipline
    ns.AddRotationToDefaults(self.defaults, 2, holyRotation)  -- Holy
    ns.AddRotationToDefaults(self.defaults, 3, shadowRotation)  -- Shadow
end

function Priest:RegisterSpellTracking()
    local SpellTrackingManager = NAG:GetModule("SpellTrackingManager")
    -- Register periodic damage DoTs for Shadow Priest
    SpellTrackingManager:RegisterPeriodicDamage({ 34914 }, { tickTime = 3, lastTickTime = nil }) -- Vampiric Touch
    SpellTrackingManager:RegisterPeriodicDamage({ 589 }, { tickTime = 3, lastTickTime = nil })   -- Shadow Word: Pain
end

NAG.Class = Priest

