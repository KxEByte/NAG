local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version

local defaults = ns.InitializeClassDefaults()

-- Soulshatter threat baseline (raw threat amount)
-- TODO: Set a real baseline after testing (e.g., via /dump NAG:UnitThreatValue()).
local SOULSHATTER_THREAT_VALUE_BASELINE = nil

-- TBC Warlock spec spell locations
defaults.class.specSpellLocations = {
    [1] = { -- Affliction
        -- ABOVE spells (Buffs, maintenance)
        [28176] = NAG.SPELL_POSITIONS.ABOVE,   -- Fel Armor
        [688] = NAG.SPELL_POSITIONS.ABOVE,     -- Summon Imp (pet)


        -- LEFT spells (Cooldowns, curses, racials)
        [18288] = NAG.SPELL_POSITIONS.LEFT,    -- Amplify Curse
        [980] = NAG.SPELL_POSITIONS.LEFT,      -- Curse of Agony
        [1490] = NAG.SPELL_POSITIONS.LEFT,     -- Curse of the Elements
        [704] = NAG.SPELL_POSITIONS.LEFT,      -- Curse of Recklessness
        [29858] = NAG.SPELL_POSITIONS.LEFT,    -- Soulshatter
        [20572] = NAG.SPELL_POSITIONS.LEFT,    -- Blood Fury (Orc Racial)
        [26297] = NAG.SPELL_POSITIONS.LEFT,    -- Berserking (Troll Racial)
        [28734] = NAG.SPELL_POSITIONS.LEFT,    -- Mana Tap (BE Racial)
        [25046] = NAG.SPELL_POSITIONS.LEFT,    -- Arcane Torrent (BE Racial)

        -- AOE spells
        [27243] = NAG.SPELL_POSITIONS.RIGHT,     -- Seed of Corruption

    },
    [2] = { -- Demonology
        -- ABOVE spells (Buffs, maintenance)
        [28176] = NAG.SPELL_POSITIONS.ABOVE,   -- Fel Armor
        -- BELOW spells (Pets)
        [712] = NAG.SPELL_POSITIONS.BELOW,     -- Summon Succubus (pet)
        [30146] = NAG.SPELL_POSITIONS.BELOW,   -- Summon Felguard (pet)


        -- LEFT spells (Cooldowns, curses, racials)
        [18288] = NAG.SPELL_POSITIONS.LEFT,    -- Amplify Curse
        [980] = NAG.SPELL_POSITIONS.LEFT,      -- Curse of Agony
        [1490] = NAG.SPELL_POSITIONS.LEFT,     -- Curse of the Elements
        [704] = NAG.SPELL_POSITIONS.LEFT,      -- Curse of Recklessness
        [29858] = NAG.SPELL_POSITIONS.LEFT,    -- Soulshatter
        [20572] = NAG.SPELL_POSITIONS.LEFT,    -- Blood Fury (Orc Racial)
        [26297] = NAG.SPELL_POSITIONS.LEFT,    -- Berserking (Troll Racial)
        [28734] = NAG.SPELL_POSITIONS.LEFT,    -- Mana Tap (BE Racial)
        [25046] = NAG.SPELL_POSITIONS.LEFT,    -- Arcane Torrent (BE Racial)

        -- AOE spells
        [27243] = NAG.SPELL_POSITIONS.RIGHT,     -- Seed of Corruption

    },
    [3] = { -- Destruction
        -- ABOVE spells (Buffs, maintenance)
        [28176] = NAG.SPELL_POSITIONS.ABOVE,   -- Fel Armor
        [18788] = NAG.SPELL_POSITIONS.ABOVE,   -- Demonic Sacrifice
        [712] = NAG.SPELL_POSITIONS.ABOVE,     -- Summon Succubus (pet)
        [688] = NAG.SPELL_POSITIONS.ABOVE,     -- Summon Imp (for Imp sacrifice - Burning Wish buff)

        -- LEFT spells (Cooldowns, curses, racials)
        [18288] = NAG.SPELL_POSITIONS.LEFT,    -- Amplify Curse
        [980] = NAG.SPELL_POSITIONS.LEFT,      -- Curse of Agony
        [1490] = NAG.SPELL_POSITIONS.LEFT,     -- Curse of the Elements
        [704] = NAG.SPELL_POSITIONS.LEFT,      -- Curse of Recklessness
        [29858] = NAG.SPELL_POSITIONS.LEFT,    -- Soulshatter
        [20572] = NAG.SPELL_POSITIONS.LEFT,    -- Blood Fury (Orc Racial)
        [26297] = NAG.SPELL_POSITIONS.LEFT,    -- Berserking (Troll Racial)
        [28734] = NAG.SPELL_POSITIONS.LEFT,    -- Mana Tap (BE Racial)
        [25046] = NAG.SPELL_POSITIONS.LEFT,    -- Arcane Torrent (BE Racial)

        -- AOE spells
        [27243] = NAG.SPELL_POSITIONS.RIGHT,     -- Seed of Corruption

    },
}

-- Class assignments for raid coordination (disabled by default)
defaults.class.classAssignments = {
    {
        id = "curse_of_recklessness",
        name = "Curse of Recklessness",
        description = "Reduce target armor and remove fear effects (coordinate with other Warlocks - only one curse per target)",
        spellIds = {704, 7658, 7659, 11717, 27226}, -- All ranks
        category = "debuff",
    },
    {
        id = "curse_of_elements",
        name = "Curse of the Elements",
        description = "Apply magic vulnerability debuff (coordinate with other Warlocks - only one curse per target)",
        spellIds = {1490, 11721, 11722, 27228}, -- All ranks
        category = "debuff",
    },
    {
        id = "curse_of_weakness",
        name = "Curse of Weakness",
        description = "Reduce target's physical damage output (coordinate with other Warlocks - only one curse per target)",
        spellIds = {702, 1108, 6205, 7646, 11707, 11708, 27224, 30909}, -- All ranks
        category = "debuff",
    },
    {
        id = "curse_of_tongues",
        name = "Curse of Tongues",
        description = "Increase enemy casting time (coordinate with other Warlocks - only one curse per target)",
        spellIds = {1714, 11719}, -- All ranks
        category = "debuff",
    },
}

defaults.char.assignmentToggles = defaults.char.assignmentToggles or {}
if defaults.char.assignmentToggles.curse_of_recklessness == nil then
    defaults.char.assignmentToggles.curse_of_recklessness = false
end
if defaults.char.assignmentToggles.curse_of_elements == nil then
    defaults.char.assignmentToggles.curse_of_elements = false
end
if defaults.char.assignmentToggles.curse_of_weakness == nil then
    defaults.char.assignmentToggles.curse_of_weakness = false
end
if defaults.char.assignmentToggles.curse_of_tongues == nil then
    defaults.char.assignmentToggles.curse_of_tongues = false
end

if UnitClassBase('player') ~= "WARLOCK" then return end

-- Generic (0 talent points): low-level abilities before choosing a spec
local genericRotation = {
    name = "Generic",
    specIndex = 0,
    class = "WARLOCK",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    rotationString = [[
    (not NAG:AuraIsActiveResolved(706) and not NAG:AuraIsActiveResolved(687) and not NAG:AuraIsActiveResolved(28176)) and NAG:SpellCanCastResolved(706) and NAG:Cast(NAG:ResolveEffectiveSpellId(706))
    or (not NAG:AuraIsActiveResolved(687) and not NAG:AuraIsActiveResolved(706) and not NAG:AuraIsActiveResolved(28176)) and NAG:SpellCanCastResolved(687) and NAG:Cast(NAG:ResolveEffectiveSpellId(687))
    or (not NAG:AuraIsActiveResolved(28176) and not NAG:AuraIsActiveResolved(706) and not NAG:AuraIsActiveResolved(687)) and NAG:SpellCanCastResolved(28176) and NAG:Cast(NAG:ResolveEffectiveSpellId(28176))
    or (NAG:SpellCanCastResolved(348) and (not NAG:DotIsActive(348, "target"))) and NAG:Cast(NAG:ResolveEffectiveSpellId(348))
    or (NAG:SpellCanCastResolved(686)) and NAG:Cast(NAG:ResolveEffectiveSpellId(686))
]],
}

-- Affliction Rotation
local afflictionRotation = {
    -- Core identification
    name = "Affliction",
    specIndex = 1,
    class = "WARLOCK",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    lastModified = "12/30/2025",
    rotationString = [[
    -- NOTE: Use LOWEST-RANK IDs with ResolveEffectiveSpellId/*Resolved helpers.
    NAG:EnableAssignmentsGate()
    or

    -- Maintain Fel Armor
    (NAG:SpellCanCastResolved(28176) and (not NAG:AuraIsActiveResolved(28176)))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(28176))
    -- Maintain Summon Succubus
    or ((not NAG:PetIsActive()) and NAG:SpellCanCastResolved(712))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(712))
    -- Fall back to Imp in case no shards
    or ((not NAG:PetIsActive()) and NAG:SpellCanCastResolved(688) and (not NAG:SpellCanCastResolved(712)))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(688))

    -- Execute: Shadowburn (shard spender)
    -- Only if a Shadow Bolt won't land in time
    or (NAG:IsExecutePhase(20) and (NAG:CurrentSoulShards() >= 1) and NAG:SpellCanCastResolved(17877)
        and (NAG:RemainingTime() < (NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(686)) + NAG:SpellTravelTime(NAG:ResolveEffectiveSpellId(686)))))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(17877))

    -- Soulshatter when threat is high (group only, shards required)
    or (NAG:InCombat() and (GetNumGroupMembers() > 0) and (NAG:CurrentSoulShards() >= 1)
        and SOULSHATTER_THREAT_VALUE_BASELINE and (NAG:UnitThreatValue() >= SOULSHATTER_THREAT_VALUE_BASELINE)
        and (NAG:UnitThreatPercent() >= 90) and NAG:SpellCanCastResolved(29858))
        and NAG:CastWithOverlay(NAG:ResolveEffectiveSpellId(29858), "SHATTER", NAG.SPELL_POSITIONS.LEFT)

    -- Movement: Death Coil (only when moving and in combat; otherwise filler is preferred)
    or (NAG:InCombat() and NAG:UnitIsMoving() and NAG:SpellCanCastResolved(6789))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(6789),  nil, NAG.SPELL_POSITIONS.AOE)

    -- Mana: Life Tap when needed (health-safe, ideally while moving)
    or ((NAG:UnitIsMoving() or NAG:CurrentManaPercent() < 0.20)
        and (NAG:CurrentManaPercent() < 0.70)
        and (NAG:CurrentHealthPercent() >= 0.50)
        and NAG:SpellCanCastResolved(1454))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(1454), nil, NAG.SPELL_POSITIONS.RIGHT)

    -- AoE: Seed of Corruption on targets without it (TTD-gated)
    -- AoE: Seed of Corruption on targets without it (TTD-gated)
    or ((NAG:NumberTargetsWithTTD(9, 30) >= 2) and (not NAG:DotIsActiveResolved(27243)) and NAG:SpellCanCastResolved(27243))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(27243),  nil, NAG.SPELL_POSITIONS.PRIMARY)
    -- Utility curses (assignment opt-in only; priority Reck -> Elements -> Weak -> Tongues)
    or ((GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("curse_of_recklessness")
        and NAG:ShouldUseCurseOfRecklessness()
        and (not NAG:IsSpellBlacklisted(704)) and (not NAG:DotIsActiveGlobal(704))
        and NAG:SpellCanCastResolved(704))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(704))
    or ((GetNumGroupMembers() > 0) and (not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and NAG:IsAssignmentEnabled("curse_of_elements")
        and (not NAG:IsSpellBlacklisted(1490)) and (not NAG:DotIsActiveGlobal(1490))
        and NAG:SpellCanCastResolved(1490))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(1490))
    or ((GetNumGroupMembers() > 0) and (not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and NAG:IsAssignmentEnabled("curse_of_weakness")
        and (not NAG:IsSpellBlacklisted(702)) and (not NAG:DotIsActiveGlobal(702))
        and NAG:SpellCanCastResolved(702))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(702))
    or ((GetNumGroupMembers() > 0) and (not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and NAG:IsAssignmentEnabled("curse_of_tongues")
        and (not NAG:IsSpellBlacklisted(1714)) and (not NAG:DotIsActiveGlobal(1714))
        and NAG:SpellCanCastResolved(1714))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(1714))

    -- Curse of Agony (22-70s) - only if no utility assignment is enabled
    or ((not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and (not NAG:IsAssignmentEnabled("curse_of_tongues"))
        and (NAG:RemainingTime() >= 22) and (NAG:RemainingTime() <= 70)
        and (not (NAG:DotIsActiveResolved(603) or NAG:DotIsActiveResolved(980) or NAG:DotIsActiveResolved(1490) or NAG:DotIsActiveResolved(704) or NAG:DotIsActiveResolved(17862) or NAG:DotIsActiveResolved(702) or NAG:DotIsActiveResolved(1714)))
        and (not NAG:DotIsActiveGlobal(980))
        and ((not NAG:DotIsActiveResolved(980)) or (NAG:DotRemainingTimeResolved(980) <= (NAG:GCDTimeValue() + 0.10)))
        and NAG:SpellCanCastResolved(980))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(980))

    -- Curse of Doom with Amplify Curse (>70s) - only if no utility assignment is enabled
    or ((not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and (not NAG:IsAssignmentEnabled("curse_of_tongues"))
        and (NAG:RemainingTime() > 70) and (NAG:CurrentTime() > 2)
        and (not (NAG:DotIsActiveResolved(603) or NAG:DotIsActiveResolved(980) or NAG:DotIsActiveResolved(1490) or NAG:DotIsActiveResolved(704) or NAG:DotIsActiveResolved(17862) or NAG:DotIsActiveResolved(702) or NAG:DotIsActiveResolved(1714)))
        and (not NAG:DotIsActiveGlobal(603))
        and ((not NAG:DotIsActiveResolved(603)) or (NAG:DotRemainingTimeResolved(603) <= (NAG:GCDTimeValue() + 0.10)))
        and NAG:SpellCanCastResolved(603)
        and NAG:AuraIsActiveResolved(18288))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(603))

    -- Amplify Curse before Curse of Doom (>70s) - only if no utility assignment is enabled
    or ((not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and (not NAG:IsAssignmentEnabled("curse_of_tongues"))
        and (NAG:RemainingTime() > 70) and (NAG:CurrentTime() > 2)
        and (not (NAG:DotIsActiveResolved(603) or NAG:DotIsActiveResolved(980) or NAG:DotIsActiveResolved(1490) or NAG:DotIsActiveResolved(704) or NAG:DotIsActiveResolved(17862) or NAG:DotIsActiveResolved(702) or NAG:DotIsActiveResolved(1714)))
        and (not NAG:DotIsActiveGlobal(603))
        and ((not NAG:DotIsActiveResolved(603)) or (NAG:DotRemainingTimeResolved(603) <= (NAG:GCDTimeValue() + 0.10)))
        and NAG:SpellCanCastResolved(603)
        and NAG:SpellCanCastResolved(18288)
        and (not NAG:AuraIsActiveResolved(18288)))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(18288))

    -- Curse of Doom without Amplify Curse (>70s) - only if no utility assignment is enabled
    or ((not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and (not NAG:IsAssignmentEnabled("curse_of_tongues"))
        and (NAG:RemainingTime() > 70) and (NAG:CurrentTime() > 2)
        and (not (NAG:DotIsActiveResolved(603) or NAG:DotIsActiveResolved(980) or NAG:DotIsActiveResolved(1490) or NAG:DotIsActiveResolved(704) or NAG:DotIsActiveResolved(17862) or NAG:DotIsActiveResolved(702) or NAG:DotIsActiveResolved(1714)))
        and (not NAG:DotIsActiveGlobal(603))
        and ((not NAG:DotIsActiveResolved(603)) or (NAG:DotRemainingTimeResolved(603) <= (NAG:GCDTimeValue() + 0.10)))
        and NAG:SpellCanCastResolved(603))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(603))

    -- Maintain Corruption
    or (not NAG:DotIsActiveResolved(172))
        and NAG:SpellCanCastResolved(172)
        and NAG:Cast(NAG:ResolveEffectiveSpellId(172))

    -- Maintain Siphon Life (only with Shadow Vulnerability if ISB talent is present)
    or (not NAG:DotIsActiveResolved(18265))
        and (not (NAG:SpellIsKnown(17793) or NAG:SpellIsKnown(17796) or NAG:SpellIsKnown(17801) or NAG:SpellIsKnown(17802) or NAG:SpellIsKnown(17803))
            or (NAG:DotIsActiveGlobal(17794) or NAG:DotIsActiveGlobal(17797) or NAG:DotIsActiveGlobal(17798) or NAG:DotIsActiveGlobal(17799) or NAG:DotIsActiveGlobal(17800)))
        and NAG:SpellCanCastResolved(18265)
        and NAG:Cast(NAG:ResolveEffectiveSpellId(18265))

    -- Maintain Immolate
    or (not NAG:DotIsActiveResolved(348))
        and NAG:SpellCanCastResolved(348)
        and NAG:Cast(NAG:ResolveEffectiveSpellId(348))

    -- Cast Shadow Bolt (main filler)
    or NAG:NotSpamCast(686)
    -- If a DoT will drop before Shadow Bolt finishes, refresh it first (only if target lives long enough)
    or (NAG:DotIsActiveResolved(172)
        and (NAG:DotRemainingTimeNowResolved(172) <= ((NAG:UnitCastTimeRemaining("player") > 0)
            and NAG:UnitCastTimeRemaining("player")
            or (NAG:GCDTimeToReady() + NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(686))))))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(172))
    or (NAG:DotIsActiveResolved(18265)
        and (NAG:DotRemainingTimeNowResolved(18265) <= ((NAG:UnitCastTimeRemaining("player") > 0)
            and NAG:UnitCastTimeRemaining("player")
            or (NAG:GCDTimeToReady() + NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(686))))))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(18265))
    or (NAG:DotIsActiveResolved(348)
        and (NAG:DotRemainingTimeNowResolved(348) <= ((NAG:UnitCastTimeRemaining("player") > 0)
            and NAG:UnitCastTimeRemaining("player")
            or (NAG:GCDTimeToReady() + NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(686))))))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(348))
    or (NAG:DotIsActiveResolved(980)
        and (NAG:DotRemainingTimeNowResolved(980) <= ((NAG:UnitCastTimeRemaining("player") > 0)
            and NAG:UnitCastTimeRemaining("player")
            or (NAG:GCDTimeToReady() + NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(686))))))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(980))
    or (NAG:DotIsActiveResolved(603)
        and (NAG:DotRemainingTimeNowResolved(603) <= ((NAG:UnitCastTimeRemaining("player") > 0)
            and NAG:UnitCastTimeRemaining("player")
            or (NAG:GCDTimeToReady() + NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(686))))))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(603))
    or NAG:Cast(686)
    ]],

    -- Tracked IDs for optimization
    spells = {28176, 712, 688, 603, 980, 172, 18265, 348, 686, 17877, 6789, 1454, 27243, 18288, 1490, 704, 29858},
    items = {},
    auras = {28176, 18288, 172, 18265, 348, 603, 980}, -- Fel Armor, Amplify Curse, Corruption, Siphon Life, Immolate, Curse of Doom, Curse of Agony

    -- Optional metadata
    guide = [[
Affliction Warlock Rotation Guide (TBC)

Core Mechanics:
- Affliction Warlocks are DoT-based DPS casters focusing on shadow damage and sustained uptime.
- Reapply DoTs only after they fall off.
- If you have Improved Shadow Bolt, only use Siphon Life while Shadow Vulnerability is active.
- Curse choice is fight-length dependent: Doom for long fights, Agony for short fights.
- Coordinate curses: only one curse can be active on a target.
- Life Tap is part of your rotation; use it when mana is low and health is safe.

Rotation Priority (Single Target):
1. If Fel Armor is missing, cast Fel Armor.
2. If pet is missing, summon Succubus (fall back to Imp if no shards).
3. If execute phase and a Shadow Bolt won't land in time, cast Shadowburn.
4. Use Soulshatter in group when threat is high (shards required).
5. If moving and you need an instant, cast Death Coil.
6. If mana is low and health is safe, cast Life Tap (ideally while moving).
7. If target will live <60s and no other curse is active, cast Curse of Agony.
8. If target will live >=60s and no other curse is active, cast Amplify Curse then Curse of Doom.
9. Maintain Corruption (reapply after it falls off).
10. Maintain Siphon Life (reapply after it falls off; only with Shadow Vulnerability if you have Improved Shadow Bolt).
11. Maintain Immolate (reapply after it falls off).
12. Cast Shadow Bolt as filler.

AoE Rotation:
- Seed of Corruption for multi-target packs (TTD-gated).

Curse Priority:
- Curse of Doom: Primary curse for long fights (60 second duration)
- Curse of Agony: Use if boss will die in <60 seconds
- Curse of the Elements: Use if assigned by raid leader (magic vulnerability debuff)
- Curse of Recklessness: Use if assigned by raid leader (armor reduction, removes fear)
- Note: Only one curse can be active per target - coordinate with other Warlocks

DoT Management:
- Reapply DoTs only after they fall off.
- Siphon Life: only when Shadow Vulnerability (ISB) is active if you have Improved Shadow Bolt.
- Corruption: 12 second duration
- Siphon Life: Duration varies by rank
- Immolate: 15 second duration

Mana Management:
- Life Tap: Converts health to mana - use when low on mana
- Ideally use Life Tap while moving to avoid DPS loss
- Fel Armor: Provides passive mana regeneration
- Summon Imp: Provides passive mana regeneration (if talented)

Movement:
- Shadowburn: Instant cast shadow damage - use while moving
- Death Coil: Instant cast fear with damage - use while moving
- Life Tap: Can be used while moving without DPS loss

Pet:
- Summon Succubus: Preferred pet for Affliction Warlocks
- Fall back to Imp if Succubus is unavailable
- Keep pet alive and on target at all times

Raid Coordination:
- Coordinate curses with other Warlocks - only one curse per target
- May be assigned Curse of the Elements or Curse of Recklessness
- Usually 1-2 Affliction Warlocks per raid for curse coverage and DoT damage
    ]],
    author = "Rakizi",
}

-- Demonology Rotation
local demonologyRotation = {
    -- Core identification
    name = "Demonology",
    specIndex = 2,
    class = "WARLOCK",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    lastModified = "12/30/2025",
    rotationString = [[
    -- NOTE: Use LOWEST-RANK IDs with ResolveEffectiveSpellId/*Resolved helpers.
    NAG:EnableAssignmentsGate()

    -- Maintain Fel Armor
    or (NAG:SpellCanCastResolved(28176) and (not NAG:AuraIsActiveResolved(28176)))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(28176))
    -- Maintain Pet: Felguard if known, otherwise Succubus
    or ((not NAG:PetIsActive()) and NAG:SpellIsKnown(30146) and NAG:SpellCanCastResolved(30146))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(30146))
    or ((not NAG:PetIsActive()) and NAG:SpellCanCastResolved(712))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(712))
    -- Pet check: warn if pet is not attacking while in combat
    or (NAG:PetIsActive() and NAG:InCombat() and NAG:UnitExists("target")
        and ((not NAG:UnitExists("pettarget")) or (not NAG:InCombat("pet"))))
        and NAG:ShowCustomOverlay("Pet Not Attacking")

    -- Execute: Shadowburn (shard spender)
    -- Only if a Shadow Bolt won't land in time
    or (NAG:IsExecutePhase(20) and (NAG:CurrentSoulShards() >= 1) and NAG:SpellCanCastResolved(17877)
        and (NAG:RemainingTime() < (NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(686)) + NAG:SpellTravelTime(NAG:ResolveEffectiveSpellId(686)))))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(17877))

    -- Soulshatter when threat is high (group only, shards required)
    or (NAG:InCombat() and (GetNumGroupMembers() > 0) and (NAG:CurrentSoulShards() >= 1)
        and SOULSHATTER_THREAT_VALUE_BASELINE and (NAG:UnitThreatValue() >= SOULSHATTER_THREAT_VALUE_BASELINE)
        and (NAG:UnitThreatPercent() >= 90) and NAG:SpellCanCastResolved(29858))
        and NAG:CastWithOverlay(NAG:ResolveEffectiveSpellId(29858), "SHATTER", NAG.SPELL_POSITIONS.LEFT)

    -- Movement: Death Coil (only when moving and in combat; otherwise filler is preferred)
    or (NAG:InCombat() and NAG:UnitIsMoving() and NAG:SpellCanCastResolved(6789))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(6789), nil, NAG.SPELL_POSITIONS.AOE)

    -- Mana: Life Tap when needed (health-safe, ideally while moving)
    or ((NAG:UnitIsMoving() or NAG:CurrentManaPercent() < 0.20)
        and (NAG:CurrentManaPercent() < 0.70)
        and (NAG:CurrentHealthPercent() >= 0.50)
        and NAG:SpellCanCastResolved(1454))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(1454), nil, NAG.SPELL_POSITIONS.RIGHT)

    -- AoE: Seed of Corruption on packs that live long enough
    -- AoE: Seed of Corruption on packs that live long enough
    or ((NAG:NumberTargetsWithTTD(9, 30) >= 2) and (not NAG:DotIsActiveResolved(27243)) and NAG:SpellCanCastResolved(27243))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(27243),  nil, NAG.SPELL_POSITIONS.PRIMARY)
    -- Utility curses (assignment opt-in only; priority Reck -> Elements -> Weak -> Tongues)
    or ((GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("curse_of_recklessness")
        and NAG:ShouldUseCurseOfRecklessness()
        and (not NAG:IsSpellBlacklisted(704)) and (not NAG:DotIsActiveGlobal(704))
        and NAG:SpellCanCastResolved(704))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(704))
    or ((GetNumGroupMembers() > 0) and (not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and NAG:IsAssignmentEnabled("curse_of_elements")
        and (not NAG:IsSpellBlacklisted(1490)) and (not NAG:DotIsActiveGlobal(1490))
        and NAG:SpellCanCastResolved(1490))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(1490))
    or ((GetNumGroupMembers() > 0) and (not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and NAG:IsAssignmentEnabled("curse_of_weakness")
        and (not NAG:IsSpellBlacklisted(702)) and (not NAG:DotIsActiveGlobal(702))
        and NAG:SpellCanCastResolved(702))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(702))
    or ((GetNumGroupMembers() > 0) and (not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and NAG:IsAssignmentEnabled("curse_of_tongues")
        and (not NAG:IsSpellBlacklisted(1714)) and (not NAG:DotIsActiveGlobal(1714))
        and NAG:SpellCanCastResolved(1714))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(1714))

    -- Curse of Agony (22-70s) - only if no utility assignment is enabled
    or ((not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and (not NAG:IsAssignmentEnabled("curse_of_tongues"))
        and (NAG:RemainingTime() >= 22) and (NAG:RemainingTime() <= 70)
        and (not (NAG:DotIsActiveResolved(603) or NAG:DotIsActiveResolved(980) or NAG:DotIsActiveResolved(1490) or NAG:DotIsActiveResolved(704) or NAG:DotIsActiveResolved(17862) or NAG:DotIsActiveResolved(702) or NAG:DotIsActiveResolved(1714)))
        and (not NAG:DotIsActiveGlobal(980))
        and ((not NAG:DotIsActiveResolved(980)) or (NAG:DotRemainingTimeResolved(980) <= (NAG:GCDTimeValue() + 0.10)))
        and NAG:SpellCanCastResolved(980))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(980))

    -- Curse of Doom with Amplify Curse (>70s) - only if no utility assignment is enabled
    or ((not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and (not NAG:IsAssignmentEnabled("curse_of_tongues"))
        and (NAG:RemainingTime() > 70)
        and (not (NAG:DotIsActiveResolved(603) or NAG:DotIsActiveResolved(980) or NAG:DotIsActiveResolved(1490) or NAG:DotIsActiveResolved(704) or NAG:DotIsActiveResolved(17862) or NAG:DotIsActiveResolved(702) or NAG:DotIsActiveResolved(1714)))
        and (not NAG:DotIsActiveGlobal(603))
        and ((not NAG:DotIsActiveResolved(603)) or (NAG:DotRemainingTimeResolved(603) <= (NAG:GCDTimeValue() + 0.10)))
        and NAG:SpellCanCastResolved(603)
        and NAG:AuraIsActiveResolved(18288))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(603))

    -- Amplify Curse before Curse of Doom (>70s) - only if no utility assignment is enabled
    or ((not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and (not NAG:IsAssignmentEnabled("curse_of_tongues"))
        and (NAG:RemainingTime() > 70)
        and (not (NAG:DotIsActiveResolved(603) or NAG:DotIsActiveResolved(980) or NAG:DotIsActiveResolved(1490) or NAG:DotIsActiveResolved(704) or NAG:DotIsActiveResolved(17862) or NAG:DotIsActiveResolved(702) or NAG:DotIsActiveResolved(1714)))
        and (not NAG:DotIsActiveGlobal(603))
        and ((not NAG:DotIsActiveResolved(603)) or (NAG:DotRemainingTimeResolved(603) <= (NAG:GCDTimeValue() + 0.10)))
        and NAG:SpellCanCastResolved(603)
        and NAG:SpellCanCastResolved(18288)
        and (not NAG:AuraIsActiveResolved(18288)))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(18288))

    -- Curse of Doom without Amplify Curse (>70s) - only if no utility assignment is enabled
    or ((not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and (not NAG:IsAssignmentEnabled("curse_of_tongues"))
        and (NAG:RemainingTime() > 70)
        and (not (NAG:DotIsActiveResolved(603) or NAG:DotIsActiveResolved(980) or NAG:DotIsActiveResolved(1490) or NAG:DotIsActiveResolved(704) or NAG:DotIsActiveResolved(17862) or NAG:DotIsActiveResolved(702) or NAG:DotIsActiveResolved(1714)))
        and (not NAG:DotIsActiveGlobal(603))
        and ((not NAG:DotIsActiveResolved(603)) or (NAG:DotRemainingTimeResolved(603) <= (NAG:GCDTimeValue() + 0.10)))
        and NAG:SpellCanCastResolved(603))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(603))

    -- Maintain Corruption
    or (not NAG:DotIsActiveResolved(172))
        and NAG:SpellCanCastResolved(172)
        and NAG:Cast(NAG:ResolveEffectiveSpellId(172))

    -- Maintain Immolate
    or (not NAG:DotIsActiveResolved(348))
        and NAG:SpellCanCastResolved(348)
        and NAG:Cast(NAG:ResolveEffectiveSpellId(348))

    -- Cast Shadow Bolt (main filler)
    or NAG:NotSpamCast(686)
    or (NAG:DotIsActiveResolved(172)
        and (NAG:DotRemainingTimeNowResolved(172) <= ((NAG:UnitCastTimeRemaining("player") > 0)
            and NAG:UnitCastTimeRemaining("player")
            or (NAG:GCDTimeToReady() + NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(686))))))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(172))
    or (NAG:DotIsActiveResolved(348)
        and (NAG:DotRemainingTimeNowResolved(348) <= ((NAG:UnitCastTimeRemaining("player") > 0)
            and NAG:UnitCastTimeRemaining("player")
            or (NAG:GCDTimeToReady() + NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(686))))))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(348))
    or NAG:Cast(686)
    ]],

    -- Tracked IDs for optimization
    spells = {28176, 712, 30146, 603, 980, 172, 348, 686, 17877, 6789, 1454, 27243, 18288, 1490, 704, 29858},
    items = {},
    auras = {28176, 18288, 172, 348, 603, 980}, -- Fel Armor, Amplify Curse, Corruption, Immolate, Curse of Doom, Curse of Agony

    -- Optional metadata
    guide = [[
Demonology Warlock Rotation Guide (TBC)

Core Mechanics:
- Demonology Warlocks are DoT-based DPS casters with strong pet contribution.
- Reapply DoTs only after they fall off.
- Curse choice is fight-length dependent: Doom for long fights, Agony for short fights.
- Coordinate curses: only one curse can be active on a target.
- Life Tap is part of your rotation; use it when mana is low and health is safe.

Rotation Priority (Single Target):
1. If Fel Armor is missing, cast Fel Armor.
2. If pet is missing, summon Felguard (if known) or Succubus.
3. If execute phase and a Shadow Bolt won't land in time, cast Shadowburn.
4. Use Soulshatter in group when threat is high (shards required).
5. If moving and you need an instant, cast Death Coil.
6. If mana is low and health is safe, cast Life Tap (ideally while moving).
7. If target will live <60s and no other curse is active, cast Curse of Agony.
8. If target will live >=60s and no other curse is active, cast Amplify Curse then Curse of Doom.
9. Maintain Corruption (reapply after it falls off).
10. Maintain Immolate (reapply after it falls off).
11. Cast Shadow Bolt as filler.

AoE Rotation:
- Seed of Corruption for multi-target packs (TTD-gated).

Curse Priority:
- Curse of Doom: Primary curse for long fights (60 second duration)
- Curse of Agony: Use if boss will die in <60 seconds
- Curse of the Elements: Use if assigned by raid leader (magic vulnerability debuff)
- Curse of Recklessness: Use if assigned by raid leader (armor reduction, removes fear)
- Note: Only one curse can be active per target - coordinate with other Warlocks

DoT Management:
- Reapply DoTs only after they fall off.
- Corruption: 12 second duration
- Immolate: 15 second duration

Mana Management:
- Life Tap: Converts health to mana - use when low on mana
- Ideally use Life Tap while moving to avoid DPS loss
- Fel Armor: Provides passive mana regeneration
- Demonology talents provide additional mana efficiency

Movement:
- Shadowburn: Instant cast shadow damage - use while moving
- Death Coil: Instant cast fear with damage - use while moving
- Life Tap: Can be used while moving without DPS loss

Pet:
- Summon Succubus: Best pet for Demonology Warlocks
- Provides passive damage boost
- Keep pet alive and on target at all times

Raid Coordination:
- Coordinate curses with other Warlocks - only one curse per target
- May be assigned Curse of the Elements or Curse of Recklessness
- Usually 1-2 Demonology Warlocks per raid for curse coverage and DoT damage
    ]],
    author = "Rakizi",
}

-- Destruction Rotation
local destructionRotation = {
    -- Core identification
    name = "Destruction",
    specIndex = 3,
    class = "WARLOCK",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    lastModified = "12/30/2025",
    rotationString = [[
    -- NOTE: Use LOWEST-RANK IDs with ResolveEffectiveSpellId/*Resolved helpers.
    NAG:EnableAssignmentsGate()

    -- Maintain Fel Armor
    or (NAG:SpellCanCastResolved(28176) and (not NAG:AuraIsActiveResolved(28176)))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(28176))

    -- Demonic Sacrifice (Touch of Shadow or Burning Wish)
    or ((not NAG:AuraIsActiveResolved(18791)) and (not NAG:AuraIsActiveResolved(18789)) and NAG:PetIsActive() and NAG:SpellCanCastResolved(18788))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(18788))

    -- Summon pet for Demonic Sacrifice (Succubus default)
    or ((not NAG:AuraIsActiveResolved(18791)) and (not NAG:AuraIsActiveResolved(18789)) and (not NAG:PetIsActive()) and NAG:SpellCanCastResolved(712))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(712))

    -- Execute: Shadowburn (shard spender)
    -- Only if a Shadow Bolt won't land in time
    or (NAG:IsExecutePhase(20) and (NAG:CurrentSoulShards() >= 1) and NAG:SpellCanCastResolved(17877)
        and (NAG:RemainingTime() < (NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(686)) + NAG:SpellTravelTime(NAG:ResolveEffectiveSpellId(686)))))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(17877))

    -- Soulshatter when threat is high (group only, shards required)
    or (NAG:InCombat() and (GetNumGroupMembers() > 0) and (NAG:CurrentSoulShards() >= 1)
        and SOULSHATTER_THREAT_VALUE_BASELINE and (NAG:UnitThreatValue() >= SOULSHATTER_THREAT_VALUE_BASELINE)
        and (NAG:UnitThreatPercent() >= 90) and NAG:SpellCanCastResolved(29858))
        and NAG:CastWithOverlay(NAG:ResolveEffectiveSpellId(29858), "SHATTER", NAG.SPELL_POSITIONS.LEFT)

    -- Movement: Death Coil (only when moving and in combat; otherwise filler is preferred)
    or (NAG:InCombat() and NAG:UnitIsMoving() and NAG:SpellCanCastResolved(6789))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(6789),  nil, NAG.SPELL_POSITIONS.AOE)

    -- Mana: Life Tap when needed (health-safe, ideally while moving)
    or ((NAG:UnitIsMoving() or NAG:CurrentManaPercent() < 0.20)
        and (NAG:CurrentManaPercent() < 0.70)
        and (NAG:CurrentHealthPercent() >= 0.50)
        and NAG:SpellCanCastResolved(1454))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(1454), nil, NAG.SPELL_POSITIONS.RIGHT)

    -- AoE: Seed of Corruption on packs that live long enough
    or ((NAG:NumberTargetsWithTTD(9, 30) >= 2) and (not NAG:DotIsActiveResolved(27243)) and NAG:SpellCanCastResolved(27243))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(27243),  nil, NAG.SPELL_POSITIONS.PRIMARY)

    -- Utility curses (assignment opt-in only; priority Reck -> Elements -> Weak -> Tongues)
    or ((GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("curse_of_recklessness")
        and NAG:ShouldUseCurseOfRecklessness()
        and (not NAG:IsSpellBlacklisted(704)) and (not NAG:DotIsActiveGlobal(704))
        and NAG:SpellCanCastResolved(704))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(704))
    or ((GetNumGroupMembers() > 0) and (not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and NAG:IsAssignmentEnabled("curse_of_elements")
        and (not NAG:IsSpellBlacklisted(1490)) and (not NAG:DotIsActiveGlobal(1490))
        and NAG:SpellCanCastResolved(1490))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(1490))
    or ((GetNumGroupMembers() > 0) and (not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and NAG:IsAssignmentEnabled("curse_of_weakness")
        and (not NAG:IsSpellBlacklisted(702)) and (not NAG:DotIsActiveGlobal(702))
        and NAG:SpellCanCastResolved(702))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(702))
    or ((GetNumGroupMembers() > 0) and (not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and NAG:IsAssignmentEnabled("curse_of_tongues")
        and (not NAG:IsSpellBlacklisted(1714)) and (not NAG:DotIsActiveGlobal(1714))
        and NAG:SpellCanCastResolved(1714))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(1714))

    -- Curse of Agony (22-70s) - only if no utility assignment is enabled
    or ((not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and (not NAG:IsAssignmentEnabled("curse_of_tongues"))
        and (NAG:RemainingTime() >= 22) and (NAG:RemainingTime() <= 70)
        and (not (NAG:DotIsActiveResolved(603) or NAG:DotIsActiveResolved(980) or NAG:DotIsActiveResolved(1490) or NAG:DotIsActiveResolved(704) or NAG:DotIsActiveResolved(17862) or NAG:DotIsActiveResolved(702) or NAG:DotIsActiveResolved(1714)))
        and (not NAG:DotIsActiveGlobal(980))
        and ((not NAG:DotIsActiveResolved(980)) or (NAG:DotRemainingTimeResolved(980) <= (NAG:GCDTimeValue() + 0.10)))
        and NAG:SpellCanCastResolved(980))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(980))

    -- Curse of Doom with Amplify Curse (>70s) - only if no utility assignment is enabled
    or ((not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and (not NAG:IsAssignmentEnabled("curse_of_tongues"))
        and (NAG:RemainingTime() > 70)
        and (not (NAG:DotIsActiveResolved(603) or NAG:DotIsActiveResolved(980) or NAG:DotIsActiveResolved(1490) or NAG:DotIsActiveResolved(704) or NAG:DotIsActiveResolved(17862) or NAG:DotIsActiveResolved(702) or NAG:DotIsActiveResolved(1714)))
        and (not NAG:DotIsActiveGlobal(603))
        and ((not NAG:DotIsActiveResolved(603)) or (NAG:DotRemainingTimeResolved(603) <= (NAG:GCDTimeValue() + 0.10)))
        and NAG:SpellCanCastResolved(603)
        and NAG:AuraIsActiveResolved(18288))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(603))

    -- Amplify Curse before Curse of Doom (>70s) - only if no utility assignment is enabled
    or ((not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and (not NAG:IsAssignmentEnabled("curse_of_tongues"))
        and (NAG:RemainingTime() > 70)
        and (not (NAG:DotIsActiveResolved(603) or NAG:DotIsActiveResolved(980) or NAG:DotIsActiveResolved(1490) or NAG:DotIsActiveResolved(704) or NAG:DotIsActiveResolved(17862) or NAG:DotIsActiveResolved(702) or NAG:DotIsActiveResolved(1714)))
        and (not NAG:DotIsActiveGlobal(603))
        and ((not NAG:DotIsActiveResolved(603)) or (NAG:DotRemainingTimeResolved(603) <= (NAG:GCDTimeValue() + 0.10)))
        and NAG:SpellCanCastResolved(603)
        and NAG:SpellCanCastResolved(18288)
        and (not NAG:AuraIsActiveResolved(18288)))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(18288))

    -- Curse of Doom without Amplify Curse (>70s) - only if no utility assignment is enabled
    or ((not NAG:IsAssignmentEnabled("curse_of_recklessness"))
        and (not NAG:IsAssignmentEnabled("curse_of_elements"))
        and (not NAG:IsAssignmentEnabled("curse_of_weakness"))
        and (not NAG:IsAssignmentEnabled("curse_of_tongues"))
        and (NAG:RemainingTime() > 70)
        and (not (NAG:DotIsActiveResolved(603) or NAG:DotIsActiveResolved(980) or NAG:DotIsActiveResolved(1490) or NAG:DotIsActiveResolved(704) or NAG:DotIsActiveResolved(17862) or NAG:DotIsActiveResolved(702) or NAG:DotIsActiveResolved(1714)))
        and (not NAG:DotIsActiveGlobal(603))
        and ((not NAG:DotIsActiveResolved(603)) or (NAG:DotRemainingTimeResolved(603) <= (NAG:GCDTimeValue() + 0.10)))
        and NAG:SpellCanCastResolved(603))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(603))

    -- Maintain Immolate
    or (not NAG:DotIsActiveResolved(348))
        and NAG:SpellCanCastResolved(348)
        and NAG:Cast(NAG:ResolveEffectiveSpellId(348))

    -- Cast Incinerate if Burning Wish buff active (from Imp sacrifice)
    or (NAG:AuraIsActiveResolved(18789) and NAG:SpellCanCastResolved(29722))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(29722))

    -- Cast Shadow Bolt (main filler, or if Touch of Shadow buff active from Succubus sacrifice)
    or NAG:NotSpamCast(686)
    or (NAG:DotIsActiveResolved(348)
        and (NAG:DotRemainingTimeNowResolved(348) <= ((NAG:UnitCastTimeRemaining("player") > 0)
            and NAG:UnitCastTimeRemaining("player")
            or (NAG:GCDTimeToReady() + NAG:SpellCastTime(NAG:ResolveEffectiveSpellId(686))))))
        and NAG:Cast(NAG:ResolveEffectiveSpellId(348))
    or NAG:Cast(686)
    ]],

    -- Tracked IDs for optimization
    spells = {28176, 18788, 712, 688, 603, 980, 348, 686, 29722, 17877, 6789, 1454, 27243, 18288, 1490, 704, 29858},
    items = {},
    auras = {28176, 18288, 348, 603, 980, 18789, 18791}, -- Fel Armor, Amplify Curse, Immolate, Curse of Doom, Curse of Agony, Burning Wish (Imp sacrifice), Touch of Shadow (Succubus sacrifice)

    -- Optional metadata
    guide = [[
Destruction Warlock Rotation Guide (TBC)

Core Mechanics:
- Destruction Warlocks are burst DPS casters focusing on shadow or fire damage.
- Reapply Immolate only after it falls off.
- Curse choice is fight-length dependent: Doom for long fights, Agony for short fights.
- Main filler depends on which pet was sacrificed: Incinerate if Imp sacrificed (Burning Wish buff), Shadow Bolt if Succubus sacrificed (Touch of Shadow buff) or no sacrifice.
- Mana management is important - use Life Tap when needed, ideally while moving.

Rotation Priority (Single Target):
1. If Fel Armor is missing, cast Fel Armor.
2. If Demonic Sacrifice buffs are missing and pet is active, cast Demonic Sacrifice.
3. If Demonic Sacrifice buffs are missing and no pet is active, summon Succubus.
4. If execute phase and a Shadow Bolt won't land in time, cast Shadowburn.
5. Use Soulshatter in group when threat is high (shards required).
6. If moving and you need an instant, cast Death Coil.
7. If mana is low and health is safe, cast Life Tap (ideally while moving).
8. If target will live <60s and no other curse is active, cast Curse of Agony.
9. If target will live >=60s and no other curse is active, cast Amplify Curse then Curse of Doom.
10. Maintain Immolate (reapply after it falls off).
11. Cast Incinerate if Burning Wish buff active; otherwise Shadow Bolt.

AoE Rotation:
- Seed of Corruption for multi-target packs (TTD-gated).

Demonic Sacrifice:
- Sacrifice Summon Succubus for Touch of Shadow buff (shadow damage boost)
- Sacrifice Summon Imp for Burning Wish buff (fire damage boost)
- Provides significant damage buff for the cost of your pet
- Once sacrificed, you won't have a pet active
- Main filler spell depends on which buff you have: Incinerate for Burning Wish, Shadow Bolt for Touch of Shadow

Curse Priority:
- Curse of Doom: Primary curse for long fights (60 second duration)
- Curse of Agony: Use if boss will die in <60 seconds
- Curse of the Elements: Use if assigned by raid leader (magic vulnerability debuff)
- Curse of Recklessness: Use if assigned by raid leader (armor reduction, removes fear)
- Note: Only one curse can be active per target - coordinate with other Warlocks

DoT Management:
- Reapply Immolate only after it falls off.
- Immolate: 15 second duration

Mana Management:
- Life Tap: Converts health to mana - use when low on mana
- Ideally use Life Tap while moving to avoid DPS loss
- Fel Armor: Provides passive mana regeneration

Movement:
- Shadowburn: Instant cast shadow damage - use while moving
- Death Coil: Instant cast fear with damage - use while moving
- Life Tap: Can be used while moving without DPS loss

Raid Coordination:
- Coordinate curses with other Warlocks - only one curse per target
- May be assigned Curse of the Elements or Curse of Recklessness
- Usually 1-2 Destruction Warlocks per raid for curse coverage and burst damage
    ]],
    author = "Rakizi",
}

--- @class Warlock : ClassBase
local Warlock = NAG:CreateClassModule("WARLOCK", defaults)
if not Warlock then return end

-- Affliction Macros
local afflictionMacros = {
    {
        name = "Amplify Curse + Curse of Doom",
        body = "#showtooltip Curse of Doom\n/cast Amplify Curse\n/cast Curse of Doom"
    },
}

-- Demonology Macros
local demonologyMacros = {
    {
        name = "Amplify Curse + Curse of Doom",
        body = "#showtooltip Curse of Doom\n/cast Amplify Curse\n/cast Curse of Doom"
    },
}

-- Destruction Macros
local destructionMacros = {
    {
        name = "Amplify Curse + Curse of Doom",
        body = "#showtooltip Curse of Doom\n/cast Amplify Curse\n/cast Curse of Doom"
    },
}

function Warlock:SetupClassDefaults()
    -- Attach macros to rotations
    afflictionRotation.macros = afflictionMacros
    demonologyRotation.macros = demonologyMacros
    destructionRotation.macros = destructionMacros
    ns.AddRotationToDefaults(self.defaults, 0, genericRotation)  -- Generic (no talents)
    ns.AddRotationToDefaults(self.defaults, 1, afflictionRotation)  -- Affliction
    ns.AddRotationToDefaults(self.defaults, 2, demonologyRotation)  -- Demonology
    ns.AddRotationToDefaults(self.defaults, 3, destructionRotation)  -- Destruction
end

NAG.Class = Warlock

