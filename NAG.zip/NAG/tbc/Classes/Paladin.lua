local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version

local defaults = ns.InitializeClassDefaults()

-- TBC Paladin spec spell locations
defaults.class.specSpellLocations = {
    [1] = {
        [20572] = NAG.SPELL_POSITIONS.LEFT, -- Blood Fury (Orc Racial)
        [26297] = NAG.SPELL_POSITIONS.LEFT, -- Berserking (Troll Racial)
        [28734] = NAG.SPELL_POSITIONS.LEFT, -- Mana Tap (BE Racial)
        [25046] = NAG.SPELL_POSITIONS.LEFT, -- Arcane Torrent (BE Racial)
    },  -- Holy
    [2] = {
        [20166] = NAG.SPELL_POSITIONS.LEFT, -- Seal of Wisdom
        [2812] = NAG.SPELL_POSITIONS.RIGHT, -- Holy Wrath
        [20572] = NAG.SPELL_POSITIONS.LEFT, -- Blood Fury (Orc Racial)
        [26297] = NAG.SPELL_POSITIONS.LEFT, -- Berserking (Troll Racial)
        [28734] = NAG.SPELL_POSITIONS.LEFT, -- Mana Tap (BE Racial)
        [25046] = NAG.SPELL_POSITIONS.LEFT, -- Arcane Torrent (BE Racial)
    },  -- Protection
    [3] = {
        [20218] = NAG.SPELL_POSITIONS.BELOW,
        [19740] = NAG.SPELL_POSITIONS.BELOW,
        [20572] = NAG.SPELL_POSITIONS.LEFT, -- Blood Fury (Orc Racial)
        [26297] = NAG.SPELL_POSITIONS.LEFT, -- Berserking (Troll Racial)
        [28734] = NAG.SPELL_POSITIONS.LEFT, -- Mana Tap (BE Racial)
        [25046] = NAG.SPELL_POSITIONS.LEFT, -- Arcane Torrent (BE Racial)
   },  -- Retribution
}

-- Class assignments for raid coordination (Protection: judgement selection overrides)
defaults.class.classAssignments = {
    {
        id = "judge_wisdom",
        name = "Judge Wisdom",
        description = "Maintain Judgement of Wisdom on the target (overrides default Prot judgement selection).",
        spellIds = {20355, 20354}, -- Judgement of Wisdom (TBC ranks)
        category = "debuff",
    },
    {
        id = "judge_crusader",
        name = "Judge Crusader",
        description = "Maintain Judgement of the Crusader on the target (overrides default Prot judgement selection).",
        spellIds = {21183}, -- Judgement of the Crusader (debuff id)
        category = "debuff",
    },
}

defaults.char.assignmentToggles = defaults.char.assignmentToggles or {}
if defaults.char.assignmentToggles.judge_wisdom == nil then
    defaults.char.assignmentToggles.judge_wisdom = false
end
if defaults.char.assignmentToggles.judge_crusader == nil then
    defaults.char.assignmentToggles.judge_crusader = false
end

-- Prot-only toggle (UI): never switch into seal twisting rotation
if defaults.char.protNeverSealTwist == nil then
    defaults.char.protNeverSealTwist = false
end

if UnitClassBase('player') ~= "PALADIN" then return end

-- Holy Rotation
local holyRotation = {
    -- Core identification
    name = "Holy",
    specIndex = 1,
    class = "PALADIN",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    rotationString = "NAG:Cast(6603)",
}




-- Retribution Rotation
local protectionRotationSealTwisting = {
    -- Core identification
    name = "Prot Seal Twisting",
    specIndex = 2,
    class = "PALADIN",
    default = true,
    enabled = true,
    prePull = {
--        { time = -31.0, action = "NAG:Cast(48263)" },
--        { time = -30.0, action = "NAG:Cast(49222)" },
--        { time = -7.0, action = "NAG:Cast(42650)" },
--        { time = -1.5, action = "NAG:Cast(57330)" },
--        { time = -1.0, action = "NAG:Cast(76095)" }
    },

    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    rotationString = [[
NAG:EnableAssignmentsGate()
or
-- Rotation switching (anti ping-pong): this fallback guard is mirrored by the Prot->Twist entry guard in the
-- Protection rotation (combat/mana/RF/targets are symmetric). Additional Prot->Twist gates exist (toggle + SoC known).
(not(NAG:InCombat()) or NAG:CurrentManaPercent("player") <= 0.1 or (not NAG:AuraIsActiveResolved(25780)) or (NAG:NumberTargets(5, false) > 2)) and NAG:SelectRotation("Protection")
or NAG:EnableTBCRetBars()
or (NAG:InCombat() and (not NAG:TargetInMeleeRange(5)) and NAG:SpellCanCastResolved(31935)) and NAG:Cast(NAG:ResolveEffectiveSpellId(31935), nil, NAG.SPELL_POSITIONS.LEFT) -- Avenger's Shield at range
or (not NAG:AuraIsActiveResolved(20925)) and NAG:SpellCanCastResolved(20925) and NAG:Cast(NAG:ResolveEffectiveSpellId(20925), nil, NAG.SPELL_POSITIONS.LEFT)
or (NAG:InCombat() and NAG:ProtIsRangedPack(2, 7, 5) and (NAG:TargetMobType(NAG.Types.MobType.Undead) or NAG:TargetMobType(NAG.Types.MobType.Demon)) and NAG:SpellCanCastResolved(2812)) and NAG:Cast(NAG:ResolveEffectiveSpellId(2812), nil, NAG.SPELL_POSITIONS.RIGHT) -- Holy Wrath (Undead/Demon)
or not(NAG:IsActive(20218)) and not(IsMounted()) and NAG:Cast(20218)
or not(NAG:IsActive(19740) or NAG:IsActive(25782) or NAG:IsActive(19977) or NAG:IsActive(19742) or NAG:IsActive(25894) or NAG:IsActive(20217) or NAG:IsActive(25898) or NAG:IsActive(27168) or NAG:IsActive(25899)) and NAG:Cast(19740, nil, NAG.SPELL_POSITIONS.LEFT)


or (NAG:InCombat() and not(NAG:IsAttacking()) and (not NAG:RetTwistIsSoCActive()) and NAG:Cast(NAG:RetTwistGetSoCSealId()))
or (NAG:InCombat() and not(NAG:IsAttacking()) and NAG:RetTwistIsSoCActive() and NAG:RetTwistNowWithOverlay("Startattack\nmacro"))

or ((not NAG:RetTwistIsSoCActive()) and NAG:RetTwistIsSoBActive() and NAG:SpellIsReady(20271) and NAG:Cast(NAG:RetTwistGetSoCSealId(), nil, NAG.SPELL_POSITIONS.AOE))
or ((not NAG:RetTwistIsSoCActive()) and NAG:RetTwistIsSoBActive() and NAG:Cast(20271, nil, nil, nil, "Judge\n+\nSoC"))
or (
    (not NAG:RetTwistIsSoCActive())
    and NAG:RetTwistIsSoBActive()
    and (NAG:RetTwistJudgeSetupWaitTolerance(3, 0.4, 0.05, 0.2, 0.3) > 0)
    and NAG:Cast(20271, NAG:RetTwistJudgeSetupWaitTolerance(3, 0.4, 0.05, 0.2, 0.3), nil, nil, "Judge\n+\nSoC")
)
or (
    (not NAG:RetTwistIsSoCActive())
    and (not (NAG:RetTwistIsSoBActive() and NAG:RetTwistJudgeSetupIsPlanned(3, 0.4, 0.05, 0.2)))
    and NAG:Cast(NAG:RetTwistGetSoCSealId())
)

-- 2) TWIST NOW (in-window): SoC active -> recommend SoB/SoM with overlay "NOW"
or NAG:CanTwist(0.4, 0.1) and NAG:RetTwistIsSoCActive() and(NAG:AuraNumStacks(20055) >= 3 and (NAG:RemainingTime() >= 15 or (NAG:InEncounter() and NAG:RemainingTime() >= 5))) and NAG:RetTwistNowBURST()
or (NAG:CanTwist(0.4, 0.1) and NAG:RetTwistIsSoCActive() and NAG:RetTwistNow())

-- 3) HOLD (div boundary): inside the sensitive region where a new GCD would push past twist window.
-- Show HOLD + show the upcoming twist seal to press.
or NAG:RetTwistIsInHoldRegion(0.4) and (NAG:AuraNumStacks(20055) >= 3 and (NAG:RemainingTime() >= 15 or (NAG:InEncounter() and NAG:RemainingTime() >= 5))) and NAG:RetTwistHoldBURST()
or (
    -- Compute hold region once to avoid 1-tick flicker from multiple AutoTimeToNextAfterGCD() calls.
    NAG:RetTwistIsInHoldRegion(0.4)
    and NAG:RetTwistHold()
)

or (
    (NAG:AutoSwingTime() > 2.2)
    and (NAG:NumberTargets(5, false) >= 2)
    and NAG:TargetInMeleeRange(5)
    and (NAG:CurrentManaPercent() >= 0.4)
    and (NAG:RemainingTime() >= 5)
    and NAG:Cast(26573)
)
or (
     NAG:RetTwistIsSoCActive()
    and (NAG:AutoSwingTime() > 2.2)
    and (NAG:TargetMobType(NAG.Types.MobType.Undead) or NAG:TargetMobType(NAG.Types.MobType.Demon))
    and NAG:Cast(879)
)
or (
     NAG:TargetInMeleeRange(5)
    and (NAG:AutoSwingTime() > 2.2)
    and (NAG:CurrentManaPercent() >= 0.3)
    and (NAG:RemainingTime() >= 5)
    and NAG:Cast(26573)
)

-- Wait for AoE Consecration (same conditions as AoE Cons, but CD look-ahead before div)
or (
    (NAG:AutoSwingTime() > 2.2)
    and (NAG:NumberTargets(5, false) >= 2)
    and NAG:TargetInMeleeRange(5)
    and (NAG:CurrentManaPercent() >= 0.4)
    and (NAG:RemainingTime() >= 5)
    and (NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05) > 0)
    and (NAG:SpellTimeToReady(26573) > 0)
    and (NAG:SpellTimeToReady(26573) <= NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05))
    and NAG:Cast(26573, 3)
)

-- Wait for Exorcism (same conditions as Exo, but CD look-ahead before div)
or (
     NAG:RetTwistIsSoCActive()
    and (NAG:AutoSwingTime() > 2.2)
    and (NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05) > 0)
    and (NAG:TargetMobType(NAG.Types.MobType.Undead) or NAG:TargetMobType(NAG.Types.MobType.Demon))
    and (NAG:SpellTimeToReady(879) > 0)
    and (NAG:SpellTimeToReady(879) <= NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05))
    and NAG:Cast(879, 3)
)

-- Wait for ST Consecration (same conditions as ST Cons, but CD look-ahead before div)
or (
     NAG:TargetInMeleeRange(5)
    and (NAG:AutoSwingTime() > 2.2)
    and (NAG:CurrentManaPercent() >= 0.3)
    and (NAG:RemainingTime() >= 5)
    and (NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05) > 0)
    and (NAG:SpellTimeToReady(26573) > 0)
    and (NAG:SpellTimeToReady(26573) <= NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05))
    and NAG:Cast(26573, 3)
)

-- Otherwise, if we're before div and none of the above will happen in time, start HOLD early for twist (uses the existing HOLD swipe UX on the twist seal).
or NAG:RetTwistIsSoCActive() and (NAG:AuraNumStacks(20055) >= 3 and (NAG:RemainingTime() >= 15 or (NAG:InEncounter() and NAG:RemainingTime() >= 5))) and NAG:RetTwistHoldBURST()
or (
    NAG:RetTwistIsSoCActive()
    and NAG:RetTwistHold()
)

or ((NAG:TargetMobType(NAG.Types.MobType.Undead) or NAG:TargetMobType(NAG.Types.MobType.Demon)) and NAG:Cast(879))
or NAG:TargetInMeleeRange(5)  and (NAG:RemainingTime() >= 5) and NAG:Cast(26573)
or NAG:Cast(20271, 2, nil, nil, "Judge\n+\nSoC")

]],
}




-- Protection Rotation
local protectionRotation = {
    -- Core identification
    name = "Protection",
    specIndex = 2,
    class = "PALADIN",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    rotationString = [[
NAG:EnableAssignmentsGate()
or
-- Maintain Righteous Fury (always)
(not NAG:AuraIsActiveResolved(25780)) and NAG:SpellCanCastResolved(25780) and NAG:Cast(NAG:ResolveEffectiveSpellId(25780))
or
-- Aura management (out of combat)
((not NAG:InCombat()) and NAG:SpellIsKnown(20218) and (not NAG:IsActive(20218)) and (not IsMounted())) and NAG:Cast(20218, nil, NAG.SPELL_POSITIONS.BELOW) -- Sanctity Aura
or
((not NAG:InCombat()) and (not IsMounted()) and (not NAG:ProtHasNonCrusaderAuraActive()) and (NAG:ProtGetFallbackAuraSpellId() ~= nil)) and NAG:Cast(NAG:ProtGetFallbackAuraSpellId(), nil, NAG.SPELL_POSITIONS.BELOW) -- Any non-Crusader aura is fine
or
-- Blessings (out of combat): Sanctuary > Kings > Wisdom
-- If ANY blessing is already active, do not prompt for another blessing.
((not NAG:InCombat()) and (not NAG:ProtHasAnyBlessing()) and (not NAG:ProtHasBlessingSanctuary()) and NAG:SpellCanCastResolved(20911)) and NAG:Cast(NAG:ResolveEffectiveSpellId(20911), nil, NAG.SPELL_POSITIONS.LEFT) -- Blessing of Sanctuary
or
((not NAG:InCombat()) and (not NAG:ProtHasAnyBlessing()) and (not NAG:ProtHasBlessingKings()) and NAG:SpellCanCastResolved(20217)) and NAG:Cast(NAG:ResolveEffectiveSpellId(20217), nil, NAG.SPELL_POSITIONS.LEFT) -- Blessing of Kings
or
((not NAG:InCombat()) and (not NAG:ProtHasAnyBlessing()) and (not NAG:ProtHasBlessingWisdom()) and NAG:SpellCanCastResolved(19742)) and NAG:Cast(NAG:ResolveEffectiveSpellId(19742), nil, NAG.SPELL_POSITIONS.LEFT) -- Blessing of Wisdom
or
-- Maintain assigned seal (Wisdom or Crusader)
-- We only need the matching seal up when we intend to (re)apply its judgement debuff,
-- and only if the target's TTD is confidently > 10s (avoid wasting GCDs on short-lived targets).
((NAG:ProtChooseJudgement() == "crusader") and (not NAG:ProtHasJudgementOfCrusader()) and (not NAG:RetTwistIsSoCrusaderActive()) and (NAG:RemainingTime() > 10 and NAG:RemainingTime() < 7777) and NAG:SpellCanCast(NAG:RetTwistGetSoCrusaderSealId())) and NAG:Cast(NAG:RetTwistGetSoCrusaderSealId(), nil, NAG.SPELL_POSITIONS.LEFT) -- Seal of the Crusader
or
((NAG:ProtChooseJudgement() == "wisdom") and (not NAG:ProtHasJudgementOfWisdom("target")) and (not NAG:AuraIsActiveResolved(20166)) and (NAG:RemainingTime() > 10 and NAG:RemainingTime() < 7777) and NAG:SpellCanCastResolved(20166)) and NAG:Cast(NAG:ResolveEffectiveSpellId(20166), nil, NAG.SPELL_POSITIONS.LEFT) -- Seal of Wisdom
or
-- Maintain Holy Shield (always keep up; also pre-pull)
(not NAG:AuraIsActiveResolved(20925)) and NAG:SpellCanCastResolved(20925) and NAG:Cast(NAG:ResolveEffectiveSpellId(20925))
or
-- Pre-pull opener: Avenger's Shield after Holy Shield is up (at range)
((not NAG:InCombat()) and NAG:AuraIsActiveResolved(20925) and (not NAG:TargetInMeleeRange(5)) and NAG:SpellCanCastResolved(31935)) and NAG:Cast(NAG:ResolveEffectiveSpellId(31935)) -- Avenger's Shield
or
-- In combat: Avenger's Shield at range (no melee target within 5y)
(NAG:InCombat() and (not NAG:TargetInMeleeRange(5)) and NAG:SpellCanCastResolved(31935)) and NAG:Cast(NAG:ResolveEffectiveSpellId(31935)) -- Avenger's Shield
or
-- In combat AoE (melee): Consecration on the pack
(NAG:InCombat() and (NAG:NumberTargets(5, false) >= 2) and NAG:TargetInMeleeRange(5) and NAG:SpellCanCastResolved(20116)) and NAG:Cast(NAG:ResolveEffectiveSpellId(20116)) -- Consecration
or
-- In combat AoE (ranged pack): Holy Wrath vs Undead/Demon (always RIGHT)
(NAG:InCombat() and NAG:ProtIsRangedPack(2, 7, 5) and (NAG:TargetMobType(NAG.Types.MobType.Undead) or NAG:TargetMobType(NAG.Types.MobType.Demon)) and NAG:SpellCanCastResolved(2812)) and NAG:Cast(NAG:ResolveEffectiveSpellId(2812), nil, NAG.SPELL_POSITIONS.RIGHT) -- Holy Wrath
or
-- In combat: Judge chosen seal if the assigned judgement debuff is missing (only when the matching seal is up)
((NAG:ProtChooseJudgement() == "crusader") and (not NAG:ProtHasJudgementOfCrusader()) and NAG:RetTwistIsSoCrusaderActive() and NAG:SpellIsReady(20271)) and NAG:Cast(20271) -- Judgement (Crusader)
or
((NAG:ProtChooseJudgement() == "wisdom") and (not NAG:ProtHasJudgementOfWisdom("target")) and NAG:AuraIsActiveResolved(20166) and NAG:SpellIsReady(20271)) and NAG:Cast(20271) -- Judgement (Wisdom)
or
-- Exorcism vs Undead/Demon
((NAG:TargetMobType(NAG.Types.MobType.Undead) or NAG:TargetMobType(NAG.Types.MobType.Demon)) and NAG:SpellCanCastResolved(879)) and NAG:Cast(NAG:ResolveEffectiveSpellId(879)) -- Exorcism
or
-- Single-target Consecration (melee range)
(NAG:InCombat() and NAG:TargetInMeleeRange(5) and NAG:SpellCanCastResolved(20116)) and NAG:Cast(NAG:ResolveEffectiveSpellId(20116)) -- Consecration
-- if SoC or SoB or seal of the righteous are active on the user, cast judgement
or (NAG:RetTwistIsSoCActive() or NAG:RetTwistIsSoBActive() or NAG:AuraIsActiveResolved(20166)) and NAG:SpellIsReady(20271) and NAG:Cast(20271)
-- if mana is below 20% cast Seal of Wisdom
or (NAG:CurrentManaPercent("player") <= 0.2) and NAG:Cast(NAG:ResolveEffectiveSpellId(20166))
-- if SoC is known and aura is not active and (seal of wisdom is not active or mana is above 21%), cast SoC
or (NAG:SpellIsKnown(NAG:RetTwistGetSoCSealId()) and (not NAG:RetTwistIsSoCActive()) and ((not NAG:AuraIsActiveResolved(20166)) or (NAG:CurrentManaPercent("player") > 0.2))) and NAG:Cast(NAG:RetTwistGetSoCSealId())
-- if SoB is known and aura is not active and SoC is not active, cast SoB
or (NAG:SpellIsKnown(NAG:RetTwistGetTwistSealId()) and (not NAG:RetTwistIsSoBActive()) and (not NAG:RetTwistIsSoCActive()) and ((not NAG:AuraIsActiveResolved(20166)) or (NAG:CurrentManaPercent("player") > 0.2))) and NAG:Cast(NAG:RetTwistGetTwistSealId())

or
-- Swap to Prot seal twisting when available (explicit action, after core maintenance)
-- Use same guards as Prot Seal Twisting fallback to avoid ping-pong between rotations.
-- Symmetric gates: in-combat, mana > 10%, Righteous Fury active, targets <= 2.
(
    NAG:InCombat()
    and (not NAG:ProtNeverSealTwistEnabled())
    and NAG:SpellIsKnown(NAG:RetTwistGetSoCSealId())
    and (NAG:CurrentManaPercent("player") > 0.1)
    and NAG:AuraIsActiveResolved(25780)
    and (NAG:NumberTargets(5, false) <= 2)
    and NAG:SelectRotation("Prot Seal Twisting")
)
-- Lookahead (tolerance): Holy Shield, Consecration, Judgement - show whichever will be ready first (within 4s)
-- Judgement only when a judgeable seal is up (SoC/SoB/SoW, or SoW/SoCrusader up but not judged on target)
-- Not in melee: Holy Shield vs Judgement (if seal up)
or ((not NAG:TargetInMeleeRange(5)) and NAG:SpellTimeToReadyResolved(20925) >= 0 and NAG:SpellTimeToReadyResolved(20925) <= 4 and NAG:SpellTimeToReadyResolved(20925) <= (((NAG:RetTwistIsSoCActive() or NAG:RetTwistIsSoBActive() or NAG:AuraIsActiveResolved(20166) or (NAG:RetTwistIsSoCrusaderActive() and (not NAG:ProtHasJudgementOfCrusader())) or (NAG:AuraIsActiveResolved(20166) and (not NAG:ProtHasJudgementOfWisdom("target")))) and NAG:SpellTimeToReadyResolved(20271) >= 0 and NAG:SpellTimeToReadyResolved(20271)) or 999)) and NAG:Cast(NAG:ResolveEffectiveSpellId(20925), 4)
or ((not NAG:TargetInMeleeRange(5)) and (NAG:RetTwistIsSoCActive() or NAG:RetTwistIsSoBActive() or NAG:AuraIsActiveResolved(20166) or (NAG:RetTwistIsSoCrusaderActive() and (not NAG:ProtHasJudgementOfCrusader())) or (NAG:AuraIsActiveResolved(20166) and (not NAG:ProtHasJudgementOfWisdom("target")))) and NAG:SpellTimeToReadyResolved(20271) >= 0 and NAG:SpellTimeToReadyResolved(20271) <= 4 and NAG:SpellTimeToReadyResolved(20271) <= (NAG:SpellTimeToReadyResolved(20925) >= 0 and NAG:SpellTimeToReadyResolved(20925) or 999)) and NAG:Cast(20271, 4)
-- In melee: Holy Shield vs Consecration vs Judgement (if seal up)
or (NAG:TargetInMeleeRange(5) and NAG:SpellTimeToReadyResolved(20925) >= 0 and NAG:SpellTimeToReadyResolved(20925) <= 4 and NAG:SpellTimeToReadyResolved(20925) <= (NAG:SpellTimeToReadyResolved(20116) >= 0 and NAG:SpellTimeToReadyResolved(20116) or 999) and NAG:SpellTimeToReadyResolved(20925) <= (((NAG:RetTwistIsSoCActive() or NAG:RetTwistIsSoBActive() or NAG:AuraIsActiveResolved(20166) or (NAG:RetTwistIsSoCrusaderActive() and (not NAG:ProtHasJudgementOfCrusader())) or (NAG:AuraIsActiveResolved(20166) and (not NAG:ProtHasJudgementOfWisdom("target")))) and NAG:SpellTimeToReadyResolved(20271) >= 0 and NAG:SpellTimeToReadyResolved(20271)) or 999)) and NAG:Cast(NAG:ResolveEffectiveSpellId(20925), 4)
or (NAG:TargetInMeleeRange(5) and NAG:SpellTimeToReadyResolved(20116) >= 0 and NAG:SpellTimeToReadyResolved(20116) <= 4 and NAG:SpellTimeToReadyResolved(20116) <= (NAG:SpellTimeToReadyResolved(20925) >= 0 and NAG:SpellTimeToReadyResolved(20925) or 999) and NAG:SpellTimeToReadyResolved(20116) <= (((NAG:RetTwistIsSoCActive() or NAG:RetTwistIsSoBActive() or NAG:AuraIsActiveResolved(20166) or (NAG:RetTwistIsSoCrusaderActive() and (not NAG:ProtHasJudgementOfCrusader())) or (NAG:AuraIsActiveResolved(20166) and (not NAG:ProtHasJudgementOfWisdom("target")))) and NAG:SpellTimeToReadyResolved(20271) >= 0 and NAG:SpellTimeToReadyResolved(20271)) or 999)) and NAG:Cast(NAG:ResolveEffectiveSpellId(20116), 4)
or (NAG:TargetInMeleeRange(5) and (NAG:RetTwistIsSoCActive() or NAG:RetTwistIsSoBActive() or NAG:AuraIsActiveResolved(20166) or (NAG:RetTwistIsSoCrusaderActive() and (not NAG:ProtHasJudgementOfCrusader())) or (NAG:AuraIsActiveResolved(20166) and (not NAG:ProtHasJudgementOfWisdom("target")))) and NAG:SpellTimeToReadyResolved(20271) >= 0 and NAG:SpellTimeToReadyResolved(20271) <= 4 and NAG:SpellTimeToReadyResolved(20271) <= (NAG:SpellTimeToReadyResolved(20925) >= 0 and NAG:SpellTimeToReadyResolved(20925) or 999) and NAG:SpellTimeToReadyResolved(20271) <= (NAG:SpellTimeToReadyResolved(20116) >= 0 and NAG:SpellTimeToReadyResolved(20116) or 999)) and NAG:Cast(20271, 4)

    ]],
    guide = [[
Protection Paladin Rotation Guide (TBC)

Core Mechanics:
- Righteous Fury must be active to generate tank threat.
- Holy Shield is your core mitigation/threat tool; keep it up.
- Consecration is your main AoE threat tool but is mana intensive.
- Seals are situational: Righteousness for short fights, Vengeance for long fights, Wisdom for mana sustain.

Rotation Priority (Single Target):
1. Maintain Righteous Fury (always on while tanking).
2. Maintain Holy Shield (refresh on cooldown).
3. Use Avenger's Shield on pull or when safe to cast for burst threat.
4. Judgement on cooldown with your chosen seal.
5. Consecration when you have mana, can stand still, and mobs are in melee range.
6. Auto-attack with Seal active (Righteousness or Vengeance).
7. Swap to Seal of Wisdom if mana is becoming a limiting factor.

AoE Rotation:
1. Holy Shield on cooldown (more blocks = more threat).
2. Consecration under the pack (primary AoE threat; requires melee range).
3. Avenger's Shield for ranged pulls or extra snap threat.
4. Holy Wrath on Undead/Demon packs.
5. Judgement on the primary target to stabilize threat.

Mana Management:
- Consecration is expensive; skip or down-rank if mana is tight.
- Seal/Judgement of Wisdom is the primary tool for sustained mana.
- Blessing of Sanctuary reduces damage and provides extra threat on blocks.

Cooldowns and Defensive Tools:
- Ardent Defender is passive in TBC (no button to press).
- Divine Protection is an emergency physical immunity with Forbearance.
- Lay on Hands and potions are emergency options; coordinate with healers.

Raid Utility:
- Blessings and Auras are raid responsibilities; coordinate assignments.
- Righteous Fury + Holy Shield + Consecration make you the premier AoE tank.
    ]],
}

-- Retribution Rotation
local retributionRotation = {
    -- Core identification
    name = "Retribution",
    specIndex = 3,
    class = "PALADIN",
    default = true,
    enabled = true,
    prePull = {
--        { time = -31.0, action = "NAG:Cast(48263)" },
--        { time = -30.0, action = "NAG:Cast(49222)" },
--        { time = -7.0, action = "NAG:Cast(42650)" },
--        { time = -1.5, action = "NAG:Cast(57330)" },
--        { time = -1.0, action = "NAG:Cast(76095)" }
    },

    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    rotationString = [[
NAG:EnableTBCRetBars()
or not(NAG:IsActive(20218)) and not(IsMounted()) and NAG:Cast(20218)
or not(NAG:IsActive(19740) or NAG:IsActive(25782) or NAG:IsActive(19977) or NAG:IsActive(19742) or NAG:IsActive(25894) or NAG:IsActive(20217) or NAG:IsActive(25898) or NAG:IsActive(27168) or NAG:IsActive(25899)) and NAG:Cast(19740)

-- ============================ SELF-APPLY JUDGEMENT OF THE CRUSADER ============================
-- Only active when: setting enabled AND (≤2 paladins in group OR assignment forced).
-- Only triggers at range (early pull phase). After judging, existing rotation handles stop attack -> SoC -> start.

-- Step 1: At range, apply Seal of Crusader (if debuff not on target and seal not active)
or (
    NAG:RetTwistShouldSelfApplyImpSoC()
    and not(NAG:InCombat())
    and (not NAG:TargetInMeleeRange(1))
    and (not NAG:RetTwistHasJudgementOfCrusaderDebuff())
    and (not NAG:RetTwistIsSoCrusaderActive())
    and NAG:SpellCanCast(NAG:RetTwistGetSoCrusaderSealId())
    and NAG:Cast(NAG:RetTwistGetSoCrusaderSealId(), nil, nil, nil, "")
)

-- Step 2: At range, Judge Seal of Crusader (if seal active and debuff not on target)
or (
    NAG:RetTwistShouldSelfApplyImpSoC()
    and not(NAG:InCombat())
    and (not NAG:TargetInMeleeRange(1))
    and (not NAG:RetTwistHasJudgementOfCrusaderDebuff())
    and NAG:RetTwistIsSoCrusaderActive()
    and NAG:SpellIsReady(20271)
    and (NAG:Cast(NAG:RetTwistGetSoCSealId(), nil, NAG.SPELL_POSITIONS.AOE) or true)
    and NAG:Cast(20271, nil, nil, nil, "Judge + SoC\n and STOP Attack")
)
-- After judging, the existing rotation handles: don't attack from distance -> apply SoC -> start attack

-- ============================ PRE-COMBAT SEAL SETUP (DEFAULT) ============================
or ((not NAG:InCombat()) and (not NAG:RetTwistIsSoCActive()) and NAG:Cast(NAG:RetTwistGetSoCSealId()))
or (not NAG:InCombat()) and NAG:IsAttacking() and not(NAG:TargetInMeleeRange(1)) and NAG:CastWithOverlay(6603, "Don't start attacking\nfrom distance")
or ((not NAG:InCombat()) and NAG:RetTwistIsSoCActive() and NAG:RetTwistNowWithOverlay("Startattack\nmacro"))
--or UnitName("target") ~= "Dummy" and NAG:Cast(27173, 10)
-- Debug: print current swing state + projected state at GCD end (spam-friendly for slow-mo review).
-- Returns false so it does not affect the chosen recommendation.
--or (NAG:InCombat() and NAG:RetTwistDebugTick())

or (NAG:InCombat() and not(NAG:IsAttacking()) and (not NAG:RetTwistIsSoCActive()) and NAG:Cast(NAG:RetTwistGetSoCSealId()))
or (NAG:InCombat() and not(NAG:IsAttacking()) and NAG:RetTwistIsSoCActive() and NAG:RetTwistNowWithOverlay("Startattack\nmacro"))

-- 1) CS OVERRIDE (WA "CS delay analyzer"): If holding/twisting would delay CS beyond the configured max, force CS as the main recommendation.
or (
    NAG:RetTwistShouldForceCrusaderStrike(1.7, 0.1, 0.4)
    and NAG:Cast(35395, 2)
)

-- If SoC is NOT active, we should still be allowed to press CS (CS does not require a seal).
-- This prevents "SoC first, then CS" moments caused by SoC-prereq clauses.
or ((not NAG:RetTwistIsSoCActive()) and NAG:Cast(35395, 0.1))

or ((not NAG:RetTwistIsSoCActive()) and NAG:RetTwistIsSoBActive() and NAG:SpellIsReady(20271) and NAG:Cast(NAG:RetTwistGetSoCSealId(), nil, NAG.SPELL_POSITIONS.AOE))
or ((not NAG:RetTwistIsSoCActive()) and NAG:RetTwistIsSoBActive() and NAG:Cast(20271, nil, nil, nil, "Judge\n+\nSoC"))
or (
    (not NAG:RetTwistIsSoCActive())
    and NAG:RetTwistIsSoBActive()
    and (NAG:RetTwistJudgeSetupWaitTolerance(3, 0.4, 0.05, 0.2, 0.3) > 0)
    and NAG:Cast(20271, NAG:RetTwistJudgeSetupWaitTolerance(3, 0.4, 0.05, 0.2, 0.3), nil, nil, "Judge\n+\nSoC")
)
or (
    (not NAG:RetTwistIsSoCActive())
    and (not (NAG:RetTwistIsSoBActive() and NAG:RetTwistJudgeSetupIsPlanned(3, 0.4, 0.05, 0.2)))
    and NAG:Cast(NAG:RetTwistGetSoCSealId())
)

-- 2) TWIST NOW (in-window): SoC active -> recommend SoB/SoM with overlay "NOW"
or NAG:CanTwist(0.4, 0.1) and NAG:RetTwistIsSoCActive() and(NAG:AuraNumStacks(20055) >= 3 and (NAG:RemainingTime() >= 15 or (NAG:InEncounter() and NAG:RemainingTime() >= 5))) and NAG:RetTwistNowBURST()
or (NAG:CanTwist(0.4, 0.1) and NAG:RetTwistIsSoCActive() and NAG:RetTwistNow())

-- 3) HOLD (div boundary): inside the sensitive region where a new GCD would push past twist window.
-- Show HOLD + show the upcoming twist seal to press.
or NAG:RetTwistIsInHoldRegion(0.4) and (NAG:AuraNumStacks(20055) >= 3 and (NAG:RemainingTime() >= 15 or (NAG:InEncounter() and NAG:RemainingTime() >= 5))) and NAG:RetTwistHoldBURST()
or (
    -- Compute hold region once to avoid 1-tick flicker from multiple AutoTimeToNextAfterGCD() calls.
    NAG:RetTwistIsInHoldRegion(0.4)
    and NAG:RetTwistHold()
)

or NAG:Cast(35395)

or (
    (NAG:AutoSwingTime() > 2.2)
    and (NAG:NumberTargets(5, false) >= 2)
    and NAG:TargetInMeleeRange(5)
    and (NAG:CurrentManaPercent() >= 0.4)
    and (NAG:RemainingTime() >= 5)
    and NAG:Cast(26573)
)
or (
     NAG:RetTwistIsSoCActive()
    and (NAG:AutoSwingTime() > 2.2)
    and (NAG:TargetMobType(NAG.Types.MobType.Undead) or NAG:TargetMobType(NAG.Types.MobType.Demon))
    and NAG:Cast(879)
)
or (
     NAG:TargetInMeleeRange(5)
    and (NAG:AutoSwingTime() > 2.2)
    and (NAG:CurrentManaPercent() >= 0.3)
    and (NAG:RemainingTime() >= 5)
    and NAG:Cast(26573)
)

-- Wait for Crusader Strike before div (shows CS early if it will be ready soon enough)
or (
    NAG:InCombat()
    and (NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05) > 0)
    and (NAG:SpellTimeToReady(35395) >= 0)
    and (NAG:SpellTimeToReady(35395) <= NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05))
    and NAG:Cast(35395, 3)
)

-- Wait for AoE Consecration (same conditions as AoE Cons, but CD look-ahead before div)
or (
    (NAG:AutoSwingTime() > 2.2)
    and (NAG:NumberTargets(5, false) >= 2)
    and NAG:TargetInMeleeRange(5)
    and (NAG:CurrentManaPercent() >= 0.4)
    and (NAG:RemainingTime() >= 5)
    and (NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05) > 0)
    and (NAG:SpellTimeToReady(26573) > 0)
    and (NAG:SpellTimeToReady(26573) <= NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05))
    and NAG:Cast(26573, 3)
)

-- Wait for Exorcism (same conditions as Exo, but CD look-ahead before div)
or (
     NAG:RetTwistIsSoCActive()
    and (NAG:AutoSwingTime() > 2.2)
    and (NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05) > 0)
    and (NAG:TargetMobType(NAG.Types.MobType.Undead) or NAG:TargetMobType(NAG.Types.MobType.Demon))
    and (NAG:SpellTimeToReady(879) > 0)
    and (NAG:SpellTimeToReady(879) <= NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05))
    and NAG:Cast(879, 3)
)

-- Wait for ST Consecration (same conditions as ST Cons, but CD look-ahead before div)
or (
     NAG:TargetInMeleeRange(5)
    and (NAG:AutoSwingTime() > 2.2)
    and (NAG:CurrentManaPercent() >= 0.3)
    and (NAG:RemainingTime() >= 5)
    and (NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05) > 0)
    and (NAG:SpellTimeToReady(26573) > 0)
    and (NAG:SpellTimeToReady(26573) <= NAG:RetTwistWaitToleranceBeforeDiv(3, 0.4, 0.05))
    and NAG:Cast(26573, 3)
)

-- Otherwise, if we're before div and none of the above will happen in time, start HOLD early for twist (uses the existing HOLD swipe UX on the twist seal).
or NAG:RetTwistIsSoCActive() and (NAG:AuraNumStacks(20055) >= 3 and (NAG:RemainingTime() >= 15 or (NAG:InEncounter() and NAG:RemainingTime() >= 5))) and NAG:RetTwistHoldBURST()
or (
    NAG:RetTwistIsSoCActive()
    and NAG:RetTwistHold()
)

or ((NAG:TargetMobType(NAG.Types.MobType.Undead) or NAG:TargetMobType(NAG.Types.MobType.Demon)) and NAG:Cast(879))
or NAG:TargetInMeleeRange(5)  and (NAG:RemainingTime() >= 5) and NAG:Cast(26573)
or NAG:Cast(20271, 2, nil, nil, "Judge\n+\nSoC")

]],
}

--- @class Paladin : ClassBase
local Paladin = NAG:CreateClassModule("PALADIN", defaults)
if not Paladin then return end

function Paladin:SetupClassDefaults()
    --ns.AddRotationToDefaults(self.defaults, 1, holyRotation)  -- Holy
    ns.AddRotationToDefaults(self.defaults, 2, protectionRotation)  -- Protection
    ns.AddRotationToDefaults(self.defaults, 2, protectionRotationSealTwisting)  -- Protection
    ns.AddRotationToDefaults(self.defaults, 3, retributionRotation)  -- Retribution
end

NAG.Class = Paladin

