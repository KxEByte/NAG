local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version

local defaults = ns.InitializeClassDefaults()

local combatMacros = {
    {
        name = "Rogue Racial Orc",
        body = "#showtooltip\n/cast Blood Fury(Racial)\n/use Haste Potion\n/use Thistle Tea\n/use 13"
    },
    {
        name = "Rogue Racial Troll",
        body = "#showtooltip\n/cast Berserking(Racial)\n/use Haste Potion\n/use Thistle Tea\n/use 13"
    },
    {
        name = "Rogue Racial",
        body = "#showtooltip\n/use Haste Potion\n/use Thistle Tea\n/use 13"
    },
}

-- ============================ EXPOSE ARMOR / FINISHER GATING ============================

-- ============================ MULTI-TARGET TTD HELPERS ============================

local UnitGUID = _G.UnitGUID
local TTDManager = ns.TTDManager

local _rogueNearbyMinTTD = 0
local function rogueNearbyTTDCustomCheck(unit)
    if not unit or not UnitGUID then
        return false
    end
    if not TTDManager or not TTDManager.GetTTD then
        return false
    end

    local guid = UnitGUID(unit)
    if not guid then
        return false
    end

    local ttd = TTDManager:GetTTD(guid, 3)
    -- Exclude unknown sentinels (e.g., 8888) by requiring < 7777.
    return ttd and (ttd > _rogueNearbyMinTTD) and (ttd < 7777)
end

local _rogueNearbyTTDOpts = { customCheck = rogueNearbyTTDCustomCheck }

--- True if any nearby enemy has a known TTD greater than the threshold.
--- This is used for multi-target “refresh SnD before spending CP” logic.
--- @param minTTD number
--- @param range number
--- @return boolean
function NAG:RogueHasNearbyEnemyKnownTTDGreaterThan(minTTD, range)
    if not TTDManager or not TTDManager.GetEnemyUnitsInRange then
        return false
    end

    local r = tonumber(range) or 8
    if r <= 0 then
        r = 8
    end

    _rogueNearbyMinTTD = tonumber(minTTD) or 12
    local count = TTDManager:GetEnemyUnitsInRange(r, _rogueNearbyTTDOpts) or 0
    return count >= 1
end

-- ============================ RUPTURE TTD GATING ============================

--- Full duration of Rupture by combo points in TBC.
--- 1cp=8s, 2cp=10s, 3cp=12s, 4cp=14s, 5cp=16s.
--- @param comboPoints number
--- @return number
function NAG:RogueRuptureDurationForComboPoints(comboPoints)
    local cp = tonumber(comboPoints) or 0
    if cp < 1 then cp = 1 end
    if cp > 5 then cp = 5 end
    return 6 + (2 * cp)
end

--- True if the current target is expected to live long enough to justify applying Rupture.
--- Uses the target's TTD directly (ignores encounter timer mode) to avoid suggesting Rupture on
--- dying targets even when an encounter timer is running.
---
--- Behavior:
--- - If target is fresh at 100% HP (TTD intentionally unknown), allow Rupture (consistent with prior behavior).
--- - If TTD is known: require TTD >= Rupture duration for current combo points.
--- - If TTD is unknown on a non-fresh target: do not suggest Rupture (conservative).
--- @return boolean
function NAG:RogueTargetTTDLongEnoughForRupture()
    if not UnitGUID or not TTDManager or not TTDManager.GetTTD then
        return true
    end

    local guid = UnitGUID("target")
    if not guid then
        return false
    end

    local UnitHealth = _G.UnitHealth
    local UnitHealthMax = _G.UnitHealthMax
    local hp = UnitHealth and UnitHealth("target") or 0
    local maxHealth = UnitHealthMax and UnitHealthMax("target") or 0

    -- Fresh target at 100% HP reports unknown TTD by design; treat as safe to apply.
    if maxHealth > 0 and hp >= maxHealth then
        return true
    end

    local ttd = TTDManager:GetTTD(guid, 3)
    if not ttd or ttd <= 0 or ttd >= 7777 then
        return false
    end

    local cp = self:CurrentComboPoints() or 0
    local needed = self:RogueRuptureDurationForComboPoints(cp)
    return ttd >= needed
end

--- Returns true if damage finishers should be allowed to proceed with Expose Armor assignment enabled.
--- This prevents "deadlocks" where EA is assigned but not actually due to be applied right now.
--- Logic: block finishers ONLY when Expose Armor is actively due for application; otherwise allow finishers.
--- @return boolean
function NAG:RogueExposeArmorAllowsFinishers()
    if not (GetNumGroupMembers() > 0 and self:IsAssignmentEnabled("expose_armor")) then
        return true
    end

    if (self:DotRemainingTimeResolved(8647) >= 1) then -- Expose Armor debuff
        return true
    end

    if (self:RemainingTime() <= 10) then
        return true
    end

    local exposeDue = (self:DotRemainingTimeResolved(8647) <= 1)
        and (self:AuraRemainingTimeResolved(5171) >= 5) -- Slice and Dice up enough to spare a finisher
        and (self:CurrentComboPoints() >= 5)
        and (
            ((not self:InEncounter()) and self:RemainingTime() >= 10)
            or (self:InEncounter() and self:RemainingTime() >= 3)
        )

    return not exposeDue
end

-- TBC Rogue spec spell locations
defaults.class.specSpellLocations = {
    [1] = { -- Assassination
        [13750] = NAG.SPELL_POSITIONS.LEFT, -- Adrenaline Rush
        [13877] = NAG.SPELL_POSITIONS.LEFT, -- Blade Flurry
        [20572] = NAG.SPELL_POSITIONS.LEFT, -- Blood Fury (Orc Racial)
        [26297] = NAG.SPELL_POSITIONS.LEFT, -- Berserking (Troll Racial)
        [22838] = NAG.SPELL_POSITIONS.LEFT, -- Racial macro (e.g. Berserking)
        [28734] = NAG.SPELL_POSITIONS.LEFT, -- Mana Tap (BE Racial)
        [25046] = NAG.SPELL_POSITIONS.LEFT, -- Arcane Torrent (BE Racial)
    },
    [2] = { -- Combat
        [13750] = NAG.SPELL_POSITIONS.LEFT, -- Adrenaline Rush
        [13877] = NAG.SPELL_POSITIONS.LEFT, -- Blade Flurry
        [20572] = NAG.SPELL_POSITIONS.LEFT, -- Blood Fury (Orc Racial)
        [26297] = NAG.SPELL_POSITIONS.LEFT, -- Berserking (Troll Racial)
        [22838] = NAG.SPELL_POSITIONS.LEFT, -- Racial macro
        [28734] = NAG.SPELL_POSITIONS.LEFT, -- Mana Tap (BE Racial)
        [25046] = NAG.SPELL_POSITIONS.LEFT, -- Arcane Torrent (BE Racial)
    },
    [3] = { -- Subtlety
        [13750] = NAG.SPELL_POSITIONS.LEFT, -- Adrenaline Rush
        [13877] = NAG.SPELL_POSITIONS.LEFT, -- Blade Flurry
        [20572] = NAG.SPELL_POSITIONS.LEFT, -- Blood Fury (Orc Racial)
        [26297] = NAG.SPELL_POSITIONS.LEFT, -- Berserking (Troll Racial)
        [22838] = NAG.SPELL_POSITIONS.LEFT, -- Racial macro
        [28734] = NAG.SPELL_POSITIONS.LEFT, -- Mana Tap (BE Racial)
        [25046] = NAG.SPELL_POSITIONS.LEFT, -- Arcane Torrent (BE Racial)
    },
}

-- Class assignments for raid coordination
defaults.class.classAssignments = {
    {
        id = "expose_armor",
        name = "Expose Armor",
        description = "Apply armor reduction debuff on targets (conflicts with Warrior Sunder Armor)",
        spellIds = {8647, 8649, 8650, 11197, 11198, 26866}, -- All ranks
        category = "debuff",
    },
}

defaults.char.assignmentToggles = defaults.char.assignmentToggles or {}
if defaults.char.assignmentToggles.expose_armor == nil then
    defaults.char.assignmentToggles.expose_armor = false
end
defaults.char.saveEnergyForKicks = false

if UnitClassBase('player') ~= "ROGUE" then return end

-- Generic (0 talent points): low-level abilities before choosing a spec
local genericRotation = {
    name = "Generic",
    specIndex = 0,
    class = "ROGUE",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    rotationString = [[
    (NAG:ComboPoints() >= 4 and NAG:SpellCanCastResolved(2098)) and NAG:Cast(NAG:ResolveEffectiveSpellId(2098))
    or (NAG:SpellCanCastResolved(1752)) and NAG:Cast(NAG:ResolveEffectiveSpellId(1752))
]],
}

-- Assassination Rotation
local assassinationRotation = {
    -- Core identification
    name = "Assassination",
    specIndex = 1,
    class = "ROGUE",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    rotationString = [[
NAG:EnableAssignmentsGate()
or
(not NAG:InCombat()) and (not NAG:RogueHasDeadlyPoisonOH()) and NAG:CastPlaceholderWithOverlay(26967, "OH", NAG.SPELL_POSITIONS.LEFT) -- Deadly Poison VII (OH)
or
(not NAG:InCombat()) and (not NAG:RogueHasInstantPoisonMH()) and (not NAG:HasWindfuryTotemWeaponBuff()) and NAG:CastPlaceholderWithOverlay(8679, "MH", NAG.SPELL_POSITIONS.LEFT) -- Instant Poison VII (MH, skip if Windfury)
or
NAG:StrictSequence("Cold Blood", nil, 14177, 1329) -- Cold Blood
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(5171) and (not NAG:IsActive(51120, "player" )) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(185848) -- Greater Drums of Battle
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(5171) and (not NAG:IsActive(51120, "player" )) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(29529) -- Drums of Battle
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(20572) and NAG:CastWithOverlay(20572, "Racial Macro") -- Orc Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(26297) and NAG:CastWithOverlay(26297, "Racial Macro") -- Troll Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:CastWithOverlay(22838, "Racial Macro")
or
(NAG:AuraRemainingTimeResolved(5171) <= 1) and NAG:CurrentComboPoints() >= 5 and (not NAG:RogueShouldAvoidSnDHolding()) and ((NAG:RemainingTime() >= 9) or (NAG:RemainingTime() < 7777 and NAG:RogueSliceAndDiceFullDuration() >= NAG:RemainingTime())) and NAG:Cast(5171) -- Slice And Dice prefer 5 CP
or
(NAG:AuraRemainingTimeResolved(5171) <= 1) and NAG:CurrentComboPoints() >= 1 and (not NAG:RogueShouldAvoidSnDHolding()) and ((NAG:RemainingTime() >= 9) or (NAG:RemainingTime() < 7777 and NAG:RogueSliceAndDiceFullDuration() >= NAG:RemainingTime())) and NAG:Cast(5171) -- Slice And Dice
or
(NAG:InCombat() and NAG:CurrentComboPoints() >= 1 and (NAG:AuraRemainingTimeResolved(5171, "player") < 3) and (NAG:NumberTargets(8, false) >= 2) and NAG:RogueHasNearbyEnemyKnownTTDGreaterThan(12, 8)) and NAG:Cast(5171) -- Slice And Dice (multi-target: any nearby mob TTD > 12s)
or
(GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("expose_armor")
    and (NAG:DotRemainingTimeResolved(8647) <= 1)
    and NAG:AuraRemainingTimeResolved(5171) >= 5
    and NAG:CurrentComboPoints() >= 5
    and ((not NAG:InEncounter()) and NAG:RemainingTime() >= 10 or (NAG:InEncounter() and NAG:RemainingTime() >= 3))
    and NAG:Cast(8647) -- Expose Armor
or (
    (not ((GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("expose_armor")))
    or (NAG:DotRemainingTimeResolved(8647) >= 1)
    or (NAG:RemainingTime() <= 10)
    or (not (
        (GetNumGroupMembers() > 0)
        and NAG:IsAssignmentEnabled("expose_armor")
        and (NAG:DotRemainingTimeResolved(8647) <= 1)
        and NAG:AuraRemainingTimeResolved(5171) >= 5
        and NAG:CurrentComboPoints() >= 5
        and ((not NAG:InEncounter()) and NAG:RemainingTime() >= 10 or (NAG:InEncounter() and NAG:RemainingTime() >= 3))
    ))
) and (NAG:NumberTargets() == 1 or (not NAG:AuraIsActiveResolved(13877, "player"))) and (NAG:DotRemainingTimeResolved(1943) == 0) and (NAG:AuraRemainingTimeResolved(5171) >= 5 or NAG:RemainingTime() <= 9 or NAG:RogueShouldAvoidSnDHolding()) and (NAG:CurrentComboPoints() >= 3 or (NAG:RemainingTime() < 2 and NAG:CurrentComboPoints() >= 1)) and (NAG:RemainingTime() > 16  and NAG:RemainingTime() < 600) and NAG:RogueTargetTTDLongEnoughForRupture() and NAG:Cast(1943) -- Rupture
or (
    (not ((GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("expose_armor")))
    or (NAG:DotRemainingTimeResolved(8647) >= 1)
    or (NAG:RemainingTime() <= 10)
    or (not (
        (GetNumGroupMembers() > 0)
        and NAG:IsAssignmentEnabled("expose_armor")
        and (NAG:DotRemainingTimeResolved(8647) <= 1)
        and NAG:AuraRemainingTimeResolved(5171) >= 5
        and NAG:CurrentComboPoints() >= 5
        and ((not NAG:InEncounter()) and NAG:RemainingTime() >= 10 or (NAG:InEncounter() and NAG:RemainingTime() >= 3))
    ))
) and (NAG:AuraRemainingTimeResolved(5171) >= 5 or NAG:RemainingTime() <= 9 or NAG:RogueShouldAvoidSnDHolding()) and (NAG:CurrentComboPoints() >= 3 or (NAG:RemainingTime() < 2 and NAG:CurrentComboPoints() >= 1)) and NAG:Cast(2098) -- Eviscerate
or
NAG:AuraIsActiveResolved(27186, "target") and (NAG:DotRemainingTimeResolved(27186) <= 3) and NAG:Cast(5938) -- Deadly Poison and Shiv
or
NAG:SpellIsKnown(28734) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(28734) -- BE Racial Mana Tap
or
NAG:AuraNumStacks(28734) >= 3 and NAG:SpellIsKnown(25046) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(25046) -- BE Racial Arcane Torrent
or
(NAG:CurrentComboPoints() <= 4 or (NAG:CurrentEnergyAtGCD() > 80)) and NAG:Cast(1329) -- Mutilate

    ]],
}

-- Combat Rotation
local combatRotation = {
    -- Core identification
    name = "Combat",
    specIndex = 2,
    class = "ROGUE",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    lastModified = "12/10/2025",
    author = "@horalius",
    macros = combatMacros,
    enableSmartSwitching = true,
    rotationString = [[
NAG:EnableAssignmentsGate()
or
(not NAG:InCombat()) and (not NAG:RogueHasDeadlyPoisonOH()) and NAG:CastPlaceholderWithOverlay(26967, "OH", NAG.SPELL_POSITIONS.LEFT) -- Deadly Poison VII (OH)
or
(not NAG:InCombat()) and (not NAG:RogueHasInstantPoisonMH()) and (not NAG:HasWindfuryTotemWeaponBuff()) and NAG:CastPlaceholderWithOverlay(8681, "MH", NAG.SPELL_POSITIONS.LEFT) -- Instant Poison VII (MH, skip if Windfury)
or
NAG:AuraIsActiveResolved(5171) and NAG:Cast(13750) -- Adrenaline Rush
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(185848) -- Greater Drums of Battle
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(20572) and NAG:CastWithOverlay(20572, "Racial Macro") -- Orc Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(26297) and NAG:CastWithOverlay(26297, "Racial Macro") -- Troll Racials
or
NAG:SpellIsReady(13877) and (NAG:NumberTargets(8) >= 2 or NAG:AuraIsActiveResolved(5171, "player")) and NAG:Cast(13877) -- Blade Flurry
or
((NAG:AuraRemainingTimeResolved(5171, "player") <= 1)) and NAG:CurrentComboPoints() >= 5 and (not NAG:RogueShouldAvoidSnDHolding()) and ((NAG:RemainingTime() >= 9) or (NAG:RemainingTime() < 7777 and NAG:RogueSliceAndDiceFullDuration() >= NAG:RemainingTime())) and NAG:Cast(5171) -- Slice And Dice prefer 5 CP
or
((NAG:AuraRemainingTimeResolved(5171, "player") <= 1)) and NAG:CurrentComboPoints() >= 1 and (not NAG:RogueShouldAvoidSnDHolding()) and ((NAG:RemainingTime() >= 9) or (NAG:RemainingTime() < 7777 and NAG:RogueSliceAndDiceFullDuration() >= NAG:RemainingTime())) and NAG:Cast(5171) -- Slice And Dice
or
(NAG:InCombat() and NAG:CurrentComboPoints() >= 1 and (NAG:AuraRemainingTimeResolved(5171, "player") < 3) and (NAG:NumberTargets(8, false) >= 2) and NAG:RogueHasNearbyEnemyKnownTTDGreaterThan(12, 8)) and NAG:Cast(5171) -- Slice And Dice (multi-target: any nearby mob TTD > 12s)
or
(GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("expose_armor")
    and (not NAG:AuraIsActiveResolved(8647, "target"))
    and NAG:AuraRemainingTimeResolved(5171) >= 5
    and NAG:CurrentComboPoints() >= 5
    and ((not NAG:InEncounter()) and NAG:RemainingTime() >= 10 or (NAG:InEncounter() and NAG:RemainingTime() >= 3))
    and NAG:Cast(8647) -- Expose Armor
or
((
    (not ((GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("expose_armor")))
    or (NAG:DotRemainingTimeResolved(8647) >= 1)
    or (NAG:RemainingTime() <= 10)
    or (not (
        (GetNumGroupMembers() > 0)
        and NAG:IsAssignmentEnabled("expose_armor")
        and (not NAG:AuraIsActiveResolved(8647, "target"))
        and NAG:AuraRemainingTimeResolved(5171) >= 5
        and NAG:CurrentComboPoints() >= 5
        and ((not NAG:InEncounter()) and NAG:RemainingTime() >= 10 or (NAG:InEncounter() and NAG:RemainingTime() >= 3))
    ))
)) and (NAG:NumberTargets() == 1 or (not NAG:AuraIsActiveResolved(13877, "player"))) and (NAG:DotRemainingTimeResolved(1943) == 0) and (NAG:AuraRemainingTimeResolved(5171) >= 5 or NAG:RogueShouldAvoidSnDHolding()) and (NAG:CurrentComboPoints() >= 3 or (NAG:RemainingTime() < 2 and NAG:CurrentComboPoints() >= 1)) and (NAG:RemainingTime() > 16 ) and NAG:RogueTargetTTDLongEnoughForRupture() and NAG:Cast(1943) -- Rupture
or
((
    (not ((GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("expose_armor")))
    or (NAG:DotRemainingTimeResolved(8647) >= 1)
    or (NAG:RemainingTime() <= 10)
    or (not (
        (GetNumGroupMembers() > 0)
        and NAG:IsAssignmentEnabled("expose_armor")
        and (not NAG:AuraIsActiveResolved(8647, "target"))
        and NAG:AuraRemainingTimeResolved(5171) >= 5
        and NAG:CurrentComboPoints() >= 5
        and ((not NAG:InEncounter()) and NAG:RemainingTime() >= 10 or (NAG:InEncounter() and NAG:RemainingTime() >= 3))
    ))
)) and (NAG:AuraRemainingTimeResolved(5171) >= 5 or NAG:RogueShouldAvoidSnDHolding()) and (NAG:CurrentComboPoints() >= 3 or (NAG:RemainingTime() < 2 and NAG:CurrentComboPoints() >= 1)) and ((NAG:RemainingTime() < 21 ) or (NAG:NumberTargets() >= 2)) and NAG:Cast(2098) -- Eviscerate
or
NAG:AuraIsActiveResolved(27186, "target") and (NAG:DotRemainingTimeResolved(27186) <= 3) and NAG:Cast(5938) -- Deadly Poison and Shiv
or
NAG:SpellIsKnown(28734) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(28734) -- BE Racial Mana Tap
or
NAG:AuraNumStacks(28734) >= 3 and NAG:SpellIsKnown(25046) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(25046) -- BE Racial Arcane Torrent
or
NAG:Cast(14251)
or
NAG:Cast(1752) -- Sinister Strike
]],
}


-- Combat Rotation
local combatRotationExposeArmor = {
    -- Core identification
    name = "Combat w/Expose Armor",
    specIndex = 2,
    class = "ROGUE",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    lastModified = "12/10/2025",
    author = "@horalius",
    macros = combatMacros,
    enableSmartSwitching = true,
    customConditions = {
        {
            type = ns.CUSTOM_CONDITION_TYPES.ASSIGNMENT,
            value = "expose_armor",
        }
    },
    rotationString = [[
NAG:EnableAssignmentsGate()
or
(not NAG:InCombat()) and (not NAG:RogueHasDeadlyPoisonOH()) and NAG:CastPlaceholderWithOverlay(26967, "OH", NAG.SPELL_POSITIONS.LEFT) -- Deadly Poison VII (OH)
or
(not NAG:InCombat()) and (not NAG:RogueHasInstantPoisonMH()) and (not NAG:HasWindfuryTotemWeaponBuff()) and NAG:CastPlaceholderWithOverlay(8679, "MH", NAG.SPELL_POSITIONS.LEFT) -- Instant Poison VII (MH, skip if Windfury)
or
NAG:AuraIsActiveResolved(5171) and NAG:Cast(13750) -- Adrenaline Rush
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(5171) and (not NAG:IsActive(51120, "player" )) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(185848) -- Greater Drums of Battle
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(5171) and (not NAG:IsActive(51120, "player" )) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(29529) -- Drums of Battle
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(20572) and NAG:CastWithOverlay(20572, "Racial Macro") -- Orc Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(26297) and NAG:CastWithOverlay(26297, "Racial Macro") -- Troll Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:CastWithOverlay(22838, "Racial Macro")
or
NAG:SpellIsReady(13877) and (NAG:NumberTargets(8) >= 2 or NAG:AuraIsActiveResolved(5171, "player")) and NAG:Cast(13877) -- Blade Flurry
or
(NAG:AuraRemainingTimeResolved(5171) <= 1) and NAG:CurrentComboPoints() >= 5 and (not NAG:RogueShouldAvoidSnDHolding()) and ((NAG:RemainingTime() >= 9) or (NAG:RemainingTime() < 7777 and NAG:RogueSliceAndDiceFullDuration() >= NAG:RemainingTime())) and NAG:Cast(5171) -- Slice And Dice prefer 5 CP
or
(NAG:AuraRemainingTimeResolved(5171) <= 1) and NAG:CurrentComboPoints() >= 1 and (not NAG:RogueShouldAvoidSnDHolding()) and ((NAG:RemainingTime() >= 9) or (NAG:RemainingTime() < 7777 and NAG:RogueSliceAndDiceFullDuration() >= NAG:RemainingTime())) and NAG:Cast(5171) -- Slice And Dice
or
(NAG:InCombat() and NAG:CurrentComboPoints() >= 1 and (NAG:AuraRemainingTimeResolved(5171, "player") < 3) and (NAG:NumberTargets(8, false) >= 2) and NAG:RogueHasNearbyEnemyKnownTTDGreaterThan(12, 8)) and NAG:Cast(5171) -- Slice And Dice (multi-target: any nearby mob TTD > 12s)
or
(GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("expose_armor")
    and (NAG:DotRemainingTimeResolved(8647) <= 1)
    and NAG:AuraRemainingTimeResolved(5171) >= 5
    and NAG:CurrentComboPoints() >= 5
    and ((not NAG:InEncounter()) and NAG:RemainingTime() >= 10 or (NAG:InEncounter() and NAG:RemainingTime() >= 3))
    and NAG:Cast(8647) -- Expose Armor
or
((NAG:DotRemainingTimeResolved(8647) >= 1) or (NAG:RemainingTime() <= 10)) and (NAG:NumberTargets() == 1 or (not NAG:AuraIsActiveResolved(13877, "player"))) and (NAG:DotRemainingTimeResolved(1943) == 0) and (NAG:AuraRemainingTimeResolved(5171) >= 5 or NAG:RogueShouldAvoidSnDHolding()) and (NAG:CurrentComboPoints() >= 3 or (NAG:RemainingTime() < 2 and NAG:CurrentComboPoints() >= 1)) and (NAG:RemainingTime() > 16 ) and NAG:RogueTargetTTDLongEnoughForRupture() and NAG:Cast(1943) -- Rupture
or
((NAG:DotRemainingTimeResolved(8647) >= 1) or (NAG:RemainingTime() <= 10)) and (NAG:AuraRemainingTimeResolved(5171) >= 5 or NAG:RogueShouldAvoidSnDHolding()) and (NAG:CurrentComboPoints() >= 3 or (NAG:RemainingTime() < 2 and NAG:CurrentComboPoints() >= 1)) and ((NAG:RemainingTime() < 21 ) or (NAG:NumberTargets() >= 2)) and NAG:Cast(2098) -- Eviscerate
or
NAG:AuraIsActiveResolved(27186, "target") and (NAG:DotRemainingTimeResolved(27186) <= 3) and NAG:Cast(5938) -- Deadly Poison and Shiv
or
NAG:SpellIsKnown(28734) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(28734) -- BE Racial Mana Tap
or
NAG:AuraNumStacks(28734) >= 3 and NAG:SpellIsKnown(25046) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(25046) -- BE Racial Arcane Torrent
or
NAG:Cast(14251)
or
(NAG:CurrentComboPoints() <= 4 or (NAG:CurrentEnergyAtGCD() > 80)) and NAG:Cast(1752) -- Sinister Strike
]],
}

-- Subtlety Rotation
local subtletyRotation = {
    -- Core identification
    name = "Subtlety",
    specIndex = 3,
    class = "ROGUE",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    rotationString = [[
NAG:EnableAssignmentsGate()
or
(not NAG:InCombat()) and (not NAG:RogueHasDeadlyPoisonOH()) and NAG:CastPlaceholderWithOverlay(26967, "OH", NAG.SPELL_POSITIONS.LEFT) -- Deadly Poison VII (OH)
or
(not NAG:InCombat()) and (not NAG:RogueHasInstantPoisonMH()) and (not NAG:HasWindfuryTotemWeaponBuff()) and NAG:CastPlaceholderWithOverlay(8679, "MH", NAG.SPELL_POSITIONS.LEFT) -- Instant Poison VII (MH, skip if Windfury)
or
NAG:AuraIsActiveResolved(5171) and NAG:Cast(13750) -- Adrenaline Rush
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(5171) and (not NAG:IsActive(51120, "player" )) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(185848) -- Greater Drums of Battle
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(5171) and (not NAG:IsActive(51120, "player" )) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(29529) -- Drums of Battle
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(20572) and NAG:CastWithOverlay(20572, "Racial Macro") -- Orc Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(26297) and NAG:CastWithOverlay(26297, "Racial Macro") -- Troll Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:CastWithOverlay(22838, "Racial Macro")
or
NAG:SpellIsReady(13877) and (NAG:NumberTargets(8) >= 2 or NAG:AuraIsActiveResolved(5171, "player")) and NAG:Cast(13877) -- Blade Flurry
or
(NAG:AuraRemainingTimeResolved(5171) <= 1) and NAG:CurrentComboPoints() >= 5 and (not NAG:RogueShouldAvoidSnDHolding()) and ((NAG:RemainingTime() >= 9) or (NAG:RemainingTime() < 7777 and NAG:RogueSliceAndDiceFullDuration() >= NAG:RemainingTime())) and NAG:Cast(5171) -- Slice And Dice prefer 5 CP
or
(NAG:AuraRemainingTimeResolved(5171) <= 1) and NAG:CurrentComboPoints() >= 1 and (not NAG:RogueShouldAvoidSnDHolding()) and ((NAG:RemainingTime() >= 9) or (NAG:RemainingTime() < 7777 and NAG:RogueSliceAndDiceFullDuration() >= NAG:RemainingTime())) and NAG:Cast(5171) -- Slice And Dice
or
(NAG:InCombat() and NAG:CurrentComboPoints() >= 1 and (NAG:AuraRemainingTimeResolved(5171, "player") < 3) and (NAG:NumberTargets(8, false) >= 2) and NAG:RogueHasNearbyEnemyKnownTTDGreaterThan(12, 8)) and NAG:Cast(5171) -- Slice And Dice (multi-target: any nearby mob TTD > 12s)
or
(GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("expose_armor")
    and (NAG:DotRemainingTimeResolved(8647) <= 1)
    and NAG:AuraRemainingTimeResolved(5171) >= 5
    and NAG:CurrentComboPoints() >= 5
    and ((not NAG:InEncounter()) and NAG:RemainingTime() >= 10 or (NAG:InEncounter() and NAG:RemainingTime() >= 3))
    and NAG:Cast(8647) -- Expose Armor
or
(NAG:RogueExposeArmorAllowsFinishers()) and (NAG:NumberTargets() == 1 or (not NAG:AuraIsActiveResolved(13877, "player"))) and (NAG:DotRemainingTimeResolved(1943) == 0) and (NAG:AuraRemainingTimeResolved(5171) >= 5 or NAG:RogueShouldAvoidSnDHolding()) and (NAG:CurrentComboPoints() >= 3 or (NAG:RemainingTime() < 2 and NAG:CurrentComboPoints() >= 1)) and (NAG:RemainingTime() > 16 ) and NAG:RogueTargetTTDLongEnoughForRupture() and NAG:Cast(1943) -- Rupture
or
(NAG:RogueExposeArmorAllowsFinishers()) and (NAG:AuraRemainingTimeResolved(5171) >= 5 or NAG:RogueShouldAvoidSnDHolding()) and (NAG:CurrentComboPoints() >= 3 or (NAG:RemainingTime() < 2 and NAG:CurrentComboPoints() >= 1)) and ((NAG:RemainingTime() < 21 ) or (NAG:NumberTargets() >= 2)) and NAG:Cast(2098) -- Eviscerate
or
NAG:AuraIsActiveResolved(27186, "target") and (NAG:DotRemainingTimeResolved(27186) <= 3) and NAG:Cast(5938) -- Deadly Poison and Shiv
or
NAG:SpellIsKnown(28734) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(28734) -- BE Racial Mana Tap
or
NAG:AuraNumStacks(28734) >= 3 and NAG:SpellIsKnown(25046) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(25046) -- BE Racial Arcane Torrent
or
(NAG:CurrentComboPoints() <= 4 or (NAG:CurrentEnergyAtGCD() > 80)) and NAG:Cast(16511) -- Hemorrhage
]],
}

--- @class Rogue : ClassBase
local Rogue = NAG:CreateClassModule("ROGUE", defaults)
if not Rogue then return end

function Rogue:SetupClassDefaults()
    ns.AddRotationToDefaults(self.defaults, 0, genericRotation)  -- Generic (no talents)
    ns.AddRotationToDefaults(self.defaults, 1, assassinationRotation)  -- Assassination
    ns.AddRotationToDefaults(self.defaults, 2, combatRotation)  -- Combat
    --ns.AddRotationToDefaults(self.defaults, 2, combatRotationExposeArmor)  -- Combat w/Expose Armor
    ns.AddRotationToDefaults(self.defaults, 3, subtletyRotation)  -- Subtlety
end

NAG.Class = Rogue

