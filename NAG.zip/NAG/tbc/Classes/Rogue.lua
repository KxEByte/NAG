local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version

local defaults = ns.InitializeClassDefaults()

local combatMacros = {
    {
        name = "Rogue Racial Orc",
        body = "#showtooltip\n/cast Blood Fury(Racial)\n/use Haste Potion\n/use Thistle Tea\n/use 13"
    },
    {
        name = "Rogue Racial Troll",
        body = "#showtooltip\n/cast Berserking(Racial)\n/use Haste Potion\n/use Thistle Tea\n/use 13"
    },
    {
        name = "Rogue Racial",
        body = "#showtooltip\n/use Haste Potion\n/use Thistle Tea\n/use 13"
    },
}

-- TBC Rogue spec spell locations (empty for now)
defaults.class.specSpellLocations = {
    [1] = { -- Assassination
        [13750] = NAG.SPELL_POSITIONS.LEFT, -- Adrenaline Rush
        [13877] = NAG.SPELL_POSITIONS.LEFT, -- Blade Flurry
    },
    [2] = { -- Combat
        [13750] = NAG.SPELL_POSITIONS.LEFT, -- Adrenaline Rush
        [13877] = NAG.SPELL_POSITIONS.LEFT, -- Blade Flurry
    },
    [3] = { -- Subtlety
        [13750] = NAG.SPELL_POSITIONS.LEFT, -- Adrenaline Rush
        [13877] = NAG.SPELL_POSITIONS.LEFT, -- Blade Flurry
    },
}

-- Class assignments for raid coordination
defaults.class.classAssignments = {
    {
        id = "expose_armor",
        name = "Expose Armor",
        description = "Apply armor reduction debuff on targets (conflicts with Warrior Sunder Armor)",
        spellIds = {8647, 8649, 8650, 11197, 11198, 26866}, -- All ranks
        category = "debuff",
    },
}

defaults.char.assignmentToggles = defaults.char.assignmentToggles or {}
if defaults.char.assignmentToggles.expose_armor == nil then
    defaults.char.assignmentToggles.expose_armor = false
end

if UnitClassBase('player') ~= "ROGUE" then return end

-- Assassination Rotation
local assassinationRotation = {
    -- Core identification
    name = "Assassination",
    specIndex = 1,
    class = "ROGUE",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    rotationString = [[
NAG:EnableAssignmentsGate()
or
(not NAG:IsActive(27186)) and NAG:CastWithOverlay(22054, "OH",NAG.SPELL_POSITIONS.ABOVE) -- Deadly Poison VII
or
(not NAG:IsActive(26891)) and (not NAG:IsActive(25584))and NAG:CastWithOverlay(21927," \nMH/WF" ,NAG.SPELL_POSITIONS.ABOVE) -- Instant Poison VII /w Windfurry check
or
NAG:StrictSequence("Cold Blood", nil, 14177, 1329) -- Cold Blood
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(5171) and (not NAG:IsActive(51120, "player" )) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(185848) -- Greater Drums of Battle
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(5171) and (not NAG:IsActive(51120, "player" )) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(29529) -- Drums of Battle
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(20572) and NAG:CastWithOverlay(20572, "Racial Macro") -- Orc Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(26297) and NAG:CastWithOverlay(26297, "Racial Macro") -- Troll Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:CastWithOverlay(22838, "Racial Macro")
or
(NAG:AuraRemainingTimeResolved(5171) <= 1) and NAG:CurrentComboPoints() >= 1 and (not NAG:RogueShouldAvoidSnDHolding()) and NAG:Cast(5171) -- Slice And Dice
or
(GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("expose_armor")
    and (NAG:DotRemainingTimeResolved(8647) <= 1)
    and NAG:AuraRemainingTimeResolved(5171) >= 5
    and NAG:CurrentComboPoints() >= 5
    and ((not NAG:InEncounter()) and NAG:RemainingTime() >= 10 or (NAG:InEncounter() and NAG:RemainingTime() >= 3))
    and NAG:Cast(8647) -- Expose Armor
or
(NAG:DotRemainingTimeResolved(8647) >= 13) and (NAG:AuraRemainingTimeResolved(5171) >= 8 or NAG:RogueShouldAvoidSnDHolding()) and NAG:CurrentComboPoints() >= 5 and ((NAG:RemainingTime() < 21 ) or (NAG:NumberTargets() >= 2)) and NAG:Cast(2098) -- Eviscerate
or
(NAG:DotRemainingTimeResolved(8647) >= 13) and (NAG:AuraRemainingTimeResolved(5171) >= 8 or NAG:RogueShouldAvoidSnDHolding()) and NAG:CurrentComboPoints() >= 5 and (NAG:RemainingTime() > 21 ) and NAG:Cast(1943) -- Rupture
or
NAG:AuraIsActiveResolved(27186, "target") and (NAG:DotRemainingTimeResolved(27186) <= 3) and NAG:Cast(5938) -- Deadly Poison and Shiv
or
NAG:SpellIsKnown(28734) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(28734) -- BE Racial Mana Tap
or
NAG:AuraNumStacks(28734) >= 3 and NAG:SpellIsKnown(25046) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(25046) -- BE Racial Arcane Torrent
or
(NAG:CurrentComboPoints() <= 4 or (NAG:CurrentEnergyAtGCD() > 80)) and NAG:Cast(1329) -- Mutilate

    ]],
}

-- Combat Rotation
local combatRotation = {
    -- Core identification
    name = "Combat",
    specIndex = 2,
    class = "ROGUE",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    lastModified = "12/10/2025",
    author = "@horalius",
    macros = combatMacros,
    enableSmartSwitching = true,
    rotationString = [[
NAG:EnableAssignmentsGate()
or
(not NAG:IsActive(27186)) and NAG:CastWithOverlay(22054, "OH") -- Deadly Poison VII
or
(not NAG:IsActive(26891)) and (not NAG:IsActive(25584))and NAG:CastWithOverlay(21927," \nMH or WF" ) -- Instant Poison VII /w Windfurry check
or
NAG:AuraIsActiveResolved(5171) and NAG:Cast(13750) -- Adrenaline Rush
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(185848) -- Greater Drums of Battle
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(20572) and NAG:CastWithOverlay(20572, "Racial Macro") -- Orc Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(26297) and NAG:CastWithOverlay(26297, "Racial Macro") -- Troll Racials
or
NAG:SpellIsReady(13877) and NAG:AuraIsActiveResolved(5171, "player") and NAG:Cast(13877) -- Blade Flurry
or
(not NAG:AuraIsActiveResolved(5171, "player")) and NAG:CurrentComboPoints() >= 1 and NAG:Cast(5171) -- Slice And Dice
or
(GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("expose_armor")
    and (not NAG:AuraIsActiveResolved(8647, "target"))
    and NAG:AuraRemainingTimeResolved(5171) >= 5
    and NAG:CurrentComboPoints() >= 5
    and ((not NAG:InEncounter()) and NAG:RemainingTime() >= 10 or (NAG:InEncounter() and NAG:RemainingTime() >= 3))
    and NAG:Cast(8647) -- Expose Armor
or
(NAG:DotRemainingTimeResolved(8647) >= 3) and (NAG:AuraRemainingTimeResolved(5171) >= 5 or NAG:RogueShouldAvoidSnDHolding()) and NAG:CurrentComboPoints() >= 5 and ((NAG:RemainingTime() < 21 ) or (NAG:NumberTargets() >= 2)) and NAG:Cast(2098) -- Eviscerate
or
(NAG:DotRemainingTimeResolved(8647) >= 5) and (NAG:AuraRemainingTimeResolved(5171) >= 5 or NAG:RogueShouldAvoidSnDHolding()) and NAG:CurrentComboPoints() >= 5 and (NAG:RemainingTime() > 21 ) and NAG:Cast(1943) -- Rupture
or
NAG:AuraIsActiveResolved(27186, "target") and (NAG:DotRemainingTimeResolved(27186) <= 3) and NAG:Cast(5938) -- Deadly Poison and Shiv
or
NAG:SpellIsKnown(28734) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(28734) -- BE Racial Mana Tap
or
NAG:AuraNumStacks(28734) >= 3 and NAG:SpellIsKnown(25046) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(25046) -- BE Racial Arcane Torrent
or
NAG:Cast(14251)
or
NAG:Cast(1752) -- Sinister Strike
]],
}


-- Combat Rotation
local combatRotationExposeArmor = {
    -- Core identification
    name = "Combat w/Expose Armor",
    specIndex = 2,
    class = "ROGUE",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    lastModified = "12/10/2025",
    author = "@horalius",
    macros = combatMacros,
    enableSmartSwitching = true,
    customConditions = {
        {
            type = ns.CUSTOM_CONDITION_TYPES.ASSIGNMENT,
            value = "expose_armor",
        }
    },
    rotationString = [[
NAG:EnableAssignmentsGate()
or
(not NAG:IsActive(27186)) and NAG:CastWithOverlay(22054, "OH",NAG.SPELL_POSITIONS.ABOVE) -- Deadly Poison VII
or
(not NAG:IsActive(26891)) and (not NAG:IsActive(25584))and NAG:CastWithOverlay(21927," \nMH/WF" ,NAG.SPELL_POSITIONS.ABOVE) -- Instant Poison VII /w Windfurry check
or
NAG:AuraIsActiveResolved(5171) and NAG:Cast(13750) -- Adrenaline Rush
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(5171) and (not NAG:IsActive(51120, "player" )) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(185848) -- Greater Drums of Battle
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(5171) and (not NAG:IsActive(51120, "player" )) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(29529) -- Drums of Battle
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(20572) and NAG:CastWithOverlay(20572, "Racial Macro") -- Orc Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(26297) and NAG:CastWithOverlay(26297, "Racial Macro") -- Troll Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:CastWithOverlay(22838, "Racial Macro")
or
NAG:SpellIsReady(13877) and NAG:AuraIsActiveResolved(5171, "player") and NAG:Cast(13877) -- Blade Flurry
or
(NAG:AuraRemainingTimeResolved(5171) <= 1) and NAG:CurrentComboPoints() >= 1 and (not NAG:RogueShouldAvoidSnDHolding()) and NAG:Cast(5171) -- Slice And Dice
or
(GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("expose_armor")
    and (NAG:DotRemainingTimeResolved(8647) <= 1)
    and NAG:AuraRemainingTimeResolved(5171) >= 5
    and NAG:CurrentComboPoints() >= 5
    and ((not NAG:InEncounter()) and NAG:RemainingTime() >= 10 or (NAG:InEncounter() and NAG:RemainingTime() >= 3))
    and NAG:Cast(8647) -- Expose Armor
or
(NAG:DotRemainingTimeResolved(8647) >= 13) and (NAG:AuraRemainingTimeResolved(5171) >= 8 or NAG:RogueShouldAvoidSnDHolding()) and NAG:CurrentComboPoints() >= 5 and ((NAG:RemainingTime() < 21 ) or (NAG:NumberTargets() >= 2)) and NAG:Cast(2098) -- Eviscerate
or
(NAG:DotRemainingTimeResolved(8647) >= 13) and (NAG:AuraRemainingTimeResolved(5171) >= 8 or NAG:RogueShouldAvoidSnDHolding()) and NAG:CurrentComboPoints() >= 5 and (NAG:RemainingTime() > 21 ) and NAG:Cast(1943) -- Rupture
or
NAG:AuraIsActiveResolved(27186, "target") and (NAG:DotRemainingTimeResolved(27186) <= 3) and NAG:Cast(5938) -- Deadly Poison and Shiv
or
NAG:SpellIsKnown(28734) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(28734) -- BE Racial Mana Tap
or
NAG:AuraNumStacks(28734) >= 3 and NAG:SpellIsKnown(25046) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(25046) -- BE Racial Arcane Torrent
or
NAG:Cast(14251)
or
(NAG:CurrentComboPoints() <= 4 or (NAG:CurrentEnergyAtGCD() > 80)) and NAG:Cast(1752) -- Sinister Strike
]],
}

-- Subtlety Rotation
local subtletyRotation = {
    -- Core identification
    name = "Subtlety",
    specIndex = 3,
    class = "ROGUE",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_TBC,
    rotationString = [[
NAG:EnableAssignmentsGate()
or
(not NAG:IsActive(27186)) and NAG:CastWithOverlay(22054, "OH",NAG.SPELL_POSITIONS.ABOVE) -- Deadly Poison VII
or
(not NAG:IsActive(26891)) and (not NAG:IsActive(25584))and NAG:CastWithOverlay(21927," \nMH/WF" ,NAG.SPELL_POSITIONS.ABOVE) -- Instant Poison VII /w Windfurry check
or
NAG:AuraIsActiveResolved(5171) and NAG:Cast(13750) -- Adrenaline Rush
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(5171) and (not NAG:IsActive(51120, "player" )) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(185848) -- Greater Drums of Battle
or
NAG:SpellIsKnown(32549) and NAG:AuraIsActiveResolved(5171) and (not NAG:IsActive(51120, "player" )) and NAG:AuraIsActiveResolved(13750) and NAG:Cast(29529) -- Drums of Battle
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(20572) and NAG:CastWithOverlay(20572, "Racial Macro") -- Orc Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:SpellIsKnown(26297) and NAG:CastWithOverlay(26297, "Racial Macro") -- Troll Racials
or
NAG:AuraIsActiveResolved(5171) and NAG:CastWithOverlay(22838, "Racial Macro")
or
NAG:SpellIsReady(13877) and NAG:AuraIsActiveResolved(5171, "player") and NAG:Cast(13877) -- Blade Flurry
or
(NAG:AuraRemainingTimeResolved(5171) <= 1) and NAG:CurrentComboPoints() >= 1 and (not NAG:RogueShouldAvoidSnDHolding()) and NAG:Cast(5171) -- Slice And Dice
or
(GetNumGroupMembers() > 0) and NAG:IsAssignmentEnabled("expose_armor")
    and (NAG:DotRemainingTimeResolved(8647) <= 1)
    and NAG:AuraRemainingTimeResolved(5171) >= 5
    and NAG:CurrentComboPoints() >= 5
    and ((not NAG:InEncounter()) and NAG:RemainingTime() >= 10 or (NAG:InEncounter() and NAG:RemainingTime() >= 3))
    and NAG:Cast(8647) -- Expose Armor
or
(NAG:DotRemainingTimeResolved(8647) >= 13) and (NAG:AuraRemainingTimeResolved(5171) >= 8 or NAG:RogueShouldAvoidSnDHolding()) and NAG:CurrentComboPoints() >= 5 and ((NAG:RemainingTime() < 21 ) or (NAG:NumberTargets() >= 2)) and NAG:Cast(2098) -- Eviscerate
or
(NAG:DotRemainingTimeResolved(8647) >= 13) and (NAG:AuraRemainingTimeResolved(5171) >= 8 or NAG:RogueShouldAvoidSnDHolding()) and NAG:CurrentComboPoints() >= 5 and (NAG:RemainingTime() > 21 ) and NAG:Cast(1943) -- Rupture
or
NAG:AuraIsActiveResolved(27186, "target") and (NAG:DotRemainingTimeResolved(27186) <= 3) and NAG:Cast(5938) -- Deadly Poison and Shiv
or
NAG:SpellIsKnown(28734) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(28734) -- BE Racial Mana Tap
or
NAG:AuraNumStacks(28734) >= 3 and NAG:SpellIsKnown(25046) and (NAG:CurrentEnergyAtGCD() < 30) and NAG:Cast(25046) -- BE Racial Arcane Torrent
or
(NAG:CurrentComboPoints() <= 4 or (NAG:CurrentEnergyAtGCD() > 80)) and NAG:Cast(16511) -- Hemorrhage
]],
}

--- @class Rogue : ClassBase
local Rogue = NAG:CreateClassModule("ROGUE", defaults)
if not Rogue then return end

function Rogue:SetupClassDefaults()
    ns.AddRotationToDefaults(self.defaults, 1, assassinationRotation)  -- Assassination
    ns.AddRotationToDefaults(self.defaults, 2, combatRotation)  -- Combat
    ns.AddRotationToDefaults(self.defaults, 2, combatRotationExposeArmor)  -- Combat w/Expose Armor
    ns.AddRotationToDefaults(self.defaults, 3, subtletyRotation)  -- Subtlety
end

NAG.Class = Rogue

