# Beta Release Changes (v5.6.11-beta6 to v5.6.11-beta7)

- feat: Add racial abilities data for WotLK (Rakizi)\n- feat: Add  common buffs and debuffs to wrath data (Rakizi)
