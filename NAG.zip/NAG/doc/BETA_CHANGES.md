# Beta Release Changes (v5.6.10-beta8 to v5.6.10-beta9)

- TBC Rogue fix, snd protection gate (fonsas)\n- Ensure rotation selection and error reporting (fonsas)
