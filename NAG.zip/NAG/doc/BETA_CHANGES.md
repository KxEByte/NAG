# Beta Release Changes (v5.6.13-beta6 to v5.6.13-beta7)

- prot pal fixes (fonsas)
