# Beta Release Changes (v5.6.14-beta8 to v5.6.14-beta9)

- feat: add cooldown and AoE frame toggle functionality(keybind, floating N or macro via /nag cooldowns or /nag aoeframe, old /nagburst works still) (Rakizi)
