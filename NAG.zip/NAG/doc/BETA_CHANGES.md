# Beta Release Changes (v5.6.16-beta11 to v5.6.16-beta12)

- hunter prediction cooldown fix (fonsas)\n- TBC hunter polishing for more accuracy (fonsas)
