# Beta Release Changes (v5.6.15-beta1 to v5.6.15-beta2)

- Ret TBC fix - fillers (fonsas)
