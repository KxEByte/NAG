# Beta Release Changes (v5.6.10-beta21 to v5.6.10-beta22)

- NAG rotation selector watchdog (fonsas)
