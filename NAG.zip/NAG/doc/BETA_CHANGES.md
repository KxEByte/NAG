# Beta Release Changes (v5.6.13-beta55 to v5.6.13-beta56)

- SV hunter rotation enabled (fonsas)
