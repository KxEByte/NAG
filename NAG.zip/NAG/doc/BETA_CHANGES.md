# Beta Release Changes (v5.6.16-beta12 to v5.6.16-beta13)

- TBC hunter MS/AR when on cd (fonsas)\n- fix: bug in key dialog (Rakizi)\n- Remove DevMode visibility condition from DisplayManager options (Rakizi)
