# Beta Release Changes (v5.6.13-beta26 to v5.6.13-beta27)

- TBC enhance auto staggering polishing (fonsas)
