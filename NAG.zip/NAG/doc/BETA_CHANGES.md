# Beta Release Changes (v5.6.16-beta4 to v5.6.16-beta5)

- FIX: SPEll position ranks (Rakizi)
