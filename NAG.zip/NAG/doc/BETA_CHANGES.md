# Beta Release Changes (v5.6.13-beta2 to v5.6.13-beta3)

- mana percent fix (fonsas)
