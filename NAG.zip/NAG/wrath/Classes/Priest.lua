local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version

local defaults = ns.InitializeClassDefaults()

-- Wrath Priest spec spell locations
defaults.class.specSpellLocations = {
    [1] = {},  -- Discipline
    [2] = {},  -- Holy
    [3] = {},  -- Shadow
}

if UnitClassBase('player') ~= "PRIEST" then return end

-- Discipline Rotation
local disciplineRotation = {
    -- Core identification
    name = "Discipline",
    specIndex = 1,
    class = "PRIEST",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

-- Holy Rotation
local holyRotation = {
    -- Core identification
    name = "Holy",
    specIndex = 2,
    class = "PRIEST",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

-- Shadow Rotation
local shadowRotation = {
    -- Core identification
    name = "Shadow",
    specIndex = 3,
    class = "PRIEST",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

--- @class Priest : ClassBase
local Priest = NAG:CreateClassModule("PRIEST", defaults)
if not Priest then return end

function Priest:SetupClassDefaults()
    ns.AddRotationToDefaults(self.defaults, 1, disciplineRotation)  -- Discipline
    ns.AddRotationToDefaults(self.defaults, 2, holyRotation)  -- Holy
    ns.AddRotationToDefaults(self.defaults, 3, shadowRotation)  -- Shadow
end

NAG.Class = Priest

