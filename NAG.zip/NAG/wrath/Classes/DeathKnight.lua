local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version

local defaults = ns.InitializeClassDefaults()

-- Wrath Death Knight spec spell locations
defaults.class.specSpellLocations = {
    [1] = {},  -- Blood
    [2] = {},  -- Frost
    [3] = {},  -- Unholy
}

if UnitClassBase('player') ~= "DEATHKNIGHT" then return end

-- Blood Rotation
local bloodRotation = {
    -- Core identification
    name = "Blood",
    specIndex = 1,
    class = "DEATHKNIGHT",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

-- Frost Rotation
local frostRotation = {
    -- Core identification
    name = "Frost",
    specIndex = 2,
    class = "DEATHKNIGHT",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

-- Unholy Rotation
local unholyRotation = {
    -- Core identification
    name = "Unholy",
    specIndex = 3,
    class = "DEATHKNIGHT",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

--- @class DeathKnight : ClassBase
local DeathKnight = NAG:CreateClassModule("DEATHKNIGHT", defaults)
if not DeathKnight then return end

function DeathKnight:SetupClassDefaults()
    ns.AddRotationToDefaults(self.defaults, 1, bloodRotation)  -- Blood
    ns.AddRotationToDefaults(self.defaults, 2, frostRotation)  -- Frost
    ns.AddRotationToDefaults(self.defaults, 3, unholyRotation)  -- Unholy
end

NAG.Class = DeathKnight

