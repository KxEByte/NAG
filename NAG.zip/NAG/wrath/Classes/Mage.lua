local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version

local defaults = ns.InitializeClassDefaults()

-- Wrath Mage spec spell locations
defaults.class.specSpellLocations = {
    [1] = {},  -- Arcane
    [2] = {},  -- Fire
    [3] = {},  -- Frost
}

if UnitClassBase('player') ~= "MAGE" then return end

-- Arcane Rotation
local arcaneRotation = {
    -- Core identification
    name = "Arcane",
    specIndex = 1,
    class = "MAGE",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

-- Fire Rotation
local fireRotation = {
    -- Core identification
    name = "Fire",
    specIndex = 2,
    class = "MAGE",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

-- Frost Rotation
local frostRotation = {
    -- Core identification
    name = "Frost",
    specIndex = 3,
    class = "MAGE",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

--- @class Mage : ClassBase
local Mage = NAG:CreateClassModule("MAGE", defaults)
if not Mage then return end

function Mage:SetupClassDefaults()
    ns.AddRotationToDefaults(self.defaults, 1, arcaneRotation)  -- Arcane
    ns.AddRotationToDefaults(self.defaults, 2, fireRotation)  -- Fire
    ns.AddRotationToDefaults(self.defaults, 3, frostRotation)  -- Frost
end

NAG.Class = Mage

