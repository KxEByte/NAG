local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version

local defaults = ns.InitializeClassDefaults()

-- Wrath Shaman spec spell locations
defaults.class.specSpellLocations = {
    [1] = {},  -- Elemental
    [2] = {},  -- Enhancement
    [3] = {},  -- Restoration
}

if UnitClassBase('player') ~= "SHAMAN" then return end

-- Elemental Rotation
local elementalRotation = {
    -- Core identification
    name = "Elemental",
    specIndex = 1,
    class = "SHAMAN",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

-- Enhancement Rotation
local enhancementRotation = {
    -- Core identification
    name = "Enhancement",
    specIndex = 2,
    class = "SHAMAN",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

-- Restoration Rotation
local restorationRotation = {
    -- Core identification
    name = "Restoration",
    specIndex = 3,
    class = "SHAMAN",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

--- @class Shaman : ClassBase
local Shaman = NAG:CreateClassModule("SHAMAN", defaults)
if not Shaman then return end

function Shaman:SetupClassDefaults()
    ns.AddRotationToDefaults(self.defaults, 1, elementalRotation)  -- Elemental
    ns.AddRotationToDefaults(self.defaults, 2, enhancementRotation)  -- Enhancement
    ns.AddRotationToDefaults(self.defaults, 3, restorationRotation)  -- Restoration
end

NAG.Class = Shaman

