local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version

local defaults = ns.InitializeClassDefaults()

-- Wrath Hunter spec spell locations
defaults.class.specSpellLocations = {
    [1] = {},  -- Beast Mastery
    [2] = {},  -- Marksmanship
    [3] = {},  -- Survival
}

if UnitClassBase('player') ~= "HUNTER" then return end

-- Beast Mastery Rotation
local beastMasteryRotation = {
    -- Core identification
    name = "Beast Mastery",
    specIndex = 1,
    class = "HUNTER",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

-- Marksmanship Rotation
local marksmanshipRotation = {
    -- Core identification
    name = "Marksmanship",
    specIndex = 2,
    class = "HUNTER",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

-- Survival Rotation
local survivalRotation = {
    -- Core identification
    name = "Survival",
    specIndex = 3,
    class = "HUNTER",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

--- @class Hunter : ClassBase
local Hunter = NAG:CreateClassModule("HUNTER", defaults)
if not Hunter then return end

function Hunter:SetupClassDefaults()
    ns.AddRotationToDefaults(self.defaults, 1, beastMasteryRotation)  -- Beast Mastery
    ns.AddRotationToDefaults(self.defaults, 2, marksmanshipRotation)  -- Marksmanship
    ns.AddRotationToDefaults(self.defaults, 3, survivalRotation)  -- Survival
end

NAG.Class = Hunter

