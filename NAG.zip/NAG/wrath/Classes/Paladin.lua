local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version

local defaults = ns.InitializeClassDefaults()

-- Wrath Paladin spec spell locations
defaults.class.specSpellLocations = {
    [1] = {},  -- Holy
    [2] = {},  -- Protection
    [3] = {},  -- Retribution
}

if UnitClassBase('player') ~= "PALADIN" then return end

-- Holy Rotation
local holyRotation = {
    -- Core identification
    name = "Holy",
    specIndex = 1,
    class = "PALADIN",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

-- Protection Rotation
local protectionRotation = {
    -- Core identification
    name = "Protection",
    specIndex = 2,
    class = "PALADIN",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

-- Retribution Rotation
local retributionRotation = {
    -- Core identification
    name = "Retribution",
    specIndex = 3,
    class = "PALADIN",
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_WRATH,
    rotationString = [[NAG:Cast(6603)]],
}

--- @class Paladin : ClassBase
local Paladin = NAG:CreateClassModule("PALADIN", defaults)
if not Paladin then return end

function Paladin:SetupClassDefaults()
    ns.AddRotationToDefaults(self.defaults, 1, holyRotation)  -- Holy
    ns.AddRotationToDefaults(self.defaults, 2, protectionRotation)  -- Protection
    ns.AddRotationToDefaults(self.defaults, 3, retributionRotation)  -- Retribution
end

NAG.Class = Paladin

