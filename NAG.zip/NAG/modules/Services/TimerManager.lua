--- @module "NAG.TimerManager"
--- Manages timer functionality for NAG.
---
--- This module provides functions for creating, canceling, and checking timers.
--- License: CC BY-NC 4.0 (https://creativecommons.org/licenses/by-nc/4.0/legalcode)
--- Authors: @Rakizi: farendil2020@gmail.com, @Fonsas
--- Discord: https://discord.gg/ebonhold

-- ~~~~~~~~~~ LOCALIZE ~~~~~~~~~~
local _, ns = ...
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")

-- Lua APIs (using WoW's optimized versions where available)
local format = string.format -- WoW's optimized version if available



-- ~~~~~~~~~~ CONTENT ~~~~~~~~~~
--- @class TimerManager
local TimerManager = NAG:CreateModule("TimerManager", nil, {
    libs = { "AceTimer-3.0" },
    -- Debug categories for group-based debugging
    debugCategories = {
        ns.DEBUG_CATEGORIES.SERVICES,
        ns.DEBUG_CATEGORIES.MANAGERS
    }
})
local module = TimerManager
ns.TimerManager = TimerManager

-- Timer categories for organization
TimerManager.Categories = {
    CORE = "core",                       -- Core addon functionality
    ROTATION = "rotation",               -- Rotation-related timers
    COMBAT = "combat",                   -- Combat-related timers
    UI_NOTIFICATION = "ui_notification", -- UI notification and alert timers
}

-- ~~~~~~~~~~ ACE3 LIFECYCLE ~~~~~~~~~~
do
    function TimerManager:ModuleInitialize()
        -- Initialize timer tracking
        self.timers = {
            [self.Categories.CORE] = {},
            [self.Categories.ROTATION] = {},
            [self.Categories.COMBAT] = {},
            [self.Categories.UI_NOTIFICATION] = {},
        }
    end

    function TimerManager:ModuleEnable()
        -- Nothing to do on enable - timers are created on demand
    end

    function TimerManager:ModuleDisable()
        self:CancelAllTimers()
    end
end

-- ~~~~~~~~~~ HELPERS & PUBLIC API ~~~~~~~~~~
--- Creates and registers a new timer
--- @param category string The category for the timer (use TimerManager.Categories)
--- @param name string Unique name for the timer within its category
--- @param callback function The function to call when the timer fires
--- @param interval number The interval in seconds
--- @param repeating boolean Whether the timer should repeat
--- @param args? table Optional arguments to pass to the callback
--- @return string|nil timerHandle The handle of the created timer, or nil if failed
function TimerManager:Create(category, name, callback, interval, repeating, args)
    -- Safety check: ensure timers are initialized
    if not self.timers then
        self:ModuleInitialize()
    end

    -- Validate inputs
    if not self.timers[category] then
        self:Error(format("Invalid timer category: %s", tostring(category)))
        return nil
    end

    if not name or type(name) ~= "string" then
        self:Error(format("Invalid timer name: %s", tostring(name)))
        return nil
    end

    if not callback or type(callback) ~= "function" then
        self:Error(format("Invalid timer callback: %s", tostring(callback)))
        return nil
    end

    if not interval or type(interval) ~= "number" or interval <= 0 then
        self:Error(format("Invalid timer interval: %s", tostring(interval)))
        return nil
    end

    if self.timers[category][name] then
        -- Don't spam debug for duplicate timers - just return existing
        return self.timers[category][name]
    end

    -- Create the timer using Ace3
    local timer
    if repeating then
        timer = self:ScheduleRepeatingTimer(function()
            if args then
                callback(unpack(args))
            else
                callback()
            end
        end, interval)
    else
        timer = self:ScheduleTimer(function()
            if args then
                callback(unpack(args))
            else
                callback()
            end
            -- Auto-cleanup non-repeating timers
            self.timers[category][name] = nil
        end, interval)
    end

    -- Store timer reference
    self.timers[category][name] = timer

    return timer
end

--- Cancels a specific timer
--- @param category string The category of the timer
--- @param name string The name of the timer to cancel
function TimerManager:Cancel(category, name)
    -- Safety check: ensure timers are initialized
    if not self.timers then
        return
    end

    -- Validate inputs
    if not category or not self.timers[category] then
        return
    end

    if not name or not self.timers[category][name] then
        return
    end

    -- Call parent AceTimer-3.0 CancelTimer method
    self:CancelTimer(self.timers[category][name])
    self.timers[category][name] = nil
end

--- Cancels all timers in a category
--- @param category string The category of timers to cancel
function TimerManager:CancelCategoryTimers(category)
    -- Safety check: ensure timers are initialized
    if not self.timers then
        return
    end

    if not self.timers[category] then
        return
    end

    for name, timer in pairs(self.timers[category]) do
        self:Cancel(category, name)
    end
end

--- Cancels all registered timers
function TimerManager:CancelAllTimers()
    -- Safety check: ensure timers are initialized
    if not self.timers then
        return
    end

    for category in pairs(self.timers) do
        for name, timer in pairs(self.timers[category]) do
            self:Cancel(category, name)
        end
    end
end

--- Checks if a specific timer is active
--- @param category string The category to check
--- @param name string The name of the timer to check
--- @return boolean isActive Whether the timer exists and is active
function TimerManager:IsTimerActive(category, name)
    -- Safety check: ensure timers are initialized
    if not self.timers then
        return false
    end

    -- Validate inputs
    if not category or not name then
        return false
    end

    return self.timers[category] and self.timers[category][name] ~= nil
end

--- Prints all active timers to debug output
--- @param category string Optional category to filter by
function TimerManager:PrintActiveTimers(category)
    -- Safety check: ensure timers are initialized
    if not self.timers then
        self:Debug("TimerManager not initialized")
        return
    end

    local hasActiveTimers = false

    for cat, timers in pairs(self.timers) do
        -- Skip if filtering by category and this isn't it
        if category and cat ~= category then
            -- Continue to next iteration (Lua 5.1 compatible)
        else
            local categoryHasTimers = false
            for name, timer in pairs(timers) do
                if not categoryHasTimers then
                    self:Debug("=== Active Timers in Category: %s ===", cat)
                    categoryHasTimers = true
                    hasActiveTimers = true
                end
                self:Debug("  Timer: %s (Handle: %s)", name, tostring(timer))
            end
        end
    end

    if not hasActiveTimers then
        if category then
            self:Debug("No active timers in category: %s", category)
        else
            self:Debug("No active timers found")
        end
    end
end

--- Gets a count of active timers
--- @param category string Optional category to count
--- @return number count Number of active timers
function TimerManager:GetActiveTimerCount(category)
    -- Safety check: ensure timers are initialized
    if not self.timers then
        return 0
    end

    local count = 0

    for cat, timers in pairs(self.timers) do
        -- Skip if filtering by category and this isn't it
        if category and cat ~= category then
            -- Continue to next iteration (Lua 5.1 compatible)
        else
            for name, timer in pairs(timers) do
                count = count + 1
            end
        end
    end

    return count
end
