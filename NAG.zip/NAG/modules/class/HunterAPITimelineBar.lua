--- @module "NAG.HunterAPITimelineBar"
--- Independent Hunter prediction timeline bar driven only by TBCHunterAPI outputs.
---
--- Displays a 6-second forecast with:
--- - SS gap windows
--- - SS icon markers at 70% into each SS window
--- - Next Multi-Shot and Arcane Shot markers
---
--- License: CC BY-NC 4.0
--- Authors: Rakizi, Fonsas

-- ============================ LOCALIZE ============================
local _, ns = ...

local GetTime = _G.GetTime
local UnitClassBase = _G.UnitClassBase
local UnitAffectingCombat = _G.UnitAffectingCombat
local CreateFrame = _G.CreateFrame
local GetSpellTexture = _G.GetSpellTexture

--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local OptionsFactory

-- ============================ CONSTANTS ============================
local DEFAULT_HORIZON_SECONDS = 6.0
local UPDATE_INTERVAL = 0.016
local BAR_DEBUG_PRINT_INTERVAL_SECONDS = 0.2
local BAR_DEBUG_PRINT_VERSION = "2026.02.18-5"
local MAX_SS_WINDOWS = 16
local MAX_SS_MARKERS = 8
local MAX_STATE_TICKS = 16

local STEADY_SHOT_ID = 34120
local MULTI_SHOT_ID = 27021
local ARCANE_SHOT_ID = 27019

-- ============================ DEFAULTS ============================
local defaults = {
    class = {
        enabled = true,
        hideOutOfCombat = false,

        autoAnchor = true,
        lockToNagAnchor = true,
        point = "CENTER",
        x = 120,
        y = -20,

        width = 360, -- Double legacy 180 width, to show 6s horizon cleanly.
        height = 20,
        alpha = 1.0,
        horizonSeconds = DEFAULT_HORIZON_SECONDS,

        showBackground = true,
        showTimelineLine = true,
        showNowMarker = true,
        showSSWindows = true,
        showSSIcons = true,
        showMSMarker = true,
        showARMarker = true,
        showDebugText = false,

        iconSize = 16,
        markerLaneOffsetY = 0,
        msOverlapOffsetY = 6,
        arOverlapOffsetY = -6,

        backgroundColor = { r = 0.0, g = 0.0, b = 0.0, a = 0.35 },
        timelineColor = { r = 0.85, g = 0.85, b = 0.85, a = 0.35 },
        nowMarkerColor = { r = 1.0, g = 1.0, b = 1.0, a = 0.85 },
        ssWindowColor = { r = 0.20, g = 0.75, b = 0.35, a = 0.35 },
        ssMarkerColor = { r = 0.90, g = 0.90, b = 0.90, a = 0.95 },
    }
}

--- @class HunterAPITimelineBar:CoreModule
local HunterAPITimelineBar = NAG:CreateModule("HunterAPITimelineBar", defaults, {
    moduleType = ns.MODULE_TYPES.CLASS,
    className = "HUNTER",
    optionsCategory = ns.MODULE_CATEGORIES.CLASS,
    messageHandlers = {
        NAG_FRAME_UPDATED = true,
    },
    hidden = function()
        return UnitClassBase("player") ~= "HUNTER"
    end,
})

ns.HunterAPITimelineBar = HunterAPITimelineBar
local module = HunterAPITimelineBar

-- ============================ LOCALS ============================
local frame
local background
local timelineLine
local nowMarker
local debugText
local lastUpdate = 0
local lastBarDebugPrintAt = 0
local lastStateShiftKey = nil

-- ============================ HELPERS ============================
local function Clamp(v, minV, maxV)
    if v < minV then
        return minV
    end
    if v > maxV then
        return maxV
    end
    return v
end

local function GetSpellIcon(spellId)
    if NAG and NAG.Spell and NAG.Spell[spellId] and NAG.Spell[spellId].icon then
        return NAG.Spell[spellId].icon
    end
    return GetSpellTexture(spellId) or "Interface\\Icons\\INV_Misc_QuestionMark"
end

local function IsDevModeEnabled()
    return NAG and NAG.IsDevModeEnabled and NAG:IsDevModeEnabled() or false
end

local function TimeToX(nowAt, timestamp, horizonSeconds, width)
    if horizonSeconds <= 0 or width <= 0 then
        return 0
    end
    local t = (timestamp - nowAt) / horizonSeconds
    t = Clamp(t, 0, 1)
    return t * width
end

local function HidePredictionOverlays()
    if not frame then
        return
    end

    if frame.ssWindows then
        for i = 1, #frame.ssWindows do
            frame.ssWindows[i]:Hide()
        end
    end
    if frame.ssMarkers then
        for i = 1, #frame.ssMarkers do
            frame.ssMarkers[i]:Hide()
        end
    end
    if frame.msMarker then
        frame.msMarker:Hide()
    end
    if frame.arMarker then
        frame.arMarker:Hide()
    end
    if frame.stateTicks then
        for i = 1, #frame.stateTicks do
            frame.stateTicks[i]:Hide()
        end
    end
    if frame.stateLabels then
        for i = 1, #frame.stateLabels do
            frame.stateLabels[i]:Hide()
        end
    end
end

local function CreateMaskedIcon(parent, size)
    local iconFrame = CreateFrame("Frame", nil, parent)
    iconFrame:SetSize(size, size)
    iconFrame.icon = iconFrame:CreateTexture(nil, "OVERLAY", nil, 7)
    iconFrame.icon:SetAllPoints()
    iconFrame.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    iconFrame.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
    local mask = iconFrame:CreateMaskTexture()
    mask:SetTexture("Interface/CHARACTERFRAME/TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    mask:SetAllPoints()
    iconFrame.icon:AddMaskTexture(mask)
    iconFrame.stateLabel = iconFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    iconFrame.stateLabel:SetPoint("BOTTOM", iconFrame, "TOP", 0, 1)
    iconFrame.stateLabel:SetTextColor(1.0, 0.95, 0.35, 1.0)
    iconFrame.stateLabel:SetText("")
    iconFrame.stateLabel:Hide()
    iconFrame:Hide()
    return iconFrame
end

local function EnsureVisualPools()
    if not frame then
        return
    end

    frame.ssWindows = frame.ssWindows or {}
    frame.ssMarkers = frame.ssMarkers or {}
    frame.stateTicks = frame.stateTicks or {}
    frame.stateLabels = frame.stateLabels or {}

    for i = 1, MAX_SS_WINDOWS do
        if not frame.ssWindows[i] then
            local tex = frame:CreateTexture(nil, "ARTWORK", nil, -2)
            tex:Hide()
            frame.ssWindows[i] = tex
        end
    end

    for i = 1, MAX_SS_MARKERS do
        if not frame.ssMarkers[i] then
            frame.ssMarkers[i] = CreateMaskedIcon(frame, module.db.class.iconSize or 16)
        end
    end

    for i = 1, MAX_STATE_TICKS do
        if not frame.stateTicks[i] then
            local tick = frame:CreateTexture(nil, "OVERLAY", nil, 6)
            tick:SetColorTexture(1.0, 0.90, 0.25, 0.80)
            tick:SetSize(1, 14)
            tick:Hide()
            frame.stateTicks[i] = tick
        end
        if not frame.stateLabels[i] then
            local label = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            label:SetTextColor(1.0, 0.95, 0.35, 1.0)
            label:SetJustifyH("CENTER")
            label:SetText("")
            label:Hide()
            frame.stateLabels[i] = label
        end
    end

    if not frame.msMarker then
        frame.msMarker = CreateMaskedIcon(frame, module.db.class.iconSize or 16)
    end
    if not frame.arMarker then
        frame.arMarker = CreateMaskedIcon(frame, module.db.class.iconSize or 16)
    end
end

local function BuildViewModel()
    local db = module.db.class
    local horizonSeconds = tonumber(db.horizonSeconds or DEFAULT_HORIZON_SECONDS) or DEFAULT_HORIZON_SECONDS
    if horizonSeconds <= 0 then
        horizonSeconds = DEFAULT_HORIZON_SECONDS
    end

    local nowAt = GetTime()
    local timeline = nil
    if NAG and NAG.TBCHunterPredictStateTimelineLive then
        timeline = NAG:TBCHunterPredictStateTimelineLive(horizonSeconds)
    elseif NAG and NAG.TBCHunterPredictStateTimeline then
        timeline = NAG:TBCHunterPredictStateTimeline(nil, horizonSeconds)
    end

    if timeline and timeline.now and timeline.now > 0 then
        nowAt = tonumber(timeline.now) or nowAt
    end

    local horizonEndAt = nowAt + horizonSeconds
    local windows = {}
    local ssMarkers = {}
    local stateDebug = {}
    local stateBoundaries = {}
    local activeStateId = 0
    local activeCycleIndex = 0

    if timeline and timeline.ok and timeline.states then
        activeStateId = tonumber(timeline.activeStateId or 0) or 0
        activeCycleIndex = tonumber(timeline.activeCycleIndex or 0) or 0
        for i = 1, #timeline.states do
            local state = timeline.states[i]
            if #stateDebug < 4 then
                stateDebug[#stateDebug + 1] = {
                    stateId = tonumber(state and state.stateId or 0) or 0,
                    cycleIndex = tonumber(state and state.cycleIndex or i) or i,
                    absoluteCycleIndex = tonumber(state and state.absoluteCycleIndex or 0) or 0,
                    autoAt = tonumber(state and state.autoAt or 0) or 0,
                    startAt = tonumber(state and state.effectiveGapStartAt or 0) or 0,
                    endAt = tonumber(state and state.effectiveGapEndAt or 0) or 0,
                    rawStartAt = tonumber(state and state.gapStartAt or 0) or 0,
                    rawEndAt = tonumber(state and state.gapEndAt or 0) or 0,
                    fillerSlotStartAt = tonumber(state and state.fillerSlotStartAt or 0) or 0,
                    fillerSlotEndAt = tonumber(state and state.fillerSlotEndAt or 0) or 0,
                    effectiveWindowValid = state and state.effectiveWindowValid == true or false,
                    ssFits = state and state.ssFits == true or false,
                    fillerSpell = tostring(state and state.fillerSpell or "none"),
                }
            end
            if #stateBoundaries < MAX_STATE_TICKS then
                stateBoundaries[#stateBoundaries + 1] = {
                    stateId = tonumber(state and state.stateId or 0) or 0,
                    cycleIndex = tonumber(state and state.cycleIndex or i) or i,
                    absoluteCycleIndex = tonumber(state and state.absoluteCycleIndex or 0) or 0,
                    autoAt = tonumber(state and state.autoAt or 0) or 0,
                }
            end
            local rawStartAt = tonumber(state and state.effectiveGapStartAt or 0) or 0
            local rawEndAt = tonumber(state and state.effectiveGapEndAt or 0) or 0
            if rawEndAt > nowAt and rawStartAt < horizonEndAt then
                local clippedStartAt = rawStartAt
                local clippedEndAt = rawEndAt
                if clippedStartAt < nowAt then
                    clippedStartAt = nowAt
                end
                if clippedEndAt > horizonEndAt then
                    clippedEndAt = horizonEndAt
                end
                if clippedEndAt > clippedStartAt then
                    windows[#windows + 1] = {
                        startAt = clippedStartAt,
                        endAt = clippedEndAt,
                        stateId = tonumber(state.stateId or 0) or 0,
                        cycleIndex = tonumber(state.cycleIndex or i) or i,
                        ssFits = state.ssFits == true,
                    }

                    local fullDuration = rawEndAt - rawStartAt
                    if fullDuration > 0 then
                        local markerAt = rawStartAt + (fullDuration * 0.70)
                        if markerAt < nowAt then
                            markerAt = nowAt
                        end
                        if markerAt >= nowAt and markerAt <= horizonEndAt then
                            ssMarkers[#ssMarkers + 1] = {
                                at = markerAt,
                                stateId = tonumber(state.stateId or 0) or 0,
                                cycleIndex = tonumber(state.cycleIndex or i) or i,
                                absoluteCycleIndex = tonumber(state.absoluteCycleIndex or 0) or 0,
                                label = string.format("%d", tonumber(state.stateId or 0) or 0),
                            }
                        end
                    end
                end
            end
        end
    end

    local nextMSAt = nil
    local nextARAt = nil
    local currentFillerSpell = "none"
    local currentFillerSlotStartAt = 0
    local currentFillerSlotEndAt = 0
    local currentFillerInWindow = false
    if timeline and timeline.nextMS and timeline.nextMS.found then
        local at = tonumber(timeline.nextMS.at or 0) or 0
        if at >= nowAt and at <= horizonEndAt then
            nextMSAt = at
        end
    end
    if timeline and timeline.nextAR and timeline.nextAR.found then
        local at = tonumber(timeline.nextAR.at or 0) or 0
        if at >= nowAt and at <= horizonEndAt then
            nextARAt = at
        end
    end

    if timeline and timeline.states then
        for i = 1, #timeline.states do
            local state = timeline.states[i]
            local slotStartAt = tonumber(state and state.fillerSlotStartAt or 0) or 0
            local slotEndAt = tonumber(state and state.fillerSlotEndAt or 0) or 0
            if slotStartAt <= nowAt and nowAt <= slotEndAt then
                currentFillerInWindow = true
                currentFillerSlotStartAt = slotStartAt
                currentFillerSlotEndAt = slotEndAt
                currentFillerSpell = tostring(state and state.fillerSpell or "none")
                if currentFillerSpell == "MS" then
                    nextMSAt = nowAt
                elseif currentFillerSpell == "AR" then
                    nextARAt = nowAt
                end
                break
            end
        end
    end

    return {
        ok = (timeline and timeline.ok) and true or false,
        nowAt = nowAt,
        horizonSeconds = horizonSeconds,
        windows = windows,
        ssMarkers = ssMarkers,
        nextMSAt = nextMSAt,
        nextARAt = nextARAt,
        activeStateId = activeStateId,
        activeCycleIndex = activeCycleIndex,
        stateDebug = stateDebug,
        stateBoundaries = stateBoundaries,
        currentFillerInWindow = currentFillerInWindow,
        currentFillerSpell = currentFillerSpell,
        currentFillerSlotStartAt = currentFillerSlotStartAt,
        currentFillerSlotEndAt = currentFillerSlotEndAt,
        timelineReason = timeline and timeline.reason or "timeline_unavailable",
    }
end

local function PrintBarDebugThrottled(model)
    if not IsDevModeEnabled() then
        return
    end
    if not model then
        return
    end

    local nowAt = tonumber(model.nowAt or GetTime()) or GetTime()
    if nowAt - lastBarDebugPrintAt < BAR_DEBUG_PRINT_INTERVAL_SECONDS then
        return
    end
    lastBarDebugPrintAt = nowAt

    local windows = model.windows or {}
    local w1 = windows[1] or {}
    local w2 = windows[2] or {}
    local currentGapStartIn = tonumber(w1.startAt or 0) - nowAt
    local currentGapEndIn = tonumber(w1.endAt or 0) - nowAt
    if currentGapStartIn < 0 then
        currentGapStartIn = 0
    end
    if currentGapEndIn < 0 then
        currentGapEndIn = 0
    end
    local w2StartIn = tonumber(w2.startAt or 0) - nowAt
    local w2EndIn = tonumber(w2.endAt or 0) - nowAt
    if w2StartIn < 0 then
        w2StartIn = 0
    end
    if w2EndIn < 0 then
        w2EndIn = 0
    end
    local nextMSIn = 0
    local nextARIn = 0
    if model.nextMSAt then
        nextMSIn = tonumber(model.nextMSAt or 0) - nowAt
        if nextMSIn < 0 then
            nextMSIn = 0
        end
    end
    if model.nextARAt then
        nextARIn = tonumber(model.nextARAt or 0) - nowAt
        if nextARIn < 0 then
            nextARIn = 0
        end
    end
    local fillerStartIn = tonumber(model.currentFillerSlotStartAt or 0) - nowAt
    local fillerEndIn = tonumber(model.currentFillerSlotEndAt or 0) - nowAt
    if fillerStartIn < 0 then
        fillerStartIn = 0
    end
    if fillerEndIn < 0 then
        fillerEndIn = 0
    end

    local states = model.stateDebug or {}
    local s1 = states[1] or {}
    local s2 = states[2] or {}
    local s3 = states[3] or {}
    local s4 = states[4] or {}
    local function SafeIn(at)
        local v = tonumber(at or 0) - nowAt
        if v < 0 then
            v = 0
        end
        return v
    end
    local stateShifted = false
    local currentShiftKey = string.format(
        "%d:%d",
        tonumber(s1.stateId or 0) or 0,
        tonumber(s1.absoluteCycleIndex or s1.cycleIndex or 0) or 0
    )
    if lastStateShiftKey and lastStateShiftKey ~= currentShiftKey then
        stateShifted = true
    end
    lastStateShiftKey = currentShiftKey

    print(string.format(
        "[TBCHUNTER_BAR][TIMELINE_DEBUG][v=%s] meaning=\"throttled 0.2s bar view of persistent state timeline with auto-boundary steps and filler-slot diagnostics\" now=%.3f horizon=%.3f activeState=%d activeCycle=%d stateShifted=%s fillNow=%s fillSpell=%s fillStartIn=%.3f fillEndIn=%.3f ssCount=%d ss1StartIn=%.3f ss1EndIn=%.3f ss2StartIn=%.3f ss2EndIn=%.3f st1_id=%d st1_cycle=%d st1_autoIn=%.3f st1_startIn=%.3f st1_endIn=%.3f st1_rawStartIn=%.3f st1_rawEndIn=%.3f st1_fillSlotStartIn=%.3f st1_fillSlotEndIn=%.3f st1_effValid=%s st1_ssFits=%s st1_fill=%s st2_id=%d st2_cycle=%d st2_autoIn=%.3f st2_startIn=%.3f st2_endIn=%.3f st2_fillSlotStartIn=%.3f st2_fillSlotEndIn=%.3f st2_effValid=%s st2_ssFits=%s st2_fill=%s st3_id=%d st3_cycle=%d st3_autoIn=%.3f st3_startIn=%.3f st3_endIn=%.3f st3_effValid=%s st3_ssFits=%s st3_fill=%s st4_id=%d st4_cycle=%d st4_autoIn=%.3f st4_startIn=%.3f st4_endIn=%.3f st4_effValid=%s st4_ssFits=%s st4_fill=%s nextMSIn=%.3f nextARIn=%.3f nextMSAt=%.3f nextARAt=%.3f reason=%s",
        BAR_DEBUG_PRINT_VERSION,
        nowAt,
        tonumber(model.horizonSeconds or 0) or 0,
        tonumber(model.activeStateId or 0) or 0,
        tonumber(model.activeCycleIndex or 0) or 0,
        tostring(stateShifted),
        tostring(model.currentFillerInWindow == true),
        tostring(model.currentFillerSpell or "none"),
        fillerStartIn,
        fillerEndIn,
        #windows,
        currentGapStartIn,
        currentGapEndIn,
        w2StartIn,
        w2EndIn,
        tonumber(s1.stateId or 0) or 0,
        tonumber(s1.absoluteCycleIndex or s1.cycleIndex or 0) or 0,
        SafeIn(s1.autoAt),
        s1.effectiveWindowValid and SafeIn(s1.startAt) or 0,
        s1.effectiveWindowValid and SafeIn(s1.endAt) or 0,
        SafeIn(s1.rawStartAt),
        SafeIn(s1.rawEndAt),
        SafeIn(s1.fillerSlotStartAt),
        SafeIn(s1.fillerSlotEndAt),
        tostring(s1.effectiveWindowValid == true),
        tostring(s1.ssFits == true),
        tostring(s1.fillerSpell or "none"),
        tonumber(s2.stateId or 0) or 0,
        tonumber(s2.absoluteCycleIndex or s2.cycleIndex or 0) or 0,
        SafeIn(s2.autoAt),
        s2.effectiveWindowValid and SafeIn(s2.startAt) or 0,
        s2.effectiveWindowValid and SafeIn(s2.endAt) or 0,
        SafeIn(s2.fillerSlotStartAt),
        SafeIn(s2.fillerSlotEndAt),
        tostring(s2.effectiveWindowValid == true),
        tostring(s2.ssFits == true),
        tostring(s2.fillerSpell or "none"),
        tonumber(s3.stateId or 0) or 0,
        tonumber(s3.absoluteCycleIndex or s3.cycleIndex or 0) or 0,
        SafeIn(s3.autoAt),
        s3.effectiveWindowValid and SafeIn(s3.startAt) or 0,
        s3.effectiveWindowValid and SafeIn(s3.endAt) or 0,
        tostring(s3.effectiveWindowValid == true),
        tostring(s3.ssFits == true),
        tostring(s3.fillerSpell or "none"),
        tonumber(s4.stateId or 0) or 0,
        tonumber(s4.absoluteCycleIndex or s4.cycleIndex or 0) or 0,
        SafeIn(s4.autoAt),
        s4.effectiveWindowValid and SafeIn(s4.startAt) or 0,
        s4.effectiveWindowValid and SafeIn(s4.endAt) or 0,
        tostring(s4.effectiveWindowValid == true),
        tostring(s4.ssFits == true),
        tostring(s4.fillerSpell or "none"),
        nextMSIn,
        nextARIn,
        tonumber(model.nextMSAt or 0) or 0,
        tonumber(model.nextARAt or 0) or 0,
        tostring(model.timelineReason or "none")
    ))
end

function module:UpdateFrameAnchor()
    if not frame then
        return
    end

    local db = self.db.class
    if not db.autoAnchor or not db.lockToNagAnchor then
        frame:SetParent(_G.UIParent)
        frame:ClearAllPoints()
        frame:SetPoint(db.point, db.x, db.y)
        return
    end

    local anchor = NAG.GetDisplayAnchor and NAG:GetDisplayAnchor() or nil
    if not anchor or anchor == _G.UIParent then
        frame:SetParent(_G.UIParent)
        frame:ClearAllPoints()
        frame:SetPoint(db.point, db.x, db.y)
        return
    end

    frame:SetParent(_G.UIParent)
    frame:ClearAllPoints()
    frame:SetPoint("TOP", anchor, "BOTTOM", db.x, db.y)
end

function module:NAG_FRAME_UPDATED()
    self:UpdateVisibility()
end

function module:UpdateVisibility()
    if not frame then
        self:CreateFrameUI()
        if not frame then
            return
        end
    end

    local db = self.db.class
    local isEditMode = NAG.IsAnyEditMode and NAG:IsAnyEditMode()
    if isEditMode then
        frame:SetFrameStrata("DIALOG")
        frame:SetFrameLevel(200)
        frame:Show()
        frame:SetScript("OnUpdate", function(_, elapsed)
            lastUpdate = lastUpdate + elapsed
            if lastUpdate >= UPDATE_INTERVAL then
                lastUpdate = 0
                self:UpdateDisplay()
            end
        end)
        return
    end

    local show = db.enabled and true or false
    if show and db.hideOutOfCombat and not UnitAffectingCombat("player") then
        show = false
    end

    if show then
        local dm = NAG.GetModule and NAG:GetModule("DisplayManager", true)
        local level = dm and dm.GetRecommendedClassBarFrameLevel and dm:GetRecommendedClassBarFrameLevel() or 50
        frame:SetFrameStrata("MEDIUM")
        frame:SetFrameLevel(level)
        frame:Show()
        frame:SetScript("OnUpdate", function(_, elapsed)
            lastUpdate = lastUpdate + elapsed
            if lastUpdate >= UPDATE_INTERVAL then
                lastUpdate = 0
                self:UpdateDisplay()
            end
        end)
    else
        frame:SetScript("OnUpdate", nil)
        frame:Hide()
    end
end

function module:UpdateDisplay()
    if not frame then
        return
    end
    -- Guard against partial UI init if frame creation failed earlier.
    if not background or not timelineLine or not nowMarker or not debugText then
        return
    end

    local db = self.db.class
    frame:SetSize(db.width, db.height)
    frame:SetAlpha(db.alpha or 1.0)
    self:UpdateFrameAnchor()

    background:SetShown(db.showBackground == true)
    background:SetColorTexture(
        db.backgroundColor.r,
        db.backgroundColor.g,
        db.backgroundColor.b,
        db.backgroundColor.a
    )
    background:ClearAllPoints()
    background:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    background:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)

    timelineLine:SetShown(db.showTimelineLine == true)
    timelineLine:SetColorTexture(
        db.timelineColor.r,
        db.timelineColor.g,
        db.timelineColor.b,
        db.timelineColor.a
    )
    timelineLine:SetHeight(2)
    timelineLine:ClearAllPoints()
    timelineLine:SetPoint("LEFT", frame, "LEFT", 0, 0)
    timelineLine:SetPoint("RIGHT", frame, "RIGHT", 0, 0)

    nowMarker:SetShown(db.showNowMarker == true)
    nowMarker:SetColorTexture(
        db.nowMarkerColor.r,
        db.nowMarkerColor.g,
        db.nowMarkerColor.b,
        db.nowMarkerColor.a
    )
    nowMarker:SetWidth(2)
    nowMarker:ClearAllPoints()
    nowMarker:SetPoint("TOP", frame, "TOPLEFT", 0, 0)
    nowMarker:SetPoint("BOTTOM", frame, "BOTTOMLEFT", 0, 0)

    EnsureVisualPools()
    HidePredictionOverlays()

    local model = BuildViewModel()
    PrintBarDebugThrottled(model)
    local width = frame:GetWidth()
    local height = frame:GetHeight()
    local halfHeight = height * 0.5
    local laneY = tonumber(db.markerLaneOffsetY or 0) or 0

    if db.showSSWindows then
        local shown = 0
        for i = 1, #model.windows do
            if shown >= MAX_SS_WINDOWS then
                break
            end
            local window = model.windows[i]
            local x1 = TimeToX(model.nowAt, window.startAt, model.horizonSeconds, width)
            local x2 = TimeToX(model.nowAt, window.endAt, model.horizonSeconds, width)
            if x2 > x1 then
                shown = shown + 1
                local tex = frame.ssWindows[shown]
                tex:SetColorTexture(
                    db.ssWindowColor.r,
                    db.ssWindowColor.g,
                    db.ssWindowColor.b,
                    db.ssWindowColor.a
                )
                tex:ClearAllPoints()
                tex:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", x1, -1)
                tex:SetSize(x2 - x1, height + 2)
                tex:Show()
            end
        end
    end

    if db.showSSIcons then
        local shown = 0
        local iconTexture = GetSpellIcon(STEADY_SHOT_ID)
        local showStateLabels = IsDevModeEnabled()
        for i = 1, #model.ssMarkers do
            if shown >= MAX_SS_MARKERS then
                break
            end
            local marker = model.ssMarkers[i]
            local x = TimeToX(model.nowAt, marker.at, model.horizonSeconds, width)
            shown = shown + 1
            local iconFrame = frame.ssMarkers[shown]
            iconFrame:SetSize(db.iconSize, db.iconSize)
            iconFrame.icon:SetTexture(iconTexture)
            iconFrame.icon:SetVertexColor(
                db.ssMarkerColor.r,
                db.ssMarkerColor.g,
                db.ssMarkerColor.b,
                db.ssMarkerColor.a
            )
            local dim = 1.0 - ((shown - 1) * 0.12)
            if dim < 0.35 then
                dim = 0.35
            end
            iconFrame:SetAlpha(dim)
            iconFrame:ClearAllPoints()
            iconFrame:SetPoint("CENTER", frame, "BOTTOMLEFT", x, halfHeight + laneY)
            if iconFrame.stateLabel then
                if showStateLabels then
                    local markerState = tonumber(marker.stateId or 0) or 0
                    local markerAbsCycle = tonumber(marker.absoluteCycleIndex or marker.cycleIndex or 0) or 0
                    iconFrame.stateLabel:SetText(string.format("%d.%d", markerState, markerAbsCycle))
                    iconFrame.stateLabel:Show()
                else
                    iconFrame.stateLabel:SetText("")
                    iconFrame.stateLabel:Hide()
                end
            end
            iconFrame:Show()
        end
    end

    if IsDevModeEnabled() and frame.stateTicks and frame.stateLabels then
        local shownTicks = 0
        local boundaries = model.stateBoundaries or {}
        for i = 1, #boundaries do
            if shownTicks >= MAX_STATE_TICKS then
                break
            end
            local boundary = boundaries[i]
            local autoAt = tonumber(boundary and boundary.autoAt or 0) or 0
            if autoAt >= model.nowAt and autoAt <= (model.nowAt + model.horizonSeconds) then
                shownTicks = shownTicks + 1
                local x = TimeToX(model.nowAt, autoAt, model.horizonSeconds, width)
                local tick = frame.stateTicks[shownTicks]
                local label = frame.stateLabels[shownTicks]
                tick:ClearAllPoints()
                tick:SetPoint("BOTTOM", frame, "BOTTOMLEFT", x, 1)
                tick:SetPoint("TOP", frame, "TOPLEFT", x, -1)
                tick:Show()
                label:ClearAllPoints()
                label:SetPoint("BOTTOM", frame, "TOPLEFT", x, 2)
                label:SetText(string.format("A%d.%d", tonumber(boundary.stateId or 0) or 0, tonumber(boundary.absoluteCycleIndex or boundary.cycleIndex or 0) or 0))
                label:Show()
            end
        end
    end

    local msX = nil
    local arX = nil
    if model.nextMSAt then
        msX = TimeToX(model.nowAt, model.nextMSAt, model.horizonSeconds, width)
    end
    if model.nextARAt then
        arX = TimeToX(model.nowAt, model.nextARAt, model.horizonSeconds, width)
    end

    if db.showMSMarker and msX then
        frame.msMarker:SetSize(db.iconSize, db.iconSize)
        frame.msMarker.icon:SetTexture(GetSpellIcon(MULTI_SHOT_ID))
        frame.msMarker:SetAlpha(1.0)
        frame.msMarker:ClearAllPoints()
        frame.msMarker:SetPoint("CENTER", frame, "BOTTOMLEFT", msX, halfHeight + laneY + (db.msOverlapOffsetY or 0))
        frame.msMarker:Show()
    end

    if db.showARMarker and arX then
        frame.arMarker:SetSize(db.iconSize, db.iconSize)
        frame.arMarker.icon:SetTexture(GetSpellIcon(ARCANE_SHOT_ID))
        frame.arMarker:SetAlpha(0.95)
        frame.arMarker:ClearAllPoints()
        frame.arMarker:SetPoint("CENTER", frame, "BOTTOMLEFT", arX, halfHeight + laneY + (db.arOverlapOffsetY or 0))
        frame.arMarker:Show()
    end

    debugText:SetShown(db.showDebugText == true)
    if db.showDebugText then
        local currentFillerStartIn = 0
        local currentFillerEndIn = 0
        if model.currentFillerInWindow then
            currentFillerStartIn = model.currentFillerSlotStartAt - model.nowAt
            currentFillerEndIn = model.currentFillerSlotEndAt - model.nowAt
            if currentFillerStartIn < 0 then
                currentFillerStartIn = 0
            end
            if currentFillerEndIn < 0 then
                currentFillerEndIn = 0
            end
        end
        debugText:ClearAllPoints()
        debugText:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", 0, -2)
        local stateDebug = model.stateDebug or {}
        local s1 = stateDebug[1] or {}
        local s2 = stateDebug[2] or {}
        local s1StartIn = s1.effectiveWindowValid and (tonumber(s1.startAt or 0) - model.nowAt) or 0
        local s1EndIn = s1.effectiveWindowValid and (tonumber(s1.endAt or 0) - model.nowAt) or 0
        local s2StartIn = s2.effectiveWindowValid and (tonumber(s2.startAt or 0) - model.nowAt) or 0
        local s2EndIn = s2.effectiveWindowValid and (tonumber(s2.endAt or 0) - model.nowAt) or 0
        if s1StartIn < 0 then
            s1StartIn = 0
        end
        if s1EndIn < 0 then
            s1EndIn = 0
        end
        if s2StartIn < 0 then
            s2StartIn = 0
        end
        if s2EndIn < 0 then
            s2EndIn = 0
        end
        debugText:SetText(string.format(
            "H=%.1f SS=%d activeState=%d cycle=%d s1[id=%d c=%d %.2f->%.2f valid=%s fit=%s] s2[id=%d c=%d %.2f->%.2f valid=%s fit=%s] fillNow=%s fillSpell=%s fillStartIn=%.3f fillEndIn=%.3f reason=%s",
            tonumber(model.horizonSeconds or 0) or 0,
            #model.windows,
            tonumber(model.activeStateId or 0) or 0,
            tonumber(model.activeCycleIndex or 0) or 0,
            tonumber(s1.stateId or 0) or 0,
            tonumber(s1.absoluteCycleIndex or s1.cycleIndex or 0) or 0,
            tonumber(s1StartIn or 0) or 0,
            tonumber(s1EndIn or 0) or 0,
            tostring(s1.effectiveWindowValid == true),
            tostring(s1.ssFits == true),
            tonumber(s2.stateId or 0) or 0,
            tonumber(s2.absoluteCycleIndex or s2.cycleIndex or 0) or 0,
            tonumber(s2StartIn or 0) or 0,
            tonumber(s2EndIn or 0) or 0,
            tostring(s2.effectiveWindowValid == true),
            tostring(s2.ssFits == true),
            tostring(model.currentFillerInWindow == true),
            tostring(model.currentFillerSpell or "none"),
            tonumber(currentFillerStartIn or 0) or 0,
            tonumber(currentFillerEndIn or 0) or 0,
            tostring(model.timelineReason or "none")
        ))
    end
end

-- ============================ UI BUILD ============================
function module:CreateFrameUI()
    if frame then
        return
    end

    OptionsFactory = NAG:GetModule("OptionsFactory")
    local db = self.db.class

    frame = CreateFrame("Frame", "NAGHunterAPITimelineBar", _G.UIParent)
    frame:SetSize(db.width, db.height)
    frame:SetPoint(db.point, db.x, db.y)
    frame:SetAlpha(db.alpha or 1.0)
    frame:Hide()
    frame:SetMovable(true)
    frame:RegisterForDrag("LeftButton")
    frame:EnableMouse(NAG.IsAnyEditMode and NAG:IsAnyEditMode())
    frame:SetScript("OnDragStart", function()
        local canDrag = NAG.IsAnyEditMode and NAG:IsAnyEditMode()
        if not canDrag or (UnitAffectingCombat and UnitAffectingCombat("player")) then
            return
        end
        frame:StartMoving()
    end)
    frame:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
        local point, _, _, x, y = frame:GetPoint(1)
        db.point = point
        db.x = x
        db.y = y
    end)

    background = frame:CreateTexture(nil, "BACKGROUND", nil, -8)
    timelineLine = frame:CreateTexture(nil, "ARTWORK", nil, -4)
    nowMarker = frame:CreateTexture(nil, "OVERLAY", nil, 7)
    debugText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    debugText:SetJustifyH("LEFT")
    debugText:SetText("")
    debugText:Hide()

    EnsureVisualPools()
end

-- ============================ EVENTS ============================
module.eventHandlers = {
    PLAYER_ENTERING_WORLD = true,
    PLAYER_REGEN_DISABLED = true,
    PLAYER_REGEN_ENABLED = true,
}

function module:PLAYER_ENTERING_WORLD()
    self:UpdateVisibility()
end

function module:PLAYER_REGEN_DISABLED()
    self:UpdateVisibility()
end

function module:PLAYER_REGEN_ENABLED()
    self:UpdateVisibility()
end

-- ============================ LIFECYCLE ============================
function module:ModuleInitialize()
end

function module:ModuleEnable()
    if UnitClassBase("player") ~= "HUNTER" then
        self:SetEnabledState(false)
        return
    end
    self:CreateFrameUI()
    self:UpdateVisibility()
end

function module:ModuleDisable()
    if frame then
        frame:SetScript("OnUpdate", nil)
        frame:Hide()
    end
end

-- ============================ OPTIONS ============================
function module:GetOptions()
    if not OptionsFactory then
        OptionsFactory = NAG:GetModule("OptionsFactory")
    end

    return {
        type = "group",
        name = "Hunter API Timeline Bar",
        order = 29,
        width = "full",
        args = {
            enabled = OptionsFactory:CreateToggle(
                "Enabled",
                "Enable/disable the Hunter API timeline bar.",
                function() return self:GetSetting("class", "enabled") end,
                function(_, value)
                    self:SetSetting("class", "enabled", value)
                    if value then self:Enable() else self:Disable() end
                end,
                { order = 1 }
            ),
            hideOutOfCombat = OptionsFactory:CreateToggle(
                "Hide Out of Combat",
                "Hide this bar when out of combat.",
                function() return self:GetSetting("class", "hideOutOfCombat") end,
                function(_, value)
                    self:SetSetting("class", "hideOutOfCombat", value)
                    self:UpdateVisibility()
                end,
                { order = 2 }
            ),
            autoAnchor = OptionsFactory:CreateToggle(
                "Auto Anchor",
                "Anchor this bar relative to NAG display anchor when available.",
                function() return self:GetSetting("class", "autoAnchor") end,
                function(_, value)
                    self:SetSetting("class", "autoAnchor", value)
                    if frame then self:UpdateDisplay() end
                end,
                { order = 3 }
            ),
            lockToNagAnchor = OptionsFactory:CreateToggle(
                "Lock To NAG Anchor",
                "When auto anchor is enabled, lock this bar to NAG anchor.",
                function() return self:GetSetting("class", "lockToNagAnchor") end,
                function(_, value)
                    self:SetSetting("class", "lockToNagAnchor", value)
                    if frame then self:UpdateDisplay() end
                end,
                { order = 4 }
            ),
            anchorOffsetX = OptionsFactory:CreateRange(
                "Anchor Offset X",
                "Horizontal anchor offset.",
                function() return self:GetSetting("class", "x") end,
                function(_, value)
                    self:SetSetting("class", "x", value)
                    if frame then self:UpdateDisplay() end
                end,
                { min = -600, max = 600, step = 1, order = 5 }
            ),
            anchorOffsetY = OptionsFactory:CreateRange(
                "Anchor Offset Y",
                "Vertical anchor offset.",
                function() return self:GetSetting("class", "y") end,
                function(_, value)
                    self:SetSetting("class", "y", value)
                    if frame then self:UpdateDisplay() end
                end,
                { min = -600, max = 600, step = 1, order = 6 }
            ),
            width = OptionsFactory:CreateRange(
                "Width",
                "Bar width.",
                function() return self:GetSetting("class", "width") end,
                function(_, value)
                    self:SetSetting("class", "width", value)
                    if frame then self:UpdateDisplay() end
                end,
                { min = 120, max = 720, step = 1, order = 10 }
            ),
            height = OptionsFactory:CreateRange(
                "Height",
                "Bar height.",
                function() return self:GetSetting("class", "height") end,
                function(_, value)
                    self:SetSetting("class", "height", value)
                    if frame then self:UpdateDisplay() end
                end,
                { min = 8, max = 60, step = 1, order = 11 }
            ),
            alpha = OptionsFactory:CreateRange(
                "Alpha",
                "Bar transparency.",
                function() return self:GetSetting("class", "alpha") end,
                function(_, value)
                    self:SetSetting("class", "alpha", value)
                    if frame then self:UpdateDisplay() end
                end,
                { min = 0.05, max = 1.0, step = 0.01, order = 12 }
            ),
            horizonSeconds = OptionsFactory:CreateRange(
                "Horizon Seconds",
                "Prediction horizon shown in bar width.",
                function() return self:GetSetting("class", "horizonSeconds") end,
                function(_, value)
                    self:SetSetting("class", "horizonSeconds", value)
                    if frame then self:UpdateDisplay() end
                end,
                { min = 3.0, max = 10.0, step = 0.1, order = 13 }
            ),
            iconSize = OptionsFactory:CreateRange(
                "Icon Size",
                "Prediction icon size.",
                function() return self:GetSetting("class", "iconSize") end,
                function(_, value)
                    self:SetSetting("class", "iconSize", value)
                    if frame then self:UpdateDisplay() end
                end,
                { min = 10, max = 40, step = 1, order = 14 }
            ),
            markerLaneOffsetY = OptionsFactory:CreateRange(
                "Marker Lane Y Offset",
                "Vertical offset for prediction marker lane.",
                function() return self:GetSetting("class", "markerLaneOffsetY") end,
                function(_, value)
                    self:SetSetting("class", "markerLaneOffsetY", value)
                    if frame then self:UpdateDisplay() end
                end,
                { min = -40, max = 40, step = 1, order = 15 }
            ),
            msOverlapOffsetY = OptionsFactory:CreateRange(
                "MS Overlap Y",
                "MS vertical offset when overlaid in the same lane.",
                function() return self:GetSetting("class", "msOverlapOffsetY") end,
                function(_, value)
                    self:SetSetting("class", "msOverlapOffsetY", value)
                    if frame then self:UpdateDisplay() end
                end,
                { min = -40, max = 40, step = 1, order = 16 }
            ),
            arOverlapOffsetY = OptionsFactory:CreateRange(
                "AR Overlap Y",
                "AR vertical offset when overlaid in the same lane.",
                function() return self:GetSetting("class", "arOverlapOffsetY") end,
                function(_, value)
                    self:SetSetting("class", "arOverlapOffsetY", value)
                    if frame then self:UpdateDisplay() end
                end,
                { min = -40, max = 40, step = 1, order = 17 }
            ),
            showSSWindows = OptionsFactory:CreateToggle(
                "Show SS Windows",
                "Render predicted SS window segments.",
                function() return self:GetSetting("class", "showSSWindows") end,
                function(_, value)
                    self:SetSetting("class", "showSSWindows", value)
                    if frame then self:UpdateDisplay() end
                end,
                { order = 30 }
            ),
            showSSIcons = OptionsFactory:CreateToggle(
                "Show SS Icons",
                "Render SS markers (70% inside each predicted SS gap).",
                function() return self:GetSetting("class", "showSSIcons") end,
                function(_, value)
                    self:SetSetting("class", "showSSIcons", value)
                    if frame then self:UpdateDisplay() end
                end,
                { order = 31 }
            ),
            showMSMarker = OptionsFactory:CreateToggle(
                "Show MS Marker",
                "Render next predicted Multi-Shot marker.",
                function() return self:GetSetting("class", "showMSMarker") end,
                function(_, value)
                    self:SetSetting("class", "showMSMarker", value)
                    if frame then self:UpdateDisplay() end
                end,
                { order = 32 }
            ),
            showARMarker = OptionsFactory:CreateToggle(
                "Show AR Marker",
                "Render next predicted Arcane Shot marker.",
                function() return self:GetSetting("class", "showARMarker") end,
                function(_, value)
                    self:SetSetting("class", "showARMarker", value)
                    if frame then self:UpdateDisplay() end
                end,
                { order = 33 }
            ),
            showDebugText = OptionsFactory:CreateToggle(
                "Show Debug Text",
                "Show concise API-chain debug text below bar.",
                function() return self:GetSetting("class", "showDebugText") end,
                function(_, value)
                    self:SetSetting("class", "showDebugText", value)
                    if frame then self:UpdateDisplay() end
                end,
                { order = 34 }
            ),
        }
    }
end

return HunterAPITimelineBar
