--- @module "NAG.PaladinRetTwistBar"
--- Visual swing + GCD timing bar for validating Ret seal twisting math against SwedgeTimer.
---
--- Phase 1 (current): show only
--- - Swing bar (time to next mainhand swing)
--- - GCD bar (time to GCD ready)
---
--- Phase 2 (later): add twist window overlays (last ~0.4s + delay buffers) and "can twist" highlight.
---
--- License: CC BY-NC 4.0 (https://creativecommons.org/licenses/by-nc/4.0/legalcode)
--- Authors: Rakizi, Fonsas
--- Discord: https://discord.gg/ebonhold

-- ============================ LOCALIZE ============================
local _, ns = ...

local GetTime = _G.GetTime
local UnitClassBase = _G.UnitClassBase
local UnitAffectingCombat = _G.UnitAffectingCombat
local CreateFrame = _G.CreateFrame
local GetInventoryItemTexture = _G.GetInventoryItemTexture
local EasyMenu = _G.EasyMenu
local CloseDropDownMenus = _G.CloseDropDownMenus
local ToggleDropDownMenu = _G.ToggleDropDownMenu
local UIDropDownMenu_Initialize = _G.UIDropDownMenu_Initialize
local UIDropDownMenu_AddButton = _G.UIDropDownMenu_AddButton
local StaticPopup_Show = _G.StaticPopup_Show
local StaticPopupDialogs = _G.StaticPopupDialogs
local InCombatLockdown = _G.InCombatLockdown
local ReloadUI = _G.ReloadUI

--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")

local swingTimerLib = ns.LibClassicSwingTimerAPI
local OptionsFactory

-- ============================ DEFAULTS ============================
local defaults = {
    class = {
        enabled = true,
        showBar = true,
        hideOutOfCombat = false,
        -- Debug prints are intentionally always-on (throttled) while we validate math vs SwedgeTimer.
        debugThrottleSeconds = 0.25,

        -- Positioning
        autoAnchor = true, -- Anchor relative to NAG primary frame when available
        anchorSide = "bottom", -- "bottom" = below NAG frame, "right" = to the right of NAG frame
        point = "CENTER",
        x = 140,
        y = 33,

        -- Dimensions
        width = 220,
        height = 6,
        alpha = 1.0,
        showSwingIconSpark = true,
        userPositioned = false,

        -- Twist window visualization
        showTwistWindow = true,
        twistWindowSeconds = 0.4,   -- The classic SoC twist window (~0.4s before swing)
        -- NOTE: We intentionally do not show a separate "GCD end marker" line for now.
        -- The GCD overlay bar already provides this information visually.
        --
        -- SwedgeTimer-style "div" boundary marker:
        -- A moving tick that sits left of the swing marker by (twistWindow + lastGcdDuration),
        -- showing the last point where a fresh GCD would still end before the twist window opens.
        showDivBoundaryMarker = true,

        -- Appearance
        -- Swing bar itself is intentionally invisible; we show only the spark line (ShamanWeaveBar-style).
        swingColor = { r = 0.30, g = 0.75, b = 0.30, a = 0.0 },
        -- Slightly brighter to be easy to see over the background (matches ShamanWeaveBar vibe).
        gcdColor = { r = 0.40, g = 0.40, b = 0.40, a = 0.95 },
        backgroundColor = { r = 0.0, g = 0.0, b = 0.0, a = 0.35 },
        sparkColor = { r = 0.9, g = 0.9, b = 0.9, a = 0.9 },

        -- Twist window colors
        twistWindowColor = { r = 0.90, g = 0.90, b = 0.90, a = 0.18 },     -- full 0.4s window
        divMarkerColor = { r = 0.95, g = 0.75, b = 0.10, a = 0.95 },       -- yellow/orange boundary tick
    }
}

--- @class PaladinRetTwistBar:CoreModule
local PaladinRetTwistBar = NAG:CreateModule("PaladinRetTwistBar", defaults, {
    moduleType = ns.MODULE_TYPES.CLASS,
    className = "PALADIN",
    optionsCategory = ns.MODULE_CATEGORIES.CLASS,
    hidden = function()
        return UnitClassBase("player") ~= "PALADIN"
    end,
    messageHandlers = {
        NAG_FRAME_UPDATED = true,
    },
})

ns.PaladinRetTwistBar = PaladinRetTwistBar
local module = PaladinRetTwistBar

-- ============================ LOCALS ============================
local frame
local background
local swingBar
local gcdBar
local swingSpark
local pastSwingSpark
local swingIconSparkFrame
local swingIconSparkBackground
local swingIconSparkIcon
local swingIconSparkMask
local lastSwingIconTexture
local gcdSpark
local gcdSparkLeft
local twistWindowBar
local twistZeroSpark
local divBoundaryMarker
local twistOutcomeText
local clickCatcher

local UPDATE_INTERVAL = 0.016 -- ~60fps
local lastUpdate = 0

-- ============================ POPUPS ============================
-- Avoid re-registering popups on reloads.
if StaticPopupDialogs and not StaticPopupDialogs.NAG_RET_TWIST_BAR_DISABLE_CONFIRM then
    StaticPopupDialogs.NAG_RET_TWIST_BAR_DISABLE_CONFIRM = {
        text = "Disable Ret Twist Bar?",
        button1 = "Disable",
        button2 = "Cancel",
        OnAccept = function(dialog, data)
            local payload = data or (dialog and dialog.data) or nil
            if not payload or not payload.module then
                return
            end
            local m = payload.module
            if m.db and m.db.class then
                m.db.class.enabled = false
            end
            m:Disable()
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3,
    }
end

if StaticPopupDialogs and not StaticPopupDialogs.NAG_RET_TWIST_BAR_RESET_CONFIRM then
    StaticPopupDialogs.NAG_RET_TWIST_BAR_RESET_CONFIRM = {
        text = "Restore Ret Twist Bar defaults?",
        button1 = "Restore",
        button2 = "Cancel",
        OnAccept = function(dialog, data)
            local payload = data or (dialog and dialog.data) or nil
            if not payload or not payload.module then
                return
            end
            local m = payload.module
            if not (m.db and m.db.class) then
                return
            end

            -- Clear current settings and re-apply defaults (copy tables so we don't share refs).
            for k in pairs(m.db.class) do
                m.db.class[k] = nil
            end
            for k, v in pairs(defaults.class) do
                if type(v) == "table" and v.r ~= nil and v.g ~= nil and v.b ~= nil then
                    m.db.class[k] = { r = v.r, g = v.g, b = v.b, a = v.a or 1 }
                else
                    m.db.class[k] = v
                end
            end

            -- Ensure the bar comes back visible after reset (matches defaults).
            if m.UpdateVisibility then
                m:UpdateVisibility()
            end
            if m.UpdateDisplay then
                m:UpdateDisplay()
            end

            -- Auto reload to ensure all UI state reflects the restored defaults.
            if InCombatLockdown and InCombatLockdown() then
                m._pendingReloadUI = true
                if m.Print then
                    m:Print("Ret Twist Bar defaults restored. UI will reload after combat.")
                end
                return
            end
            if ReloadUI then
                ReloadUI()
            end
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3,
    }
end

-- ============================ HELPERS ============================
local function Clamp01(x)
    if x < 0 then return 0 end
    if x > 1 then return 1 end
    return x
end

--- Timeline geometry: 25% history + 100% future in a fixed-width bar.
--- We reserve 20% of the bar width for history (0.25 / 1.25) and keep the remaining
--- 80% for the upcoming swing (0..swingSpeed).
--- @param width number
--- @param swingSpeed number
--- @return number historyPx
--- @return number futurePx
local function GetTimelineGeometry(width, swingSpeed)
    if not width or width <= 0 or not swingSpeed or swingSpeed <= 0 then
        return 0, width or 0
    end

    local historyPx = width * 0.20
    local futurePx = width - historyPx
    if futurePx < 0 then futurePx = 0 end
    return historyPx, futurePx
end

--- Convert seconds-before-swing to X offset within the bar.
--- 0 seconds maps to the swing boundary at x=historyPx.
--- Positive seconds map into the future region to the right.
--- Negative seconds map into the history region to the left (clamped to -0.25 swing).
--- @param secondsBeforeSwing number
--- @param width number
--- @param swingSpeed number
--- @return number xPx
local function SecondsBeforeSwingToX(secondsBeforeSwing, width, swingSpeed)
    local historyPx, futurePx = GetTimelineGeometry(width, swingSpeed)
    if not swingSpeed or swingSpeed <= 0 or not width or width <= 0 or futurePx <= 0 then
        return historyPx
    end

    local s = secondsBeforeSwing or 0
    local minS = -0.25 * swingSpeed
    if s < minS then s = minS end
    if s > swingSpeed then s = swingSpeed end

    local x = historyPx + (s / swingSpeed) * futurePx
    if x < 0 then x = 0 end
    if x > width then x = width end
    return x
end

local function buildSuccessToast(twistSpellId)
    local label = "SoB/SoM"
    if twistSpellId == 31892 or twistSpellId == 31893 then
        label = "SoB"
    elseif twistSpellId == 348700 or twistSpellId == 348701 then
        label = "SoM"
    end

    return {
        text = string.format("Successful Twist"),
        r = 0.20,
        g = 0.85,
        b = 0.35,
    }
end

local function GetMainhandSwing()
    if swingTimerLib and swingTimerLib.UnitSwingTimerInfo then
        local speed, expiration = swingTimerLib:UnitSwingTimerInfo("player", "mainhand")
        if speed and expiration then
            return math.max(0, expiration - GetTime()), speed
        end
    end
    return 0, 0
end

local function To01(b)
    return b and 1 or 0
end

function PaladinRetTwistBar:UpdateFrameAnchor()
    if not frame then
        return
    end

    local db = self.db.class
    local anchor = NAG.GetDisplayAnchor and NAG:GetDisplayAnchor() or nil
    local anchorValid = anchor and anchor ~= _G.UIParent

    -- When autoAnchor is true but anchor is temporarily invalid (e.g. during lock transition),
    -- db.x/db.y hold anchor-relative offsets, not UIParent coords. Do NOT apply the fallback
    -- or we would misplace the bar. Leave the frame where it is (position from last OnDragStop).
    if db.autoAnchor and not anchorValid then
        return
    end

    if not db.autoAnchor then
        frame:SetParent(_G.UIParent)
        frame:ClearAllPoints()
        frame:SetPoint(db.point, _G.UIParent, db.point, db.x, db.y)
        return
    end

    -- Keep on UIParent so we don't affect the main frame (e.g. floating selector position)
    frame:SetParent(_G.UIParent)
    frame:ClearAllPoints()
    if db.anchorSide == "right" then
        local dm = NAG:GetModule("DisplayManager", true)
        if dm and dm.AnchorFrameToRightOfDisplay then
            dm:AnchorFrameToRightOfDisplay(frame, "BOTTOMLEFT", db.x or 8, db.y or 0)
        else
            frame:SetPoint("BOTTOMLEFT", anchor, "BOTTOMRIGHT", db.x or 8, db.y or 0)
        end
    else
        frame:SetPoint("TOP", anchor, "BOTTOM", db.x, db.y)
    end
end

function PaladinRetTwistBar:UpdateVisibility()
    if not frame then
        return
    end

    local db = self.db.class
    if not db.showBar then
        frame:Hide()
        frame:SetScript("OnUpdate", nil)
        return
    end

    if NAG.IsTBCRetBarsEnabled and not NAG:IsTBCRetBarsEnabled() then
        frame:Hide()
        frame:SetScript("OnUpdate", nil)
        return
    end

    -- In edit mode: force visible, raise strata/level above NAG display frames.
    -- Match HunterWeaveBar: do NOT call UpdateFrameAnchor in edit mode - frame stays where it is.
    if NAG.IsAnyEditMode and NAG:IsAnyEditMode() then
        frame:SetFrameStrata("DIALOG")
        frame:SetFrameLevel(200)
        frame:EnableMouse(true)
        frame:Show()
        frame:SetScript("OnUpdate", function(_, elapsed)
            lastUpdate = lastUpdate + elapsed
            if lastUpdate >= UPDATE_INTERVAL then
                self:UpdateDisplay()
                lastUpdate = 0
            end
        end)
        if clickCatcher then
            clickCatcher:EnableMouse(true)
        end
        return
    end

    if db.hideOutOfCombat and not UnitAffectingCombat("player") then
        frame:Hide()
        frame:SetScript("OnUpdate", nil)
        return
    end

    local dm = NAG:GetModule("DisplayManager", true)
    local level = dm and dm.GetRecommendedClassBarFrameLevel and dm:GetRecommendedClassBarFrameLevel() or 50
    frame:SetFrameStrata("MEDIUM")
    frame:SetFrameLevel(level)
    frame:EnableMouse(false)
    frame:Show()
    if clickCatcher then
        clickCatcher:EnableMouse(NAG.IsAnyEditMode and NAG:IsAnyEditMode())
    end
    -- Alpha will be dynamically adjusted in UpdateDisplay based on SoC + twist readiness
    self:UpdateFrameAnchor()
    frame:SetScript("OnUpdate", function(_, elapsed)
        lastUpdate = lastUpdate + elapsed
        if lastUpdate >= UPDATE_INTERVAL then
            self:UpdateDisplay()
            lastUpdate = 0
        end
    end)
end

function PaladinRetTwistBar:UpdateDisplay()
    if not frame then return end

    local db = self.db.class
    if not db.showBar then return end
    if NAG.IsTBCRetBarsEnabled and not NAG:IsTBCRetBarsEnabled() then
        frame:Hide()
        return
    end
    if db.hideOutOfCombat and not UnitAffectingCombat("player") then return end

    -- Seal state (used for gating some visuals like the weapon spark / twist window overlay).
    local soCActive = NAG.RetTwistIsSoCActive and NAG:RetTwistIsSoCActive() or false

    -- Keep the entire module alpha stable (no shifting based on seals).
    local targetAlpha = (db.alpha or 1.0)
    frame:SetAlpha(targetAlpha)

    local rawSwingLeft, swingSpeed = GetMainhandSwing()
    if not swingSpeed or swingSpeed <= 0 then
        -- Fallback to NAG helper if swingTimerLib isn't reporting yet.
        local _, raw = NAG:AutoTimeToNext()
        rawSwingLeft = raw or 0
        swingSpeed = NAG:AutoSwingTime() or 0
    end

    if not swingSpeed or swingSpeed <= 0 then
        frame:Hide()
        return
    end

    local width = db.width
    local baseHeight = db.height
    local swingHeight = baseHeight + 5
    local gcdHeight = 2
    local gcdGap = 6
    local gcdSparkHeight = 5

    -- Total frame height must fit swing lane + gap + gcd lane (including spark protrusion).
    local totalHeight = swingHeight + gcdGap + gcdSparkHeight
    frame:SetSize(width, totalHeight)

    -- ============================ TIMELINE (25% HISTORY) ============================
    -- Represent 1.25 swing cycles: 0.25 swing history + 1.0 swing future.
    -- The "swing moment" (0s before swing) is the boundary after the history region.
    local historyPx, futurePx = GetTimelineGeometry(width, swingSpeed)
    local swingCenterY = (totalHeight / 2) - (swingHeight / 2)
    local gcdCenterY = swingCenterY - (swingHeight / 2) - gcdGap - (gcdHeight / 2)

    -- Background should ONLY cover the swing lane (GCD lane intentionally sits outside the background borders).
    if background then
        background:ClearAllPoints()
        background:SetPoint("LEFT", frame, "LEFT", 0, swingCenterY)
        background:SetSize(width, swingHeight)
        background:Show()
    end

    -- Swing bar: remaining time (shrinks right -> left), anchored at the swing boundary.
    swingBar:ClearAllPoints()
    swingBar:SetPoint("LEFT", frame, "LEFT", historyPx, swingCenterY)
    local swingProgress = Clamp01((rawSwingLeft or 0) / swingSpeed)
    swingBar:SetWidth(futurePx * swingProgress)
    swingBar:SetHeight(swingHeight)
    swingBar:Show()

    -- Swing spark: a vertical line at the end of the swing bar (the moment the swing will occur).
    swingSpark:SetSize(2, swingHeight)
    swingSpark:ClearAllPoints()
    swingSpark:SetPoint("CENTER", swingBar, "RIGHT", 0, 0)
    swingSpark:Show()

    -- Optional weapon icon spark (circular) positioned above the swing marker to avoid blocking the bar.
    if swingIconSparkFrame then
        -- Only show this spark when SoC is active (otherwise it should be fully transparent).
        if db.showSwingIconSpark and soCActive then
            local iconTexture = GetInventoryItemTexture and GetInventoryItemTexture("player", 16) or nil -- INVSLOT_MAINHAND = 16
            if iconTexture and iconTexture ~= lastSwingIconTexture then
                lastSwingIconTexture = iconTexture
                if swingIconSparkIcon then
                    swingIconSparkIcon:SetTexture(iconTexture)
                end
            end

            local swingMarkerX = historyPx + (swingBar:GetWidth() or 0)
            local iconSize = swingIconSparkFrame:GetWidth() or 16
            local y = swingCenterY + (swingHeight / 2) + (iconSize / 2) + 1 + 12
            swingIconSparkFrame:ClearAllPoints()
            swingIconSparkFrame:SetPoint("CENTER", frame, "LEFT", swingMarkerX, y)
            if swingIconSparkBackground then
                swingIconSparkBackground:Show()
            end
            swingIconSparkFrame:Show()
        else
            swingIconSparkFrame:Hide()
            if swingIconSparkBackground then
                swingIconSparkBackground:Hide()
            end
        end
    end

    -- Past swing spark: show the most recent swing in the 25% history region.
    -- It starts at the swing boundary (historyPx) and moves left over (0.25 * swingSpeed).
    if pastSwingSpark and historyPx and swingSpeed and swingSpeed > 0 then
        local timeSinceSwing = swingSpeed - (rawSwingLeft or 0)
        local historySeconds = swingSpeed * 0.25
        if timeSinceSwing < 0 then timeSinceSwing = 0 end

        if historySeconds > 0 and timeSinceSwing <= historySeconds then
            local t = Clamp01(timeSinceSwing / historySeconds)
            local x = historyPx * (1 - t)
            pastSwingSpark:SetSize(2, swingHeight)
            pastSwingSpark:ClearAllPoints()
            pastSwingSpark:SetPoint("CENTER", frame, "LEFT", x, swingCenterY)
            pastSwingSpark:Show()
        else
            pastSwingSpark:Hide()
        end
    end

    -- ============================ GCD LANE (separate, below swing lane) ============================
    -- GCD bar: 2px height, positioned 6px below the swing lane so it doesn't block the view.
    local gcd = NAG:GCDTimeToReady() or 0
    local clampedGcd = gcd
    if clampedGcd < 0 then clampedGcd = 0 end
    if clampedGcd > swingSpeed then clampedGcd = swingSpeed end
    gcdBar:ClearAllPoints()
    gcdBar:SetPoint("LEFT", frame, "LEFT", historyPx, gcdCenterY)
    local gcdProgress = Clamp01(clampedGcd / swingSpeed)
    gcdBar:SetWidth(futurePx * gcdProgress)
    gcdBar:SetHeight(gcdHeight)
    if gcd > 0 then
        gcdBar:Show()
        -- Right spark (5px tall), bottom-aligned to the GCD bar.
        gcdSpark:SetSize(2, gcdSparkHeight)
        gcdSpark:ClearAllPoints()
        gcdSpark:SetPoint("BOTTOM", gcdBar, "BOTTOMRIGHT", 0, 0)
        gcdSpark:Show()

        -- Left spark (5px tall), bottom-aligned to the GCD bar.
        if gcdSparkLeft then
            gcdSparkLeft:SetSize(2, gcdSparkHeight)
            gcdSparkLeft:ClearAllPoints()
            gcdSparkLeft:SetPoint("BOTTOM", gcdBar, "BOTTOMLEFT", 0, 0)
            gcdSparkLeft:Show()
        end
    else
        gcdBar:Hide()
        gcdSpark:Hide()
        if gcdSparkLeft then
            gcdSparkLeft:Hide()
        end
    end

    -- ============================ TWIST WINDOW VISUALIZATION ============================
    -- Twist window bar only shows when SoC is the active seal, but the "zero spark" stays visible
    -- whenever the option is enabled (acts as a fixed reference mark).
    if db.showTwistWindow and twistWindowBar then
        local window = db.twistWindowSeconds or 0.4
        if window < 0 then window = 0 end
        if window > swingSpeed then window = swingSpeed end

        -- Twist window sits in the last ~0.4s before the swing, starting at the swing boundary.
        local windowPx = futurePx * Clamp01(window / swingSpeed)

        twistWindowBar:SetHeight(swingHeight)
        twistWindowBar:SetWidth(windowPx)
        twistWindowBar:ClearAllPoints()
        twistWindowBar:SetPoint("LEFT", frame, "LEFT", historyPx, swingCenterY)
        if soCActive then
            twistWindowBar:Show()
        else
            twistWindowBar:Hide()
        end

        -- Zero spark: a vertical tick at the left border of the twist window.
        if twistZeroSpark then
            twistZeroSpark:SetSize(2, swingHeight)
            twistZeroSpark:ClearAllPoints()
            twistZeroSpark:SetPoint("CENTER", frame, "LEFT", historyPx, swingCenterY)
            twistZeroSpark:Show()
        end

        -- Hide the div boundary marker (yellow/orange spark)
        if divBoundaryMarker then
            divBoundaryMarker:Hide()
        end
    else
        if twistWindowBar then twistWindowBar:Hide() end
        if twistZeroSpark then twistZeroSpark:Hide() end
        if divBoundaryMarker then divBoundaryMarker:Hide() end
    end

    -- Debug prints (always-on, throttled): verify all geometry inputs live.
    local throttle = db.debugThrottleSeconds or 0.25
    if throttle < 0 then throttle = 0 end

    local gcdShown = gcdBar:IsShown()
    local gcdW = gcdBar:GetWidth() or 0
    local swingW = swingBar:GetWidth() or 0
    local twistShown = twistWindowBar and twistWindowBar:IsShown() or false
    local feasibleShown = false
    local divShown = divBoundaryMarker and divBoundaryMarker:IsShown() or false

    -- Calculate markerX for debug output only
    local markerX = swingW or 0

    self:ThrottledInfo(
        "RetTwistBar: combat=%d gcd=%.3f swingLeft=%.3f speed=%.3f swingProg=%.3f markerX=%.1f gcdW=%.1f twistShown=%d feasibleShown=%d divShown=%d",
        "retTwistBar_debug_core",
        throttle,
        To01(UnitAffectingCombat("player")),
        gcd,
        rawSwingLeft,
        swingSpeed,
        swingProgress,
        markerX,
        gcdW,
        To01(twistShown),
        To01(feasibleShown),
        To01(divShown)
    )

    -- ============================ TWIST SUCCESS TOAST (SUCCESS-ONLY) ============================
    -- Triggered by `PaladinRetTwistModule` on swing impact via raw aura scanning.
    if twistOutcomeText and NAG.RetTwistGetLastSuccess then
        local lastSuccessTime, _, twistId = NAG:RetTwistGetLastSuccess()
        if lastSuccessTime and lastSuccessTime > 0 and self._retTwistToastLastSuccessTime ~= lastSuccessTime then
            self._retTwistToastLastSuccessTime = lastSuccessTime
            self._retTwistToastStartTime = GetTime()
            local toast = buildSuccessToast(twistId)
            self._retTwistToastText = toast.text
            self._retTwistToastColor = { toast.r, toast.g, toast.b }
        end
    end

    -- Render the toast:
    -- - Solid for 1.0s
    -- - Fade out over the next 1.0s (total lifetime 2.0s)
    -- - While fading, slide up by 30px
    if twistOutcomeText and self._retTwistToastStartTime and self._retTwistToastText then
        local now = GetTime()
        local age = now - (self._retTwistToastStartTime or now)
        if age < 0 then age = 0 end

        if age >= 2.0 then
            twistOutcomeText:Hide()
            self._retTwistToastStartTime = nil
            self._retTwistToastText = nil
            self._retTwistToastColor = nil
        else
            local a = 1.0
            local slideUp = 0
            if age > 1.0 then
                local t = (age - 1.0) / 1.0 -- 0..1 over the fade window
                if t < 0 then t = 0 end
                if t > 1 then t = 1 end
                a = 1.0 - t
                slideUp = 30 * t
            end

            -- Position centered above the swing lane.
            twistOutcomeText:ClearAllPoints()
            twistOutcomeText:SetPoint("BOTTOM", frame, "LEFT", width * 0.5, swingCenterY + (swingHeight / 2) + 2 + slideUp)

            twistOutcomeText:SetText(self._retTwistToastText)
            local c = self._retTwistToastColor
            local effectiveAlpha = a * (targetAlpha or 1.0)
            if c then
                twistOutcomeText:SetTextColor(c[1], c[2], c[3], effectiveAlpha)
            else
                twistOutcomeText:SetTextColor(1, 1, 1, effectiveAlpha)
            end
            twistOutcomeText:Show()
        end
    elseif twistOutcomeText then
        twistOutcomeText:Hide()
    end
end

-- ============================ UI BUILD ============================
function PaladinRetTwistBar:CreateFrameUI()
    if frame then return end

    OptionsFactory = NAG:GetModule("OptionsFactory")
    local db = self.db.class

    frame = CreateFrame("Frame", "NAGPaladinRetTwistBar", _G.UIParent)
    -- Initial size (UpdateDisplay will recompute precisely)
    frame:SetSize(db.width, (db.height + 5) + 6 + 5)
    frame:SetPoint(db.point, db.x, db.y)
    frame:SetAlpha(db.alpha or 1.0)
    frame:Hide()
    frame:SetMovable(true)
    frame:RegisterForDrag("LeftButton")
    frame:EnableMouse(NAG.IsAnyEditMode and NAG:IsAnyEditMode())
    frame:SetScript("OnDragStart", function()
        if InCombatLockdown and InCombatLockdown() then
            return
        end
        if not (moduleSelf and moduleSelf.db and moduleSelf.db.class) then
            return
        end
        local canDrag = NAG.IsAnyEditMode and NAG:IsAnyEditMode()
        if not canDrag then
            return
        end
        frame:StartMoving()
    end)

    -- Right-click context menu (disable/toggle off entirely).
    frame.contextMenu = frame.contextMenu or CreateFrame("Frame", "NAGPaladinRetTwistBarContextMenu", frame,
        "UIDropDownMenuTemplate")
    local moduleSelf = self

    -- Use an invisible Button overlay as the click target:
    -- - Larger hitbox than the visible bar
    -- - Higher frame level so it receives mouse clicks reliably
    clickCatcher = CreateFrame("Button", nil, frame)
    clickCatcher:SetPoint("TOPLEFT", frame, "TOPLEFT", -6, 6)
    clickCatcher:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 6, -6)
    clickCatcher:SetFrameLevel((frame:GetFrameLevel() or 0) + 50)
    clickCatcher:EnableMouse(true)
    clickCatcher:RegisterForClicks("RightButtonUp")
    -- Forward drag to frame so frame receives OnDragStop (frame has the position/save logic)
    clickCatcher:RegisterForDrag("LeftButton")
    clickCatcher:SetScript("OnDragStart", function()
        if frame and frame.StartMoving then
            frame:StartMoving()
        end
    end)
    clickCatcher:SetScript("OnDragStop", function()
        if not frame or not frame.StopMovingOrSizing then return end
        frame:StopMovingOrSizing()
        if not (moduleSelf and moduleSelf.db and moduleSelf.db.class) then return end
        local db = moduleSelf.db.class
        local anchor = NAG.GetDisplayAnchor and NAG:GetDisplayAnchor() or nil
        if anchor and anchor ~= _G.UIParent and db.autoAnchor then
            -- Read positions first while frame is still where the user dropped it (match Hunter bar).
            local saved = false
            local offsetX, offsetY
            if db.anchorSide == "right" then
                local barLeft, barBottom = frame:GetLeft(), frame:GetBottom()
                local anchorRight, anchorBottom = anchor:GetRight(), anchor:GetBottom()
                if barLeft and barBottom and anchorRight and anchorBottom then
                    offsetX = barLeft - anchorRight
                    offsetY = barBottom - anchorBottom
                    saved = true
                end
            else
                local barCenterX = select(1, frame:GetCenter())
                local barTop = frame:GetTop()
                local anchorCenterX = select(1, anchor:GetCenter())
                local anchorBottom = anchor:GetBottom()
                if barCenterX and barTop and anchorCenterX and anchorBottom then
                    offsetX = barCenterX - anchorCenterX
                    offsetY = barTop - anchorBottom
                    saved = true
                end
            end
            -- Then clear and re-anchor using saved or existing offsets.
            frame:SetParent(_G.UIParent)
            frame:ClearAllPoints()
            if saved then
                if db.anchorSide == "right" then
                    frame:SetPoint("BOTTOMLEFT", anchor, "BOTTOMRIGHT", offsetX, offsetY)
                    db.point = "BOTTOMLEFT"
                    db.x = offsetX
                    db.y = offsetY
                else
                    frame:SetPoint("TOP", anchor, "BOTTOM", offsetX, offsetY)
                    db.point = "TOP"
                    db.x = offsetX
                    db.y = offsetY
                end
            else
                -- Offset calc failed; keep autoAnchor and re-apply with existing db so bar stays attached.
                if db.anchorSide == "right" then
                    frame:SetPoint("BOTTOMLEFT", anchor, "BOTTOMRIGHT", db.x or 8, db.y or 0)
                else
                    frame:SetPoint("TOP", anchor, "BOTTOM", db.x, db.y)
                end
            end
        else
            local left, bottom = frame:GetLeft(), frame:GetBottom()
            if left and bottom then
                frame:SetParent(_G.UIParent)
                frame:ClearAllPoints()
                frame:SetPoint("BOTTOMLEFT", _G.UIParent, "BOTTOMLEFT", left, bottom)
            end
            local point, _, _, x, y = frame:GetPoint(1)
            if point then db.point = point end
            db.x = x or db.x or 0
            db.y = y or db.y or 0
            db.userPositioned = true
            db.autoAnchor = false
        end
    end)

    local function showContextMenu()
        local function isAutoAttackImageEnabled()
            return moduleSelf and moduleSelf.db and moduleSelf.db.class and moduleSelf.db.class.showSwingIconSpark
        end

        local function toggleAutoAttackImage()
            if not (moduleSelf and moduleSelf.db and moduleSelf.db.class) then
                return
            end
            moduleSelf.db.class.showSwingIconSpark = not moduleSelf.db.class.showSwingIconSpark
            if moduleSelf.UpdateDisplay and frame then
                moduleSelf:UpdateDisplay()
            end
        end

        local function isLocked()
            local dm = NAG:GetModule("DisplayManager")
            return not (dm and dm.classHelperEditMode)
        end

        local function toggleLocked()
            local dm = NAG:GetModule("DisplayManager")
            if not dm then return end
            local wasLocked = not dm.classHelperEditMode
            local newLocked = not wasLocked
            dm.classHelperEditMode = not newLocked
            NAG:SendMessage("NAG_FRAME_UPDATED")

            -- When unlocking: do NOT clear autoAnchor - let user drag and save offset so bar stays attached.
            -- When locking: if user manual-positioned during this session, keep autoAnchor off.
            if not newLocked and moduleSelf and moduleSelf.db and moduleSelf.db.class then
                if moduleSelf.UpdateVisibility then
                    moduleSelf:UpdateVisibility()
                end
                if CloseDropDownMenus then
                    CloseDropDownMenus()
                end
            else
                if moduleSelf and moduleSelf.db and moduleSelf.db.class and moduleSelf.db.class.userPositioned then
                    moduleSelf.db.class.autoAnchor = false
                end
                -- Defer UpdateVisibility when locking so the display/anchor has settled before we re-apply anchor+offset.
                if moduleSelf and moduleSelf.UpdateVisibility then
                    local doUpdate = function()
                        if moduleSelf and moduleSelf.UpdateVisibility then
                            moduleSelf:UpdateVisibility()
                        end
                    end
                    if C_Timer and C_Timer.After then
                        C_Timer.After(0, doUpdate)
                    else
                        doUpdate()
                    end
                end
            end
        end

        local function isAnchored()
            return moduleSelf and moduleSelf.db and moduleSelf.db.class and moduleSelf.db.class.autoAnchor ~= false
        end

        local function toggleAnchored()
            if not (moduleSelf and moduleSelf.db and moduleSelf.db.class) then
                return
            end
            local newAnchored = not (moduleSelf.db.class.autoAnchor ~= false)
            moduleSelf.db.class.autoAnchor = newAnchored
            if newAnchored then
                moduleSelf.db.class.userPositioned = false
                -- Snap back to the original anchored defaults.
                moduleSelf.db.class.point = defaults.class.point
                moduleSelf.db.class.x = defaults.class.x
                moduleSelf.db.class.y = defaults.class.y
            end
            if moduleSelf.UpdateVisibility then
                moduleSelf:UpdateVisibility()
            end
        end

        local function confirmDisable()
            if StaticPopup_Show then
                StaticPopup_Show("NAG_RET_TWIST_BAR_DISABLE_CONFIRM", nil, nil, { module = moduleSelf })
            end
        end

        local function confirmReset()
            if StaticPopup_Show then
                StaticPopup_Show("NAG_RET_TWIST_BAR_RESET_CONFIRM", nil, nil, { module = moduleSelf })
            end
        end

        local menu = {
            { text = "Ret Twist Bar", isTitle = true, notCheckable = true },
            {
                text = "Auto Attack image",
                isNotRadio = true,
                keepShownOnClick = true,
                checked = isAutoAttackImageEnabled,
                func = toggleAutoAttackImage,
            },
            {
                text = "Locked",
                isNotRadio = true,
                keepShownOnClick = true,
                checked = isLocked,
                func = toggleLocked,
            },
            {
                text = "Anchor to NAG",
                isNotRadio = true,
                keepShownOnClick = true,
                checked = isAnchored,
                func = toggleAnchored,
            },
            {
                text = "Restore Defaults",
                notCheckable = true,
                func = confirmReset,
            },
            {
                text = "Disable Bar",
                notCheckable = true,
                func = confirmDisable,
            },
            {
                text = "Cancel",
                notCheckable = true,
                func = function()
                    if CloseDropDownMenus then
                        CloseDropDownMenus()
                    end
                end
            },
        }

        if EasyMenu then
            EasyMenu(menu, frame.contextMenu, "cursor", 0, 0, "MENU")
            return
        end

        -- Fallback for clients without EasyMenu: use UIDropDownMenu_Initialize + ToggleDropDownMenu.
        if UIDropDownMenu_Initialize and UIDropDownMenu_AddButton and ToggleDropDownMenu then
            UIDropDownMenu_Initialize(frame.contextMenu, function(_, level)
                for i = 1, #menu do
                    UIDropDownMenu_AddButton(menu[i], level)
                end
            end, "MENU")
            ToggleDropDownMenu(1, nil, frame.contextMenu, "cursor", 0, 0)
        end
    end

    clickCatcher:SetScript("OnClick", function(_, button)
        if button ~= "RightButton" then
            return
        end
        showContextMenu()
    end)

    -- Background (lowest) - sized/positioned dynamically in UpdateDisplay so it only covers the swing lane.
    background = frame:CreateTexture(nil, "BACKGROUND", nil, -8)
    background:SetColorTexture(db.backgroundColor.r, db.backgroundColor.g, db.backgroundColor.b, db.backgroundColor.a)

    -- Outcome toast text (appears above the swing lane, fades out automatically).
    twistOutcomeText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    twistOutcomeText:SetJustifyH("CENTER")
    twistOutcomeText:SetJustifyV("MIDDLE")
    twistOutcomeText:SetText("")
    -- Make toast text 100% bigger (2x).
    local fontPath, fontSize, fontFlags = twistOutcomeText:GetFont()
    if fontPath and fontSize then
        twistOutcomeText:SetFont(fontPath, fontSize * 2, fontFlags)
    end
    twistOutcomeText:Hide()

    -- Swing timer "bar" is a hidden positioning surface; only the spark line is meant to be visible.
    -- Keep it low in ARTWORK; it is fully transparent anyway.
    swingBar = frame:CreateTexture(nil, "ARTWORK", nil, -7)
    swingBar:SetPoint("LEFT", frame, "LEFT", 0, 0)
    swingBar:SetWidth(0)
    -- Swing bar is a hidden "positioning bar" (transparent). The visible indicator is swingSpark.
    swingBar:SetColorTexture(db.swingColor.r, db.swingColor.g, db.swingColor.b, db.swingColor.a)

    -- GCD overlay bar: use a HIGH sublevel just like ShamanWeaveBar so it is unmistakably on top.
    gcdBar = frame:CreateTexture(nil, "ARTWORK", nil, 6)
    gcdBar:SetPoint("LEFT", frame, "LEFT", 0, 0)
    gcdBar:SetWidth(0)
    gcdBar:SetColorTexture(db.gcdColor.r, db.gcdColor.g, db.gcdColor.b, db.gcdColor.a)
    gcdBar:Hide()

    -- Twist window overlay bars: below GCD overlay, above background.
    twistWindowBar = frame:CreateTexture(nil, "ARTWORK", nil, 4)
    twistWindowBar:SetPoint("LEFT", frame, "LEFT", 0, 0)
    twistWindowBar:SetWidth(0)
    twistWindowBar:SetColorTexture(db.twistWindowColor.r, db.twistWindowColor.g, db.twistWindowColor.b, db.twistWindowColor.a)
    twistWindowBar:Hide()

    -- Zero spark: vertical tick at the left border of the twist window (0.4 marker boundary).
    twistZeroSpark = frame:CreateTexture(nil, "OVERLAY", nil, 6)
    twistZeroSpark:SetColorTexture(db.sparkColor.r, db.sparkColor.g, db.sparkColor.b, db.sparkColor.a)
    twistZeroSpark:Hide()

    -- Put swing spark above the GCD overlay (so you always see the actual swing moment line).
    -- Texture sublevels are limited to [-8, 7].
    swingSpark = frame:CreateTexture(nil, "OVERLAY", nil, 7)
    swingSpark:SetColorTexture(db.sparkColor.r, db.sparkColor.g, db.sparkColor.b, db.sparkColor.a)
    swingSpark:Hide()

    -- Past swing spark: same style as swingSpark, but rendered slightly dimmer.
    pastSwingSpark = frame:CreateTexture(nil, "OVERLAY", nil, 7)
    pastSwingSpark:SetColorTexture(db.sparkColor.r, db.sparkColor.g, db.sparkColor.b, (db.sparkColor.a or 0.9) * 0.55)
    pastSwingSpark:Hide()

    -- Mainhand weapon icon spark (circular), positioned above the swing marker.
    swingIconSparkFrame = CreateFrame("Frame", nil, frame)
    swingIconSparkFrame:SetSize(16, 16)
    swingIconSparkFrame:Hide()

    -- Background art for the weapon spark (sits behind the circular icon).
    -- File: NAG/media/extras/iconBar.png
    -- Use a low sublevel to guarantee this stays behind the masked weapon icon.
    swingIconSparkBackground = swingIconSparkFrame:CreateTexture(nil, "BACKGROUND", nil, -8)
    swingIconSparkBackground:SetTexture("Interface\\AddOns\\NAG\\media\\extras\\iconBar.png")
    swingIconSparkBackground:SetPoint("CENTER", swingIconSparkFrame, "CENTER", 0, 0)
    swingIconSparkBackground:SetSize(37, 37)
    swingIconSparkBackground:SetAlpha(0.95)
    swingIconSparkBackground:Hide()

    swingIconSparkIcon = swingIconSparkFrame:CreateTexture(nil, "OVERLAY", nil, 3)
    swingIconSparkIcon:SetAllPoints()
    swingIconSparkIcon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
    swingIconSparkIcon:SetTexCoord(0.15, 0.85, 0.15, 0.85) -- crop for a clean look

    swingIconSparkMask = swingIconSparkFrame:CreateMaskTexture()
    swingIconSparkMask:SetTexture("Interface/CHARACTERFRAME/TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE",
        "CLAMPTOBLACKADDITIVE")
    swingIconSparkMask:SetAllPoints()
    swingIconSparkIcon:AddMaskTexture(swingIconSparkMask)

    -- GCD spark: above the GCD bar, below the swing spark.
    gcdSpark = frame:CreateTexture(nil, "OVERLAY", nil, 6)
    gcdSpark:SetColorTexture(db.sparkColor.r, db.sparkColor.g, db.sparkColor.b, db.sparkColor.a)
    gcdSpark:Hide()

    -- GCD left spark: same style as gcdSpark.
    gcdSparkLeft = frame:CreateTexture(nil, "OVERLAY", nil, 6)
    gcdSparkLeft:SetColorTexture(db.sparkColor.r, db.sparkColor.g, db.sparkColor.b, db.sparkColor.a)
    gcdSparkLeft:Hide()

    -- Div boundary marker: a moving tick line for "swing - 0.4 - gcdDurationValue".
    divBoundaryMarker = frame:CreateTexture(nil, "OVERLAY", nil, 5)
    divBoundaryMarker:SetColorTexture(db.divMarkerColor.r, db.divMarkerColor.g, db.divMarkerColor.b, db.divMarkerColor.a)
    divBoundaryMarker:Hide()

end

-- ============================ BAR COLORS (OPTIONS APPLY) ============================
--- Applies current db.class color settings to all bar textures. Safe to call when frame not yet created.
function PaladinRetTwistBar:ApplyBarColors()
    if not frame then
        return
    end
    local db = self.db.class
    if not db then
        return
    end

    if background and db.backgroundColor then
        background:SetColorTexture(db.backgroundColor.r, db.backgroundColor.g, db.backgroundColor.b, db.backgroundColor.a)
    end
    if swingBar and db.swingColor then
        swingBar:SetColorTexture(db.swingColor.r, db.swingColor.g, db.swingColor.b, db.swingColor.a)
    end
    if gcdBar and db.gcdColor then
        gcdBar:SetColorTexture(db.gcdColor.r, db.gcdColor.g, db.gcdColor.b, db.gcdColor.a)
    end
    if twistWindowBar and db.twistWindowColor then
        twistWindowBar:SetColorTexture(db.twistWindowColor.r, db.twistWindowColor.g, db.twistWindowColor.b, db.twistWindowColor.a)
    end
    if twistZeroSpark and db.sparkColor then
        twistZeroSpark:SetColorTexture(db.sparkColor.r, db.sparkColor.g, db.sparkColor.b, db.sparkColor.a)
    end
    if swingSpark and db.sparkColor then
        swingSpark:SetColorTexture(db.sparkColor.r, db.sparkColor.g, db.sparkColor.b, db.sparkColor.a)
    end
    if pastSwingSpark and db.sparkColor then
        pastSwingSpark:SetColorTexture(db.sparkColor.r, db.sparkColor.g, db.sparkColor.b, (db.sparkColor.a or 0.9) * 0.55)
    end
    if gcdSpark and db.sparkColor then
        gcdSpark:SetColorTexture(db.sparkColor.r, db.sparkColor.g, db.sparkColor.b, db.sparkColor.a)
    end
    if gcdSparkLeft and db.sparkColor then
        gcdSparkLeft:SetColorTexture(db.sparkColor.r, db.sparkColor.g, db.sparkColor.b, db.sparkColor.a)
    end
    if divBoundaryMarker and db.divMarkerColor then
        divBoundaryMarker:SetColorTexture(db.divMarkerColor.r, db.divMarkerColor.g, db.divMarkerColor.b, db.divMarkerColor.a)
    end
end

-- ============================ LIFECYCLE ============================
function PaladinRetTwistBar:ModuleInitialize()
    -- One-time position tweak: move the bar 5px down for existing users.
    -- (WoW UI Y grows upward, so "down" means subtracting.)
    if self.db and self.db.class and not self.db.class._migratedDown5 then
        self.db.class.y = (self.db.class.y or defaults.class.y or 0) - 5
        self.db.class._migratedDown5 = true
    end

    -- No heavy work; UI built lazily.
    -- Register swing timer callbacks to force instant refresh at swing boundaries.
    if swingTimerLib and swingTimerLib.RegisterCallback then
        swingTimerLib.RegisterCallback(self, "UNIT_SWING_TIMER_START", function(_, unitId, speed, expirationTime, hand)
            if unitId == "player" and hand == "mainhand" and self.UpdateDisplay then
                self:UpdateDisplay()
            end
        end)
        swingTimerLib.RegisterCallback(self, "UNIT_SWING_TIMER_STOP", function(_, unitId, hand)
            if unitId == "player" and hand == "mainhand" and self.UpdateDisplay then
                self:UpdateDisplay()
            end
        end)
        swingTimerLib.RegisterCallback(self, "UNIT_SWING_TIMER_UPDATE", function(_, unitId, speed, expirationTime, hand)
            if unitId == "player" and hand == "mainhand" and self.UpdateDisplay then
                self:UpdateDisplay()
            end
        end)
    end
end

function PaladinRetTwistBar:ModuleEnable()
    if UnitClassBase("player") ~= "PALADIN" then
        self:SetEnabledState(false)
        return
    end

    -- Delay frame creation by 7 seconds to allow addon/spell data to fully load
    local TimerManager = ns.TimerManager
    if TimerManager then
        TimerManager:Cancel(TimerManager.Categories.UI_NOTIFICATION, "retTwistBarDelayedInit")
        TimerManager:Create(
            TimerManager.Categories.UI_NOTIFICATION,
            "retTwistBarDelayedInit",
            function()
                self:CreateFrameUI()
                self:UpdateVisibility()
            end,
            7.0,  -- 7 second delay
            false -- Don't repeat
        )
    else
        -- Fallback: create immediately if TimerManager not available
        self:CreateFrameUI()
        self:UpdateVisibility()
    end
end

function PaladinRetTwistBar:ModuleDisable()
    if frame then
        frame:SetScript("OnUpdate", nil)
        frame:Hide()
    end
end

-- ============================ EVENTS ============================
function PaladinRetTwistBar:PLAYER_REGEN_DISABLED()
    self:UpdateVisibility()
end

function PaladinRetTwistBar:PLAYER_REGEN_ENABLED()
    self:UpdateVisibility()
    if self._pendingReloadUI and ReloadUI and (not (InCombatLockdown and InCombatLockdown())) then
        self._pendingReloadUI = false
        ReloadUI()
    end
end

function PaladinRetTwistBar:PLAYER_ENTERING_WORLD()
    self:UpdateVisibility()
end

function PaladinRetTwistBar:PLAYER_TARGET_CHANGED()
    -- Target affects swing state (auto-attack start/stop). Refresh quickly.
    self.forceInstantUpdate = true
    self:UpdateDisplay()
    self.forceInstantUpdate = false
end

function PaladinRetTwistBar:NAG_FRAME_UPDATED()
    if self.db.class.autoAnchor then
        self:UpdateFrameAnchor()
    end
    if frame then
        self:UpdateVisibility()
    end
end

-- Declarative event registration
PaladinRetTwistBar.eventHandlers = {
    PLAYER_ENTERING_WORLD = true,
    PLAYER_REGEN_DISABLED = true,
    PLAYER_REGEN_ENABLED = true,
    PLAYER_TARGET_CHANGED = true,
}

-- ============================ OPTIONS ============================
function PaladinRetTwistBar:GetOptions()
    if not OptionsFactory then
        OptionsFactory = NAG:GetModule("OptionsFactory")
    end

    -- Ensure color tables exist (e.g. for older saved profiles).
    local colorKeys = { "backgroundColor", "swingColor", "gcdColor", "sparkColor", "twistWindowColor", "divMarkerColor" }
    for _, key in ipairs(colorKeys) do
        if not self.db.class[key] and defaults.class[key] then
            local d = defaults.class[key]
            self.db.class[key] = { r = d.r, g = d.g, b = d.b, a = d.a or 1 }
        end
    end

    local function colorGetter(color)
        return function()
            if not color then return 0.3, 0.75, 0.3, 0 end
            return color.r, color.g, color.b, color.a
        end
    end

    local function colorSetter(color)
        return function(_, r, g, b, a)
            if not color then return end
            color.r, color.g, color.b, color.a = r, g, b, a
            self:ApplyBarColors()
        end
    end

    return {
        type = "group",
        name = "Ret Twist Bar",
        order = 26,
        childGroups = "tab",
        width = "full",
        args = {
            enabled = OptionsFactory:CreateToggle(
                "Enabled",
                "Enable/disable the Ret twist validation bar.",
                function() return self:GetSetting("class", "enabled") end,
                function(_, value)
                    self:SetSetting("class", "enabled", value)
                    if value then self:Enable() else self:Disable() end
                end,
                { order = 1 }
            ),
            showBar = OptionsFactory:CreateToggle(
                "Show Bar",
                "Show or hide the bar frame.",
                function() return self:GetSetting("class", "showBar") end,
                function(_, value)
                    self:SetSetting("class", "showBar", value)
                    self:UpdateVisibility()
                end,
                { order = 2 }
            ),
            hideOutOfCombat = OptionsFactory:CreateToggle(
                "Hide Out of Combat",
                "Hide the bar when out of combat.",
                function() return self:GetSetting("class", "hideOutOfCombat") end,
                function(_, value)
                    self:SetSetting("class", "hideOutOfCombat", value)
                    self:UpdateVisibility()
                end,
                { order = 3 }
            ),
            showTwistWindow = OptionsFactory:CreateToggle(
                "Show Twist Window",
                "Show the twist window overlay (last ~0.4s). Only visible when Seal of Command is active.",
                function() return self:GetSetting("class", "showTwistWindow") end,
                function(_, value)
                    self:SetSetting("class", "showTwistWindow", value)
                    if frame then self:UpdateDisplay() end
                end,
                { order = 5 }
            ),
            showSwingIconSpark = OptionsFactory:CreateToggle(
                "Show Weapon Spark",
                "Show your mainhand weapon icon as a circular spark above the swing marker.",
                function() return self:GetSetting("class", "showSwingIconSpark") end,
                function(_, value)
                    self:SetSetting("class", "showSwingIconSpark", value)
                    if frame then self:UpdateDisplay() end
                end,
                { order = 6 }
            ),
            autoAnchor = OptionsFactory:CreateToggle(
                "Auto Anchor to NAG",
                "Anchor relative to NAG's primary display frame when available.",
                function() return self:GetSetting("class", "autoAnchor") end,
                function(_, value)
                    self:SetSetting("class", "autoAnchor", value)
                    self:UpdateVisibility()
                end,
                { order = 7 }
            ),
            anchorSide = OptionsFactory:CreateSelect(
                "Anchor Side",
                "When auto-anchored: position bar below NAG frame or to the right of it.",
                function() return self:GetSetting("class", "anchorSide") or "bottom" end,
                function(_, value)
                    self:SetSetting("class", "anchorSide", value)
                    self:UpdateVisibility()
                end,
                { order = 8, values = { bottom = "Below NAG frame", right = "Right of NAG frame" } }
            ),
            width = OptionsFactory:CreateRange(
                "Width",
                "Bar width.",
                function() return self:GetSetting("class", "width") end,
                function(_, value)
                    self:SetSetting("class", "width", value)
                    if frame then self:UpdateDisplay() end
                end,
                { min = 80, max = 600, step = 1, order = 10 }
            ),
            height = OptionsFactory:CreateRange(
                "Height",
                "Bar height.",
                function() return self:GetSetting("class", "height") end,
                function(_, value)
                    self:SetSetting("class", "height", value)
                    if frame then self:UpdateDisplay() end
                end,
                { min = 1, max = 60, step = 1, order = 11 }
            ),
            alpha = OptionsFactory:CreateRange(
                "Alpha",
                "Frame alpha.",
                function() return self:GetSetting("class", "alpha") end,
                function(_, value)
                    self:SetSetting("class", "alpha", value)
                    if frame then frame:SetAlpha(value) end
                end,
                { min = 0.1, max = 1.0, step = 0.05, order = 12 }
            ),
            x = OptionsFactory:CreateRange(
                "X Offset",
                "Horizontal offset.",
                function() return self:GetSetting("class", "x") end,
                function(_, value)
                    self:SetSetting("class", "x", value)
                    self:UpdateVisibility()
                end,
                { min = -2000, max = 2000, step = 1, order = 20 }
            ),
            y = OptionsFactory:CreateRange(
                "Y Offset",
                "Vertical offset.",
                function() return self:GetSetting("class", "y") end,
                function(_, value)
                    self:SetSetting("class", "y", value)
                    self:UpdateVisibility()
                end,
                { min = -2000, max = 2000, step = 1, order = 21 }
            ),
            colorsHeader = OptionsFactory:CreateHeader("Bar Colors", { order = 30 }),
            backgroundColor = OptionsFactory:CreateColor(
                "Background",
                "Color of the bar background.",
                colorGetter(self.db.class.backgroundColor),
                colorSetter(self.db.class.backgroundColor),
                { hasAlpha = true, order = 31 }
            ),
            swingColor = OptionsFactory:CreateColor(
                "Swing Bar",
                "Color of the swing timer bar (usually transparent).",
                colorGetter(self.db.class.swingColor),
                colorSetter(self.db.class.swingColor),
                { hasAlpha = true, order = 32 }
            ),
            gcdColor = OptionsFactory:CreateColor(
                "GCD Bar",
                "Color of the GCD overlay bar.",
                colorGetter(self.db.class.gcdColor),
                colorSetter(self.db.class.gcdColor),
                { hasAlpha = true, order = 33 }
            ),
            sparkColor = OptionsFactory:CreateColor(
                "Spark / Markers",
                "Color of the swing spark and other line markers.",
                colorGetter(self.db.class.sparkColor),
                colorSetter(self.db.class.sparkColor),
                { hasAlpha = true, order = 34 }
            ),
            twistWindowColor = OptionsFactory:CreateColor(
                "Twist Window",
                "Color of the twist window overlay (last ~0.4s before swing).",
                colorGetter(self.db.class.twistWindowColor),
                colorSetter(self.db.class.twistWindowColor),
                { hasAlpha = true, order = 35 }
            ),
            divMarkerColor = OptionsFactory:CreateColor(
                "Div Boundary Marker",
                "Color of the boundary tick marker.",
                colorGetter(self.db.class.divMarkerColor),
                colorSetter(self.db.class.divMarkerColor),
                { hasAlpha = true, order = 36 }
            ),
            resetBarHeader = OptionsFactory:CreateHeader("Reset", { order = 40 }),
            resetBarToDefaults = OptionsFactory:CreateExecute(
                "Reset Bar to Defaults",
                "Restore all Ret Twist Bar settings (position, size, colors) to defaults.",
                function()
                    if StaticPopup_Show then
                        StaticPopup_Show("NAG_RET_TWIST_BAR_RESET_CONFIRM", nil, nil, { module = self })
                    end
                end,
                { order = 41 }
            ),
        }
    }
end


