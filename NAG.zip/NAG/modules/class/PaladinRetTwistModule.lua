--- @module "NAG.PaladinRetTwistModule"
--- Runtime helpers for Classic TBC Retribution Paladin seal twisting rotations.
---
--- Tracks simple, runtime-only state needed by APL logic (no DB writes):
--- - "warmup swings since combat start" (WA used `meleeCount > 2`)
---
--- License: CC BY-NC 4.0 (https://creativecommons.org/licenses/by-nc/4.0/legalcode)
--- Authors: Rakizi, Fonsas
--- Discord: https://discord.gg/ebonhold

-- ~~~~~~~~~~ LOCALIZE ~~~~~~~~~~
local _, ns = ...
local GetTime = _G.GetTime
local GetSpellInfo = _G.GetSpellInfo
local UnitAura = _G.UnitAura
local UnitGUID = _G.UnitGUID
local UnitAttackSpeed = _G.UnitAttackSpeed
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")

-- ============================ MODULE DEFINITION ============================

local defaults = {
    class = {
        enabled = true,

        -- Debug: when enabled, this module will print compact state snapshots
        -- on relevant swing/cast events to help validate timing helpers in-game.
        debugLoggingEnabled = false,
        debugThrottleSeconds = 0.25,
    }
}

--- @class PaladinRetTwistModule:CoreModule
local PaladinRetTwistModule = NAG:CreateModule("PaladinRetTwistModule", defaults, {
    moduleType = ns.MODULE_TYPES.CLASS,
    className = "PALADIN",
    optionsCategory = ns.MODULE_CATEGORIES.CLASS,
    debugCategories = { ns.DEBUG_CATEGORIES.CLASS },

    slashCommands = {
        ["rettwistdebug"] = {
            handler = true,
            help = "Toggle or set Ret twist debug logging. Usage: /rettwistdebug [on|off]"
        }
    },

    eventHandlers = {
        PLAYER_REGEN_DISABLED = "OnCombatStateChanged",
        PLAYER_REGEN_ENABLED = "OnCombatStateChanged"
    },
    cleuHandlers = {
        SWING_DAMAGE = "HandleCLEU",
        SWING_MISSED = "HandleCLEU",
        SPELL_CAST_SUCCESS = "HandleCLEUSpellCastSuccess",
    },
    defaultState = {
        inCombat = false,
        swingCount = 0,
        lastResetTime = 0,

        -- Success-only twist detection (runtime-only):
        -- Updated on SWING_DAMAGE/SWING_MISSED when SoC + SoB/SoM are both active at impact.
        lastTwistSuccessTime = 0,
        lastTwistSuccessSoCId = 0,
        lastTwistSuccessTwistId = 0,
    }
})

ns.PaladinRetTwistModule = PaladinRetTwistModule
local module = PaladinRetTwistModule

-- ============================ MODULE LIFECYCLE ============================

-- ============================ TWIST SUCCESS DETECTION (RAW AURA SCAN) ============================

-- Keep these lists consistent with `NAG/handlers/APLAction_Casting.lua` (RetTwistIsSoCActive/RetTwistIsSoBActive).
local RET_TWIST_SOC_IDS = {
    20375, -- Seal of Command (Rank 1)
    20915, -- Seal of Command (Rank 2)
    20918, -- Seal of Command (Rank 3)
    20919, -- Seal of Command (Rank 4)
    20920, -- Seal of Command (Rank 5)
    27170, -- Seal of Command (Rank 6, TBC)
}

local RET_TWIST_SOB_IDS = {
    31892,  -- Seal of Blood
    31893,  -- Seal of Blood (variant)
    348700, -- Seal of the Martyr
    348701, -- Seal of the Martyr (variant)
}

-- Leveling fallback (when SoB/SoM are not learned yet)
local RET_TWIST_SOR_IDS = {
    20154, -- Seal of Righteousness
    21084, -- Seal of Righteousness (rank/variant)
}

local function buildSpellIdSet(ids)
    local set = {}
    for i = 1, #ids do
        set[ids[i]] = true
    end
    return set
end

local function buildSpellNameSet(ids)
    local set = {}
    if not GetSpellInfo then
        return set
    end
    for i = 1, #ids do
        local name = GetSpellInfo(ids[i])
        if name then
            set[name] = true
        end
    end
    return set
end

local SOC_ID_SET = buildSpellIdSet(RET_TWIST_SOC_IDS)
local SOB_ID_SET = buildSpellIdSet(RET_TWIST_SOB_IDS)
local SOC_NAME_SET = buildSpellNameSet(RET_TWIST_SOC_IDS)
local SOB_NAME_SET = buildSpellNameSet(RET_TWIST_SOB_IDS)
local SOR_NAME_SET = buildSpellNameSet(RET_TWIST_SOR_IDS)
for i = 1, #RET_TWIST_SOR_IDS do
    local id = RET_TWIST_SOR_IDS[i]
    if id then
        SOB_ID_SET[id] = true
    end
end
for name in pairs(SOR_NAME_SET) do
    SOB_NAME_SET[name] = true
end

--- Raw aura scan that avoids NAG aura helpers/caches.
--- Returns the matched spellId if found, otherwise 0.
--- @param unit string
--- @param spellIdSet table
--- @param spellNameSet table
--- @return number
local function rawFindAuraId(unit, spellIdSet, spellNameSet)
    if not UnitAura then
        return 0
    end
    for i = 1, 40 do
        local name, _, _, _, _, _, _, _, _, _, spellId = UnitAura(unit, i, "HELPFUL")
        if not name then
            break
        end
        if spellId and spellIdSet[spellId] then
            return spellId
        end
        if name and spellNameSet and spellNameSet[name] then
            return 1 -- Fallback: spellId not available on this client; name match is enough.
        end
    end
    return 0
end

function PaladinRetTwistModule:ModuleInitialize()
    -- No heavy work here; events are wired via declarative tables.
end

function PaladinRetTwistModule:StartDebugSampler()
    if self._debugSamplerActive then
        return
    end

    local TimerManager = ns.TimerManager
    if not TimerManager or not TimerManager.Create then
        return
    end

    self._debugSamplerActive = true
    TimerManager:Cancel(TimerManager.Categories.COMBAT, "retTwistDebugSampler")
    TimerManager:Create(
        TimerManager.Categories.COMBAT,
        "retTwistDebugSampler",
        function()
            self:DebugSamplerTick()
        end,
        0.05,
        true
    )
end

function PaladinRetTwistModule:StopDebugSampler()
    local TimerManager = ns.TimerManager
    if TimerManager and TimerManager.Cancel then
        TimerManager:Cancel(TimerManager.Categories.COMBAT, "retTwistDebugSampler")
    end
    self._debugSamplerActive = false
end

function PaladinRetTwistModule:DebugSamplerTick()
    if not self.db.class.debugLoggingEnabled then
        self:StopDebugSampler()
        return
    end

    self:InitializeState()
    if not self.state.inCombat then
        return
    end

    -- Only emit samples near the twist-relevant region to avoid spam.
    local _, rawTimeToSwing = NAG:AutoTimeToNext()
    if not rawTimeToSwing then
        return
    end

    if rawTimeToSwing <= 0.65 then
        self:MaybePrintSnapshot("SAMPLE")
    end
end

function PaladinRetTwistModule:OnCombatStateChanged(event)
    self:InitializeState()
    if event == "PLAYER_REGEN_DISABLED" then
        self.state.inCombat = true
        self.state.swingCount = 0
        self.state.lastResetTime = GetTime()
        self:MaybePrintSnapshot("COMBAT_START")
        if self.db.class.debugLoggingEnabled then
            self:StartDebugSampler()
        end
    else
        self:MaybePrintSnapshot("COMBAT_END")
        self.state.inCombat = false
        self.state.swingCount = 0
        self.state.lastResetTime = GetTime()
        self:StopDebugSampler()
    end
end

--- Handle swing events via CLEU dispatch.
--- EventManager passes at least (timestamp, subEvent, hideCaster, sourceGUID, ...)
function PaladinRetTwistModule:HandleCLEU(timestamp, subEvent, hideCaster, sourceGUID)
    self:InitializeState()
    if not self.state.inCombat then
        return
    end
    if sourceGUID ~= NAG.state.player.guid then
        return
    end
    -- cleuHandlers already restrict to SWING_DAMAGE / SWING_MISSED
    self.state.swingCount = (self.state.swingCount or 0) + 1

    -- Success-only twist detection:
    -- A twist is considered successful if, at swing impact, we have both SoC and SoB/SoM active.
    -- This uses a raw aura scan to avoid cached aura snapshots.
    local now = GetTime()
    local soCId = rawFindAuraId("player", SOC_ID_SET, SOC_NAME_SET)
    local twistId = rawFindAuraId("player", SOB_ID_SET, SOB_NAME_SET)
    if soCId ~= 0 and twistId ~= 0 then
        self.state.lastTwistSuccessTime = now
        self.state.lastTwistSuccessSoCId = soCId
        self.state.lastTwistSuccessTwistId = twistId
    end

    self:MaybePrintSnapshot(subEvent)
end

--- Handle spell cast success events for relevant Ret twisting spells.
--- Only used for debug snapshots (does not alter swing tracking).
function PaladinRetTwistModule:HandleCLEUSpellCastSuccess(timestamp, subEvent, hideCaster, sourceGUID, sourceName, sourceFlags, sourceRaidFlags,
    destGUID, destName, destFlags, destRaidFlags, spellId)
    self:InitializeState()
    if sourceGUID ~= NAG.state.player.guid then
        return
    end

    -- Only snapshot on spells relevant to the twisting logic (avoid spam).
    if spellId == 20375  -- Seal of Command (Rank 1, cast ID)
        or spellId == 27170 -- Seal of Command (Rank 6, cast ID)
        or spellId == 31892 -- Seal of Blood
        or spellId == 348700 -- Seal of the Martyr
        or spellId == 35395 -- Crusader Strike
        or spellId == 27138 -- Exorcism
        or spellId == 27173 -- Consecration
    then
        self:MaybePrintSnapshot("SPELL_CAST_SUCCESS:" .. tostring(spellId))
    end
end

function PaladinRetTwistModule:rettwistdebug(input)
    local arg = input and tostring(input):lower() or ""
    local enabled
    if arg == "on" or arg == "1" or arg == "true" then
        enabled = true
    elseif arg == "off" or arg == "0" or arg == "false" then
        enabled = false
    else
        enabled = not self.db.class.debugLoggingEnabled
    end

    self.db.class.debugLoggingEnabled = enabled
    self:Print(string.format("RetTwist debug logging: %s", enabled and "ON" or "OFF"))

    if enabled then
        self:StartDebugSampler()
    else
        self:StopDebugSampler()
    end
end

function PaladinRetTwistModule:MaybePrintSnapshot(reason)
    if not self.db.class.debugLoggingEnabled then
        return
    end

    local throttleSeconds = self.db.class.debugThrottleSeconds or 0.25
    if throttleSeconds < 0 then
        throttleSeconds = 0
    end

    self._lastDebugSnapshot = self._lastDebugSnapshot or 0
    local now = GetTime()
    if (now - self._lastDebugSnapshot) < throttleSeconds then
        return
    end
    self._lastDebugSnapshot = now

    local swingTimerLib = ns.LibClassicSwingTimerAPI
    local mhSpeed, mhExpiration
    if swingTimerLib and swingTimerLib.UnitSwingTimerInfo then
        mhSpeed, mhExpiration = swingTimerLib:UnitSwingTimerInfo("player", "mainhand")
    end

    local _, rawTimeToSwing = NAG:AutoTimeToNext()
    local timeAfterGCD = NAG:AutoTimeToNextAfterGCD()
    local gcd = NAG:GCDTimeToReady() or 0

    local canTwistNoDelay = NAG:CanTwist(0.4, 0.0)
    local canTwistDelay = NAG:CanTwist(0.4, 0.1)
    -- Ret twist policy: ignore ping; use fixed input delay of 0.1s
    local inputDelay = 0.1

    local csTTR = NAG:SpellTimeToReady(35395) or 0
    local forceCS = NAG:RetTwistShouldForceCrusaderStrike(1.7, 0.1, 0.4)

    local soCActive = NAG:RetTwistIsSoCActive()
    local soBActive = NAG:IsActive(31892)
    local soMActive = NAG:IsActive(348700)

    local swingCount = NAG:RetTwistSwingCount()
    local warmup = NAG:RetTwistWarmupComplete(2)

    local weaponSpeed = UnitAttackSpeed("player") or 0
    local mhTTR = (mhExpiration and (mhExpiration - now)) or 0

    self:Print(string.format(
        "RetTwist[%s] t=%.2f mhSpeed=%.3f mhTTR=%.3f apiSpeed=%.3f gcd=%.3f rawSwing=%.3f afterGCD=%.3f inputDelay=%.3f CanTwist(0.4,d0)=%.0f CanTwist(d0.1)=%.0f CS_TTR=%.3f ForceCS=%.0f SoC=%.0f SoB=%.0f SoM=%.0f swings=%d warmup=%.0f",
        tostring(reason),
        now,
        tonumber(mhSpeed) or 0,
        mhTTR,
        weaponSpeed,
        gcd,
        rawTimeToSwing or 0,
        timeAfterGCD or 0,
        inputDelay,
        canTwistNoDelay and 1 or 0,
        canTwistDelay and 1 or 0,
        csTTR,
        forceCS and 1 or 0,
        soCActive and 1 or 0,
        soBActive and 1 or 0,
        soMActive and 1 or 0,
        swingCount or 0,
        warmup and 1 or 0
    ))
end

-- ============================ APL ACCESSORS (NAG API) ============================

local RET_TWIST_BAR_GATE_TTL_SECONDS = 5

local function getTBCRetBarsGate()
    if ns.tbcRetBarsGateEnabled == nil then
        ns.tbcRetBarsGateEnabled = false
    end
    return ns.tbcRetBarsGateEnabled
end

local function getTBCRetBarsGateLastEnable()
    if ns.tbcRetBarsGateLastEnable == nil then
        ns.tbcRetBarsGateLastEnable = 0
    end
    return ns.tbcRetBarsGateLastEnable
end

local function updateTBCRetBarsGateLastEnable(timeSeconds)
    ns.tbcRetBarsGateLastEnable = timeSeconds or 0
end

local function isTBCRetBarsGateExpired(now)
    local lastEnable = getTBCRetBarsGateLastEnable()
    if lastEnable <= 0 then
        return true
    end
    return (now - lastEnable) > RET_TWIST_BAR_GATE_TTL_SECONDS
end

--- Returns true when the TBC Ret twist bars are gated on by a rotation call.
--- @return boolean
function NAG:IsTBCRetBarsEnabled()
    if not getTBCRetBarsGate() then
        return false
    end
    local now = GetTime()
    if isTBCRetBarsGateExpired(now) then
        ns.tbcRetBarsGateEnabled = false
        return false
    end
    return true
end

--- Enable the TBC Ret twist bars gate (does not override user visibility settings).
--- @return boolean Always false so it never short-circuits rotation strings
function NAG:EnableTBCRetBars()
    local now = GetTime()
    local wasEnabled = getTBCRetBarsGate()
    ns.tbcRetBarsGateEnabled = true
    updateTBCRetBarsGateLastEnable(now)

    local bar = ns.PaladinRetTwistBar
    if bar and bar.UpdateVisibility and not wasEnabled then
        bar:UpdateVisibility()
    end

    local TimerManager = ns.TimerManager
    if TimerManager and TimerManager.Create then
        TimerManager:Cancel(TimerManager.Categories.UI_NOTIFICATION, "tbcRetBarsGateExpire")
        TimerManager:Create(
            TimerManager.Categories.UI_NOTIFICATION,
            "tbcRetBarsGateExpire",
            function()
                local expiredNow = GetTime()
                if isTBCRetBarsGateExpired(expiredNow) then
                    ns.tbcRetBarsGateEnabled = false
                    if bar and bar.UpdateVisibility then
                        bar:UpdateVisibility()
                    end
                end
            end,
            RET_TWIST_BAR_GATE_TTL_SECONDS,
            false
        )
    end
    return false
end

--- Returns the number of player melee swings observed since entering combat.
--- @return number
function NAG:RetTwistSwingCount()
    local m = ns.PaladinRetTwistModule
    if not m then
        return 0
    end
    m:InitializeState()
    if not m.state then
        return 0
    end
    return m.state.swingCount or 0
end

--- Returns true when we have observed more than `minSwings` swings since entering combat.
--- WA used `meleeCount > 2` as a warmup gate for filler suggestions.
--- @param minSwings number|nil Default: 2
--- @return boolean
function NAG:RetTwistWarmupComplete(minSwings)
    local threshold = minSwings
    if threshold == nil then
        threshold = 2
    end
    if threshold < 0 then
        threshold = 0
    end
    return self:RetTwistSwingCount() > threshold
end

--- Returns recent twist attempts (runtime-only) for visualization modules (e.g., RetTwistBar).
--- @return number timeSeconds
--- @return number soCSpellId
--- @return number twistSpellId
function NAG:RetTwistGetLastSuccess()
    local m = ns.PaladinRetTwistModule
    if not m then
        return 0, 0, 0
    end
    m:InitializeState()
    if not m.state then
        return 0, 0, 0
    end
    return m.state.lastTwistSuccessTime or 0, m.state.lastTwistSuccessSoCId or 0, m.state.lastTwistSuccessTwistId or 0
end


