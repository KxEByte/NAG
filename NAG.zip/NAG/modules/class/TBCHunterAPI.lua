--- @module "NAG.TBCHunterAPI"
--- Stateful TBC hunter timing engine for SS/filler prediction.
---
--- This module provides a rolling state-machine timeline where each state
--- represents one predicted Auto Shot cycle and carries SS/filler viability.
---
--- License: CC BY-NC 4.0
--- Authors: Rakizi, Fonsas

-- ============================ LOCALIZE ============================
local _, ns = ...
local GetTime = _G.GetTime
local UnitClassBase = _G.UnitClassBase

--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local Version = ns.Version
local StateMachine = ns.StateMachine
local swingTimerLib = ns.LibClassicSwingTimerAPI

-- ============================ CONSTANTS ============================
local DEFAULT_WINDUP_SECONDS = 0.5
local DEFAULT_STEADY_CAST_SECONDS = 1.5
local EARLY_GAP_MIN_SECONDS = 0.1
local FILLER_SAFETY_TOLERANCE_SECONDS = 0.1
local FILLER_MIN_SWING_SECONDS = 1.7
local DEFAULT_HORIZON_SECONDS = 8.0
local MAX_STATE_CYCLES = 32
local STATE_RING_SIZE = 9

local SS_SHORT_GAP_MIN_SECONDS = 0.150
local SS_PREFERRED_PRESS_OFFSET_SECONDS = 0.050
local GCD_SECONDS = 1.5

local MULTI_SHOT_TBC_ID = 27021
local ARCANE_SHOT_TBC_ID = 27019
local MULTI_SHOT_COOLDOWN_SECONDS = 10.0
local ARCANE_SHOT_COOLDOWN_SECONDS = 6.0
local ACTION_NONE = "none"
local ACTION_SS = "SS"
local ACTION_MS = "MS"
local ACTION_AR = "AR"

local SWING_SNAPSHOT_MAX_AGE_SECONDS = 1.0
local CYCLE_TRACKER_RESET_IDLE_SECONDS = 3.0
local CYCLE_TRACKER_SPEED_CHANGE_THRESHOLD_SECONDS = 0.05
local CYCLE_TRACKER_AUTO_OFFSET_TOLERANCE_CYCLES = 0.20

local STATE_TIMELINE_DEBUG_PRINT_VERSION = "2026.02.18-2"

local defaults = {
    class = {
        enabled = true,
    }
}

--- @class TBCHunterAPI:CoreModule
local TBCHunterAPI = NAG:CreateModule("TBCHunterAPI", defaults, {
    moduleType = ns.MODULE_TYPES.CLASS,
    className = "HUNTER",
    optionsCategory = ns.MODULE_CATEGORIES.CLASS,
    hidden = function()
        return UnitClassBase("player") ~= "HUNTER"
    end,
})

ns.TBCHunterAPI = TBCHunterAPI

-- ============================ STATE MACHINE OVERVIEW ============================
--[[ 
Prediction pipeline overview:
1) ResolveTimingInputs(snap) normalizes now/readiness/swing/cast inputs.
2) EvaluateStateTimeline(...) builds static run inputs (horizon, earlyGapDuration, firstAutoAt).
3) StateMachine.CreateTimelinePredictor(...) runs BuildHunterCycleStep repeatedly.
4) BuildHunterCycleStep(...) computes one state window and delegates the per-state decision.
5) DecideHunterStateAction(...) selects SS/MS/AR (or none) and returns timing/carry-forward mutations.
6) Step context is advanced and fed into the next state to create a chained forecast.

Carry-forward values between states:
- stateStartAt/stateEndAt (autoshot cycle boundaries)
- actionableAt/gcdReadyAt (when actions are legal)
- ssQueuedLastState (queued SS hand-off)
- msReadyAt/arReadyAt (cooldown readiness timestamps)
]]

local lastValidRangedSnapshot = nil
local cycleTracker = {
    initialized = false,
    anchorAutoAt = 0,
    anchorAbsoluteCycle = 1,
    anchorSpeed = 0,
    lastGoodNow = 0,
}

-- ============================ INTERNAL HELPERS ============================
--- @return boolean
local function IsDevModeEnabled()
    return NAG and NAG.IsDevModeEnabled and NAG:IsDevModeEnabled() or false
end

--- @return table|nil
local function BuildRangedSwingSnapshot()
    if not swingTimerLib or not swingTimerLib.UnitSwingTimerInfo then
        return nil
    end

    local speed, expiration = swingTimerLib:UnitSwingTimerInfo("player", "ranged")
    if not speed or not expiration or speed <= 0 then
        return nil
    end

    local now = GetTime()
    local timeToNext = expiration - now
    if timeToNext < 0 then
        timeToNext = 0
    end

    return {
        now = now,
        rangedSpeed = speed,
        rangedTimeToNext = timeToNext,
        expirationAt = expiration,
    }
end

--- @param value number
--- @return number
local function Round(value)
    if value >= 0 then
        return math.floor(value + 0.5)
    end
    return math.ceil(value - 0.5)
end

local function ResetCycleTracker()
    cycleTracker.initialized = false
    cycleTracker.anchorAutoAt = 0
    cycleTracker.anchorAbsoluteCycle = 1
    cycleTracker.anchorSpeed = 0
    cycleTracker.lastGoodNow = 0
end

--- @param firstAutoAt number
--- @param rangedSpeed number
--- @param now number
--- @return number
local function ResolveAbsoluteCycleBase(firstAutoAt, rangedSpeed, now)
    if not cycleTracker.initialized then
        cycleTracker.initialized = true
        cycleTracker.anchorAutoAt = firstAutoAt
        cycleTracker.anchorAbsoluteCycle = 1
        cycleTracker.anchorSpeed = rangedSpeed
        cycleTracker.lastGoodNow = now
        return 1
    end

    local idleFor = now - (tonumber(cycleTracker.lastGoodNow or 0) or 0)
    local speedDiff = math.abs((tonumber(cycleTracker.anchorSpeed or 0) or 0) - rangedSpeed)
    if idleFor > CYCLE_TRACKER_RESET_IDLE_SECONDS or speedDiff > CYCLE_TRACKER_SPEED_CHANGE_THRESHOLD_SECONDS then
        cycleTracker.anchorAutoAt = firstAutoAt
        cycleTracker.anchorAbsoluteCycle = 1
        cycleTracker.anchorSpeed = rangedSpeed
        cycleTracker.lastGoodNow = now
        return 1
    end

    local cycleOffsetFloat = (firstAutoAt - cycleTracker.anchorAutoAt) / rangedSpeed
    local cycleOffsetRounded = Round(cycleOffsetFloat)
    if math.abs(cycleOffsetFloat - cycleOffsetRounded) > CYCLE_TRACKER_AUTO_OFFSET_TOLERANCE_CYCLES then
        local estimatedAbs = cycleTracker.anchorAbsoluteCycle + cycleOffsetRounded
        if estimatedAbs < 1 then
            estimatedAbs = 1
        end
        cycleTracker.anchorAutoAt = firstAutoAt
        cycleTracker.anchorAbsoluteCycle = estimatedAbs
        cycleTracker.anchorSpeed = rangedSpeed
        cycleTracker.lastGoodNow = now
        return estimatedAbs
    end

    local absoluteBase = cycleTracker.anchorAbsoluteCycle + cycleOffsetRounded
    if absoluteBase < 1 then
        absoluteBase = 1
    end
    cycleTracker.lastGoodNow = now
    cycleTracker.anchorSpeed = rangedSpeed
    return absoluteBase
end

--- Builds the best available snapshot for state timeline calls.
--- @return table|nil
local function BuildBestSnapshot()
    local hunterWeaveModule = NAG and NAG.GetModule and NAG:GetModule("HunterWeaveModule", true) or nil
    if hunterWeaveModule and hunterWeaveModule.GetWeaveSnapshot then
        local snap = hunterWeaveModule:GetWeaveSnapshot()
        if snap and snap.ok then
            return snap
        end
    end
    return nil
end

--- @param horizonSeconds number|nil
--- @return number
local function NormalizeHorizon(horizonSeconds)
    local horizon = tonumber(horizonSeconds or DEFAULT_HORIZON_SECONDS) or DEFAULT_HORIZON_SECONDS
    if horizon <= 0 then
        horizon = DEFAULT_HORIZON_SECONDS
    end
    return horizon
end

--- @param cycleIndex number
--- @return number
local function GetStateId(cycleIndex)
    if cycleIndex <= 0 then
        return 1
    end
    return ((cycleIndex - 1) % STATE_RING_SIZE) + 1
end

--- @param spellId number
--- @return number|nil
local function GetSpellReadyIn(spellId)
    if NAG and NAG.SpellTimeToReady then
        local readyIn = tonumber(NAG:SpellTimeToReady(spellId) or 0) or 0
        if readyIn < 0 then
            readyIn = 0
        end
        return readyIn
    end
    if NAG and NAG.SpellIsReady then
        if NAG:SpellIsReady(spellId) then
            return 0
        end
    end
    return nil
end

--- @param snap table|nil
--- @return number now
--- @return number readyInEffective
--- @return number readyInBase
--- @return number queuedEndIn
--- @return boolean steadyQueued
--- @return number rangedTimeToNext
--- @return number rangedSpeed
--- @return number windupSeconds
--- @return number steadyCastSeconds
--- @return boolean usedFallbackSnapshot
--- @return boolean ok
local function ResolveTimingInputs(snap)
    local now = tonumber(snap and snap.now or 0) or 0
    if now <= 0 then
        now = GetTime()
    end

    local readyInBase = tonumber(snap and snap.nextActionDelay or 0) or 0
    if readyInBase < 0 then
        readyInBase = 0
    end

    local steadyQueued = (snap and snap.steadyQueued and true) or false
    local queuedEndIn = 0
    if steadyQueued and snap and snap.queuedSteadyEndAt and now > 0 then
        queuedEndIn = (tonumber(snap.queuedSteadyEndAt) or 0) - now
        if queuedEndIn < 0 then
            queuedEndIn = 0
        end
    end

    local readyInEffective = readyInBase
    if queuedEndIn > readyInEffective then
        readyInEffective = queuedEndIn
    end

    local rangedTimeToNext = tonumber(snap and snap.rangedTimeToNext or 0) or 0
    local rangedSpeed = tonumber(snap and snap.rangedSpeed or 0) or 0
    local usedFallbackSnapshot = false
    local windupSeconds = DEFAULT_WINDUP_SECONDS
    local steadyCastSeconds = tonumber(snap and snap.steadyCast or DEFAULT_STEADY_CAST_SECONDS) or DEFAULT_STEADY_CAST_SECONDS
    if steadyCastSeconds < 0 then
        steadyCastSeconds = 0
    end

    if rangedSpeed > 0 and rangedTimeToNext > 0 then
        lastValidRangedSnapshot = {
            now = now,
            rangedSpeed = rangedSpeed,
            rangedTimeToNext = rangedTimeToNext,
            expirationAt = now + rangedTimeToNext,
        }
    end

    if rangedSpeed <= 0 or rangedTimeToNext <= 0 then
        local live = BuildRangedSwingSnapshot()
        if live then
            now = tonumber(live.now or now) or now
            rangedTimeToNext = tonumber(live.rangedTimeToNext or 0) or 0
            rangedSpeed = tonumber(live.rangedSpeed or 0) or 0
            lastValidRangedSnapshot = {
                now = now,
                rangedSpeed = rangedSpeed,
                rangedTimeToNext = rangedTimeToNext,
                expirationAt = tonumber(live.expirationAt or (now + rangedTimeToNext)) or (now + rangedTimeToNext),
            }
        elseif lastValidRangedSnapshot then
            local snapshotNow = tonumber(lastValidRangedSnapshot.now or 0) or 0
            local snapshotSpeed = tonumber(lastValidRangedSnapshot.rangedSpeed or 0) or 0
            local snapshotExpiration = tonumber(lastValidRangedSnapshot.expirationAt or 0) or 0
            local snapshotAge = now - snapshotNow
            if snapshotSpeed > 0 and snapshotExpiration > 0 and snapshotAge >= 0 and snapshotAge <= SWING_SNAPSHOT_MAX_AGE_SECONDS then
                rangedSpeed = snapshotSpeed
                rangedTimeToNext = snapshotExpiration - now
                if rangedTimeToNext < 0 then
                    rangedTimeToNext = 0
                end
                usedFallbackSnapshot = true
            else
                return now, readyInEffective, readyInBase, queuedEndIn, steadyQueued, 0, 0, windupSeconds, steadyCastSeconds, false, false
            end
        else
            return now, readyInEffective, readyInBase, queuedEndIn, steadyQueued, 0, 0, windupSeconds, steadyCastSeconds, false, false
        end
    end

    if rangedSpeed <= 0 or rangedTimeToNext <= 0 then
        return now, readyInEffective, readyInBase, queuedEndIn, steadyQueued, 0, 0, windupSeconds, steadyCastSeconds, usedFallbackSnapshot, false
    end

    if windupSeconds < 0 then
        windupSeconds = 0
    end
    if windupSeconds > rangedSpeed then
        windupSeconds = rangedSpeed
    end

    return now, readyInEffective, readyInBase, queuedEndIn, steadyQueued, rangedTimeToNext, rangedSpeed, windupSeconds, steadyCastSeconds, usedFallbackSnapshot, true
end

--- @param result table
--- @param expectedPrintVersion string|nil
local function PrintStateTimelineDebug(result, expectedPrintVersion)
    if not IsDevModeEnabled() then
        return
    end

    local expected = tostring(expectedPrintVersion or STATE_TIMELINE_DEBUG_PRINT_VERSION)
    local versionMatches = expected == STATE_TIMELINE_DEBUG_PRINT_VERSION
    local states = result.states or {}
    local s1 = states[1] or {}
    local s2 = states[2] or {}
    local s3 = states[3] or {}
    local s4 = states[4] or {}
    local now = tonumber(result.now or 0) or 0

    local function SafeIn(at)
        local value = tonumber(at or 0) or 0
        value = value - now
        if value < 0 then
            value = 0
        end
        return value
    end

    print(string.format(
        "[TBCHUNTER_API][STATE_TIMELINE_DEBUG][v=%s][versionMatch=%s][expected=%s] meaning=\"state-machine timeline with persistent absolute cycle indexing and stable state progression\" ok=%s reason=%s now=%.3f horizon=%.3f activeState=%d activeCycle=%d states=%d speed=%.3f windup=%.3f earlyGap=%.3f readyInBase=%.3f queuedEndIn=%.3f readyInEffective=%.3f speedOk=%s fallbackUsed=%s s1_id=%d s1_cycle=%d s1_autoIn=%.3f s1_effStartIn=%.3f s1_effEndIn=%.3f s1_effValid=%s s1_ssFits=%s s1_filler=%s s2_id=%d s2_cycle=%d s2_effStartIn=%.3f s2_effEndIn=%.3f s2_effValid=%s s2_ssFits=%s s2_filler=%s s3_id=%d s3_cycle=%d s3_ssFits=%s s3_filler=%s s4_id=%d s4_cycle=%d s4_ssFits=%s s4_filler=%s nextMS_found=%s nextMS_cycle=%d nextMS_in=%.3f nextAR_found=%s nextAR_cycle=%d nextAR_in=%.3f",
        STATE_TIMELINE_DEBUG_PRINT_VERSION,
        tostring(versionMatches),
        expected,
        tostring(result.ok == true),
        tostring(result.reason or "none"),
        now,
        tonumber(result.horizonSeconds or 0) or 0,
        tonumber(result.activeStateId or 0) or 0,
        tonumber(result.activeCycleIndex or 0) or 0,
        #states,
        tonumber(result.rangedSpeed or 0) or 0,
        tonumber(result.windupSeconds or 0) or 0,
        tonumber(result.earlyGapDuration or 0) or 0,
        tonumber(result.readyInBase or 0) or 0,
        tonumber(result.queuedEndIn or 0) or 0,
        tonumber(result.readyInEffective or 0) or 0,
        tostring(result.speedOk == true),
        tostring(result.usedSnapshotFallback == true),
        tonumber(s1.stateId or 0) or 0,
        tonumber(s1.absoluteCycleIndex or s1.cycleIndex or 0) or 0,
        SafeIn(s1.autoAt),
        SafeIn(s1.effectiveGapStartAt),
        SafeIn(s1.effectiveGapEndAt),
        tostring(s1.effectiveWindowValid == true),
        tostring(s1.ssFits == true),
        tostring(s1.fillerSpell or "none"),
        tonumber(s2.stateId or 0) or 0,
        tonumber(s2.absoluteCycleIndex or s2.cycleIndex or 0) or 0,
        SafeIn(s2.effectiveGapStartAt),
        SafeIn(s2.effectiveGapEndAt),
        tostring(s2.effectiveWindowValid == true),
        tostring(s2.ssFits == true),
        tostring(s2.fillerSpell or "none"),
        tonumber(s3.stateId or 0) or 0,
        tonumber(s3.absoluteCycleIndex or s3.cycleIndex or 0) or 0,
        tostring(s3.ssFits == true),
        tostring(s3.fillerSpell or "none"),
        tonumber(s4.stateId or 0) or 0,
        tonumber(s4.absoluteCycleIndex or s4.cycleIndex or 0) or 0,
        tostring(s4.ssFits == true),
        tostring(s4.fillerSpell or "none"),
        tostring(result.nextMS and result.nextMS.found == true),
        tonumber(result.nextMS and result.nextMS.absoluteCycleIndex or 0) or 0,
        tonumber(result.nextMS and result.nextMS.timeFromNow or 0) or 0,
        tostring(result.nextAR and result.nextAR.found == true),
        tonumber(result.nextAR and result.nextAR.absoluteCycleIndex or 0) or 0,
        tonumber(result.nextAR and result.nextAR.timeFromNow or 0) or 0
    ))

    local maxCascadeStates = 3
    local stateCount = #states
    if stateCount < maxCascadeStates then
        maxCascadeStates = stateCount
    end

    for stateIndex = 1, maxCascadeStates do
        local state = states[stateIndex] or {}
        local stateStartAt = tonumber(state.stateStartAt or 0) or 0
        local stateEndAt = tonumber(state.stateEndAt or 0) or 0
        local stateAdjustedEndAt = tonumber(state.stateEndAtAdjusted or stateEndAt) or stateEndAt
        local gcdBeforeAt = tonumber(state.actionableAt or 0) or 0
        local gcdAfterAt = tonumber(state.gcdEndAt or 0) or 0
        local nextActionAt = tonumber(state.postFillerActionableAt or state.nextActionableAt or 0) or 0
        local carryMsBeforeAt = tonumber(state.msReadyAtBefore or 0) or 0
        local carryArBeforeAt = tonumber(state.arReadyAtBefore or 0) or 0
        local carryMsAfterAt = tonumber(state.msReadyAtAfter or 0) or 0
        local carryArAfterAt = tonumber(state.arReadyAtAfter or 0) or 0
        local fillerCastAt = tonumber(state.fillerCastAt or 0) or 0
        local ssPressAt = tonumber(state.ssPressAt or 0) or 0
        local ssCastStartAt = tonumber(state.ssCastStartAt or 0) or 0
        local ssCastEndAt = tonumber(state.ssCastEndAt or 0) or 0
        local fillerCastAt2 = tonumber(state.fillerCastAt2 or 0) or 0
        local ssPressAt2 = tonumber(state.ssPressAt2 or 0) or 0
        local ssCastStartAt2 = tonumber(state.ssCastStartAt2 or 0) or 0
        local ssCastEndAt2 = tonumber(state.ssCastEndAt2 or 0) or 0

        print(string.format(
            "[TBCHUNTER_API][STATE_CASCADE][v=%s] idx=%d stateId=%d cycle=%d stateStartAt=%.3f stateStartIn=%.3f stateEndAt=%.3f stateEndIn=%.3f stateEndAdjustedAt=%.3f stateEndAdjustedIn=%.3f carry_ssQueuedLast=%s carry_msReadyIn=%.3f carry_arReadyIn=%.3f carry_actionableIn=%.3f carry_gcdReadyIn=%.3f chosen=%s reason=%s ssPressIn=%.3f ssCastStartIn=%.3f ssCastEndIn=%.3f filler=%s fillerAtIn=%.3f chosen2=%s reason2=%s ssPress2In=%.3f ssCastStart2In=%.3f ssCastEnd2In=%.3f filler2=%s filler2AtIn=%.3f out_ssQueued=%s out_msReadyIn=%.3f out_arReadyIn=%.3f out_nextActionableIn=%.3f out_gcdReadyIn=%.3f clipped=%s",
            STATE_TIMELINE_DEBUG_PRINT_VERSION,
            stateIndex,
            tonumber(state.stateId or 0) or 0,
            tonumber(state.absoluteCycleIndex or state.cycleIndex or 0) or 0,
            stateStartAt,
            SafeIn(stateStartAt),
            stateEndAt,
            SafeIn(stateEndAt),
            stateAdjustedEndAt,
            SafeIn(stateAdjustedEndAt),
            tostring(state.ssQueuedLastState == true),
            SafeIn(carryMsBeforeAt),
            SafeIn(carryArBeforeAt),
            SafeIn(gcdBeforeAt),
            SafeIn(tonumber(state.gcdEndAt or 0) or 0),
            tostring(state.chosenAction or ACTION_NONE),
            tostring(state.stateReason or "none"),
            SafeIn(ssPressAt),
            SafeIn(ssCastStartAt),
            SafeIn(ssCastEndAt),
            tostring(state.fillerSpell or ACTION_NONE),
            SafeIn(fillerCastAt),
            tostring(state.chosenAction2 or ACTION_NONE),
            tostring(state.stateReason2 or "none"),
            SafeIn(ssPressAt2),
            SafeIn(ssCastStartAt2),
            SafeIn(ssCastEndAt2),
            tostring(state.fillerSpell2 or ACTION_NONE),
            SafeIn(fillerCastAt2),
            tostring(state.ssQueuedThisState == true),
            SafeIn(carryMsAfterAt),
            SafeIn(carryArAfterAt),
            SafeIn(nextActionAt),
            SafeIn(gcdAfterAt),
            tostring(state.clipped == true)
        ))
    end
end

--- Decides the action to perform in one hunter state.
--- @param context table
--- @param stepInput table
--- @param stateWindow table
--- @return table decision
local function DecideHunterStateAction(context, stepInput, stateWindow)
    local decision = {
        chosenAction = ACTION_NONE,
        stateReason = "no_action_selected",
        ssPressAt = 0,
        ssCastStartAt = 0,
        ssCastEndAt = 0,
        gcdEndAt = tonumber(context.gcdReadyAt or 0) or 0,
        nextActionableAt = tonumber(context.actionableAt or 0) or 0,
        fillerSpellId = 0,
        fillerSpell = ACTION_NONE,
        fillerCastAt = 0,
        fillerCastEndAt = 0,
        fillerGcdEndAt = 0,
        msReadyAtAfter = tonumber(context.msReadyAt or 0) or 0,
        arReadyAtAfter = tonumber(context.arReadyAt or 0) or 0,
        ssQueuedThisState = false,
        stateEndAtAdjusted = stateWindow.stateEndAt,
        clipped = false,
    }

    local actionableAt = tonumber(context.actionableAt or 0) or 0
    local gcdReadyAt = tonumber(context.gcdReadyAt or 0) or 0
    if gcdReadyAt > actionableAt then
        actionableAt = gcdReadyAt
    end

    local stateStartAt = stateWindow.stateStartAt
    local stateEndAt = stateWindow.stateEndAt
    local windupStartAt = stateWindow.windupStartAt
    local steadyCastSeconds = stepInput.steadyCastSeconds
    local rangedSpeed = stepInput.rangedSpeed
    local earlyGapDuration = stepInput.earlyGapDuration
    local speedOk = stepInput.speedOk == true
    local fillerBoundary = math.max(GCD_SECONDS, steadyCastSeconds)

    -- Execute queued SS from previous state before any fresh decision.
    if context.ssQueuedLastState == true then
        decision.chosenAction = ACTION_SS
        decision.stateReason = "queued_ss_execute_at_state_start"
        decision.ssPressAt = stateStartAt
        decision.ssCastStartAt = stateStartAt
        decision.ssCastEndAt = stateStartAt + steadyCastSeconds
        decision.gcdEndAt = decision.ssPressAt + GCD_SECONDS
        decision.nextActionableAt = decision.ssCastEndAt
        if decision.gcdEndAt > decision.nextActionableAt then
            decision.nextActionableAt = decision.gcdEndAt
        end
        if decision.ssCastEndAt > stateEndAt then
            decision.clipped = true
            decision.stateEndAtAdjusted = decision.ssCastEndAt
        end
        return decision
    end

    if actionableAt >= stateEndAt then
        decision.stateReason = "actionable_after_state_end"
        decision.nextActionableAt = actionableAt
        decision.gcdEndAt = actionableAt
        return decision
    end

    if (actionableAt + steadyCastSeconds) <= stateEndAt then
        decision.chosenAction = ACTION_SS
        decision.stateReason = "ss_cast_without_clip"
        decision.ssPressAt = actionableAt
        decision.ssCastStartAt = actionableAt
        decision.ssCastEndAt = decision.ssCastStartAt + steadyCastSeconds
        decision.gcdEndAt = decision.ssPressAt + GCD_SECONDS
        decision.nextActionableAt = decision.ssCastEndAt
        if decision.gcdEndAt > decision.nextActionableAt then
            decision.nextActionableAt = decision.gcdEndAt
        end
        return decision
    end

    if actionableAt < windupStartAt and speedOk and earlyGapDuration > EARLY_GAP_MIN_SECONDS then
        local fillerSafetyLhs = actionableAt + GCD_SECONDS + fillerBoundary
        local fillerSafetyRhs = (2 * rangedSpeed) - FILLER_SAFETY_TOLERANCE_SECONDS
        if fillerSafetyLhs < fillerSafetyRhs then
            if actionableAt >= (tonumber(context.msReadyAt or 0) or 0) then
                decision.chosenAction = ACTION_MS
                decision.stateReason = "filler_ms_safe"
                decision.fillerSpellId = MULTI_SHOT_TBC_ID
                decision.fillerSpell = ACTION_MS
                decision.msReadyAtAfter = actionableAt + MULTI_SHOT_COOLDOWN_SECONDS
            elseif actionableAt >= (tonumber(context.arReadyAt or 0) or 0) then
                decision.chosenAction = ACTION_AR
                decision.stateReason = "filler_ar_safe"
                decision.fillerSpellId = ARCANE_SHOT_TBC_ID
                decision.fillerSpell = ACTION_AR
                decision.arReadyAtAfter = actionableAt + ARCANE_SHOT_COOLDOWN_SECONDS
            end

            if decision.fillerSpellId > 0 then
                decision.fillerCastAt = actionableAt
                decision.fillerCastEndAt = actionableAt
                decision.fillerGcdEndAt = actionableAt + GCD_SECONDS
                decision.gcdEndAt = decision.fillerGcdEndAt
                decision.nextActionableAt = decision.fillerGcdEndAt
                return decision
            end
        end
    end

    if actionableAt >= windupStartAt and actionableAt <= stateEndAt then
        decision.chosenAction = ACTION_SS
        decision.stateReason = "ss_press_inside_windup"
        decision.ssQueuedThisState = true
        decision.ssPressAt = actionableAt
        decision.ssCastStartAt = stateEndAt
        decision.ssCastEndAt = decision.ssCastStartAt + steadyCastSeconds
        decision.gcdEndAt = decision.ssPressAt + GCD_SECONDS
        decision.nextActionableAt = decision.ssCastEndAt
        if decision.gcdEndAt > decision.nextActionableAt then
            decision.nextActionableAt = decision.gcdEndAt
        end
        if decision.ssCastEndAt > stateEndAt then
            decision.clipped = true
            decision.stateEndAtAdjusted = decision.ssCastEndAt
        end
        return decision
    end

    if actionableAt < windupStartAt then
        decision.chosenAction = ACTION_SS
        decision.stateReason = "ss_wait_for_windup_queue"
        decision.ssQueuedThisState = true
        decision.ssPressAt = windupStartAt
        decision.ssCastStartAt = stateEndAt
        decision.ssCastEndAt = decision.ssCastStartAt + steadyCastSeconds
        decision.gcdEndAt = decision.ssPressAt + GCD_SECONDS
        decision.nextActionableAt = decision.ssCastEndAt
        if decision.gcdEndAt > decision.nextActionableAt then
            decision.nextActionableAt = decision.gcdEndAt
        end
        if decision.ssCastEndAt > stateEndAt then
            decision.clipped = true
            decision.stateEndAtAdjusted = decision.ssCastEndAt
        end
        return decision
    end

    decision.stateReason = "no_valid_action_path"
    decision.gcdEndAt = actionableAt
    decision.nextActionableAt = actionableAt
    return decision
end

--- Applies one decision to timeline result/context and computes post-action carry values.
--- @param decision table
--- @param context table
--- @param result table
--- @param stateMeta table
--- @return table applyResult
local function ApplyHunterDecision(decision, context, result, stateMeta)
    local postActionableAt = tonumber(decision.nextActionableAt or 0) or 0
    local fillerSlotStartAt = postActionableAt
    local nextAutoBoundaryAt = (tonumber(stateMeta.autoAt or 0) or 0) + (tonumber(stateMeta.rangedSpeed or 0) or 0)
    local fillerSlotEndAt = nextAutoBoundaryAt - (tonumber(stateMeta.windupSeconds or 0) or 0)
    local fillerSlotDuration = fillerSlotEndAt - fillerSlotStartAt
    if fillerSlotDuration < 0 then
        fillerSlotDuration = 0
    end

    context.msReadyAt = tonumber(decision.msReadyAtAfter or context.msReadyAt or 0) or 0
    context.arReadyAt = tonumber(decision.arReadyAtAfter or context.arReadyAt or 0) or 0

    local fillerSpellId = tonumber(decision.fillerSpellId or 0) or 0
    local fillerSpell = tostring(decision.fillerSpell or ACTION_NONE)
    local fillerCastAt = tonumber(decision.fillerCastAt or 0) or 0
    local fillerCastEndAt = tonumber(decision.fillerCastEndAt or 0) or 0
    local fillerGcdEndAt = tonumber(decision.fillerGcdEndAt or 0) or 0
    if fillerSpellId > 0 then
        if fillerGcdEndAt > postActionableAt then
            postActionableAt = fillerGcdEndAt
        end
        if fillerCastEndAt > postActionableAt then
            postActionableAt = fillerCastEndAt
        end

        local fillerEvent = {
            stateId = tonumber(stateMeta.stateId or 0) or 0,
            cycleIndex = tonumber(stateMeta.cycleIndex or 0) or 0,
            absoluteCycleIndex = tonumber(stateMeta.absoluteCycleIndex or 0) or 0,
            spellId = fillerSpellId,
            spell = fillerSpell,
            at = fillerCastAt,
            timeFromNow = fillerCastAt - (tonumber(stateMeta.now or 0) or 0),
            slotStartAt = fillerSlotStartAt,
            slotEndAt = fillerSlotEndAt,
        }
        if fillerEvent.timeFromNow < 0 then
            fillerEvent.timeFromNow = 0
        end
        result.fillerEvents[#result.fillerEvents + 1] = fillerEvent

        if fillerSpellId == MULTI_SHOT_TBC_ID and not result.nextMS.found then
            result.nextMS.found = true
            result.nextMS.at = fillerCastAt
            result.nextMS.timeFromNow = fillerEvent.timeFromNow
            result.nextMS.stateId = fillerEvent.stateId
            result.nextMS.cycleIndex = fillerEvent.cycleIndex
            result.nextMS.absoluteCycleIndex = fillerEvent.absoluteCycleIndex
            result.nextMS.reason = "state_timeline"
        elseif fillerSpellId == ARCANE_SHOT_TBC_ID and not result.nextAR.found then
            result.nextAR.found = true
            result.nextAR.at = fillerCastAt
            result.nextAR.timeFromNow = fillerEvent.timeFromNow
            result.nextAR.stateId = fillerEvent.stateId
            result.nextAR.cycleIndex = fillerEvent.cycleIndex
            result.nextAR.absoluteCycleIndex = fillerEvent.absoluteCycleIndex
            result.nextAR.reason = "state_timeline"
        end
    end

    return {
        postActionableAt = postActionableAt,
        fillerSlotStartAt = fillerSlotStartAt,
        fillerSlotEndAt = fillerSlotEndAt,
        fillerSlotDuration = fillerSlotDuration,
    }
end

--- Builds one hunter cycle state and advances timeline context.
--- @param context table
--- @param stepInput table
--- @param result table
--- @return table stepResult
local function BuildHunterCycleStep(context, stepInput, result)
    local now = stepInput.now
    local horizonAt = stepInput.horizonAt
    local rangedSpeed = stepInput.rangedSpeed
    local windupSeconds = stepInput.windupSeconds
    local steadyCastSeconds = stepInput.steadyCastSeconds
    local earlyGapDuration = stepInput.earlyGapDuration
    local absoluteCycleBase = stepInput.absoluteCycleBase

    if context.cycleIndex >= MAX_STATE_CYCLES then
        return { done = true, context = context }
    end

    local stateStartAt = tonumber(context.stateStartAt or 0) or 0
    local stateEndAt = tonumber(context.stateEndAt or 0) or 0
    if stateStartAt <= 0 or stateEndAt <= stateStartAt then
        local fallbackEndAt = tonumber(context.autoAt or 0) or 0
        if fallbackEndAt <= 0 then
            fallbackEndAt = now + rangedSpeed
        end
        stateEndAt = fallbackEndAt
        stateStartAt = stateEndAt - rangedSpeed
        if stateStartAt < now - rangedSpeed then
            stateStartAt = now
            stateEndAt = stateStartAt + rangedSpeed
        end
    end

    local autoAt = stateEndAt
    local gapStartAt = stateEndAt - windupSeconds
    local gapEndAt = stateStartAt + earlyGapDuration
    if gapStartAt > horizonAt then
        return { done = true, context = context }
    end

    if gapEndAt < now then
        local nextStateStartAt = stateEndAt
        local nextStateEndAt = nextStateStartAt + rangedSpeed
        context.stateStartAt = nextStateStartAt
        context.stateEndAt = nextStateEndAt
        context.autoAt = nextStateEndAt
        return { context = context }
    end

    context.cycleIndex = context.cycleIndex + 1
    local cycleIndex = context.cycleIndex
    local absoluteCycleIndex = absoluteCycleBase + cycleIndex - 1
    if absoluteCycleIndex < 1 then
        absoluteCycleIndex = 1
    end

    local stateId = GetStateId(absoluteCycleIndex)
    local rawGapDuration = gapEndAt - gapStartAt
    if rawGapDuration < 0 then
        rawGapDuration = 0
    end

    local actionableAt = context.actionableAt
    local effectiveGapStartAt = gapStartAt
    if actionableAt > effectiveGapStartAt then
        effectiveGapStartAt = actionableAt
    end
    local effectiveGapEndAt = gapEndAt
    local effectiveGapDuration = effectiveGapEndAt - effectiveGapStartAt
    if effectiveGapDuration < 0 then
        effectiveGapDuration = 0
    end

    local shortGapAllowed = (actionableAt >= gapStartAt) and ((gapEndAt - actionableAt) >= SS_PREFERRED_PRESS_OFFSET_SECONDS)
    local isPreferredGap = rawGapDuration > SS_SHORT_GAP_MIN_SECONDS
    local ssFits = effectiveGapDuration > 0 and (isPreferredGap or shortGapAllowed)

    local msReadyAtBefore = context.msReadyAt
    local arReadyAtBefore = context.arReadyAt
    local ssQueuedLastStateIn = context.ssQueuedLastState == true
    local stateWindow = {
        stateStartAt = stateStartAt,
        stateEndAt = stateEndAt,
        windupStartAt = gapStartAt,
    }
    local stateMeta = {
        now = now,
        stateId = stateId,
        cycleIndex = cycleIndex,
        absoluteCycleIndex = absoluteCycleIndex,
        autoAt = autoAt,
        rangedSpeed = rangedSpeed,
        windupSeconds = windupSeconds,
    }
    local decision = DecideHunterStateAction(context, {
        steadyCastSeconds = steadyCastSeconds,
        rangedSpeed = rangedSpeed,
        earlyGapDuration = earlyGapDuration,
        speedOk = result.speedOk,
    }, stateWindow)

    local ssPressAt = decision.ssPressAt
    local ssCastStartAt = decision.ssCastStartAt
    local ssCastEndAt = decision.ssCastEndAt
    local gcdEndAt = decision.gcdEndAt
    local nextActionableAt = decision.nextActionableAt
    local stateReason = decision.stateReason

    local fillerSpellId = decision.fillerSpellId
    local fillerSpell = decision.fillerSpell
    local fillerCastAt = decision.fillerCastAt
    local fillerCastEndAt = decision.fillerCastEndAt
    local fillerGcdEndAt = decision.fillerGcdEndAt
    local applyFirst = ApplyHunterDecision(decision, context, result, stateMeta)
    local fillerSlotStartAt = applyFirst.fillerSlotStartAt
    local fillerSlotEndAt = applyFirst.fillerSlotEndAt
    local fillerSlotDuration = applyFirst.fillerSlotDuration
    local postFillerActionableAt = applyFirst.postActionableAt

    local secondDecision = nil
    if decision.chosenAction ~= ACTION_NONE and postFillerActionableAt < stateEndAt then
        local contextSecond = {
            actionableAt = postFillerActionableAt,
            gcdReadyAt = gcdEndAt,
            ssQueuedLastState = false,
            msReadyAt = context.msReadyAt,
            arReadyAt = context.arReadyAt,
        }
        local candidateDecision = DecideHunterStateAction(contextSecond, {
            steadyCastSeconds = steadyCastSeconds,
            rangedSpeed = rangedSpeed,
            earlyGapDuration = earlyGapDuration,
            speedOk = result.speedOk,
        }, stateWindow)

        if candidateDecision.chosenAction ~= ACTION_NONE then
            secondDecision = candidateDecision
            local applySecond = ApplyHunterDecision(secondDecision, context, result, stateMeta)
            postFillerActionableAt = applySecond.postActionableAt
            gcdEndAt = secondDecision.gcdEndAt
        end
    end

    local finalDecision = secondDecision or decision
    local secondChosenAction = secondDecision and secondDecision.chosenAction or nil

    local state = {
        stateId = stateId,
        cycleIndex = cycleIndex,
        absoluteCycleIndex = absoluteCycleIndex,
        stateStartAt = stateStartAt,
        stateEndAt = stateEndAt,
        stateEndAtAdjusted = finalDecision.stateEndAtAdjusted,
        clipped = finalDecision.clipped == true,
        autoAt = autoAt,
        gapStartAt = gapStartAt,
        gapEndAt = gapEndAt,
        gapDuration = rawGapDuration,
        ssQueuedLastState = ssQueuedLastStateIn,
        ssQueuedThisState = finalDecision.ssQueuedThisState == true,
        chosenAction = decision.chosenAction,
        chosenAction2 = secondChosenAction,
        actionableAt = actionableAt,
        effectiveGapStartAt = effectiveGapStartAt,
        effectiveGapEndAt = effectiveGapEndAt,
        effectiveGapDuration = effectiveGapDuration,
        effectiveWindowValid = effectiveGapDuration > 0,
        ssFits = ssFits,
        ssPressAt = ssPressAt,
        ssCastStartAt = ssCastStartAt,
        ssCastEndAt = ssCastEndAt,
        gcdEndAt = gcdEndAt,
        nextActionableAt = nextActionableAt,
        fillerSlotStartAt = fillerSlotStartAt,
        fillerSlotEndAt = fillerSlotEndAt,
        fillerSlotDuration = fillerSlotDuration,
        fillerSpellId = fillerSpellId,
        fillerSpell = fillerSpell,
        fillerCastAt = fillerCastAt,
        fillerCastEndAt = fillerCastEndAt,
        fillerGcdEndAt = fillerGcdEndAt,
        postFillerActionableAt = postFillerActionableAt,
        msReadyAtBefore = msReadyAtBefore,
        arReadyAtBefore = arReadyAtBefore,
        msReadyAtAfter = context.msReadyAt,
        arReadyAtAfter = context.arReadyAt,
        stateReason = stateReason,
        stateReason2 = secondDecision and secondDecision.stateReason or nil,
        ssPressAt2 = secondDecision and secondDecision.ssPressAt or 0,
        ssCastStartAt2 = secondDecision and secondDecision.ssCastStartAt or 0,
        ssCastEndAt2 = secondDecision and secondDecision.ssCastEndAt or 0,
        fillerSpellId2 = secondDecision and secondDecision.fillerSpellId or 0,
        fillerSpell2 = secondDecision and secondDecision.fillerSpell or ACTION_NONE,
        fillerCastAt2 = secondDecision and secondDecision.fillerCastAt or 0,
        fillerCastEndAt2 = secondDecision and secondDecision.fillerCastEndAt or 0,
        fillerGcdEndAt2 = secondDecision and secondDecision.fillerGcdEndAt or 0,
        gcdEndAt2 = secondDecision and secondDecision.gcdEndAt or 0,
        nextActionableAt2 = secondDecision and secondDecision.nextActionableAt or 0,
    }
    state.timeToGapStart = gapStartAt - now
    state.timeToGapEnd = gapEndAt - now
    state.timeToEffectiveGapStart = effectiveGapStartAt - now
    state.timeToEffectiveGapEnd = effectiveGapEndAt - now
    if state.timeToGapStart < 0 then
        state.timeToGapStart = 0
    end
    if state.timeToGapEnd < 0 then
        state.timeToGapEnd = 0
    end
    if state.timeToEffectiveGapStart < 0 then
        state.timeToEffectiveGapStart = 0
    end
    if state.timeToEffectiveGapEnd < 0 then
        state.timeToEffectiveGapEnd = 0
    end
    if not state.effectiveWindowValid then
        state.timeToEffectiveGapStart = 0
        state.timeToEffectiveGapEnd = 0
    end

    context.actionableAt = postFillerActionableAt
    context.gcdReadyAt = gcdEndAt
    context.ssQueuedLastState = finalDecision.ssQueuedThisState == true
    local nextStateStartAt = finalDecision.stateEndAtAdjusted
    context.stateStartAt = nextStateStartAt
    context.stateEndAt = nextStateStartAt + rangedSpeed
    context.autoAt = context.stateEndAt

    return {
        context = context,
        state = state,
    }
end

--- @param snap table|nil
--- @param horizonSeconds number|nil
--- @return table result
local function EvaluateStateTimeline(snap, horizonSeconds)
    local result = {
        ok = false,
        reason = "not_ready",
        classOk = UnitClassBase("player") == "HUNTER",
        versionOk = Version:IsTBC(),
        moduleEnabled = false,
        inputsOk = false,
        now = 0,
        horizonSeconds = NormalizeHorizon(horizonSeconds),
        readyInBase = 0,
        queuedEndIn = 0,
        readyInEffective = 0,
        steadyQueued = false,
        rangedTimeToNext = 0,
        rangedSpeed = 0,
        usedSnapshotFallback = false,
        windupSeconds = DEFAULT_WINDUP_SECONDS,
        steadyCastSeconds = DEFAULT_STEADY_CAST_SECONDS,
        earlyGapDuration = 0,
        speedOk = false,
        activeStateId = 0,
        activeCycleIndex = 0,
        msReadyAtInitial = 0,
        arReadyAtInitial = 0,
        msReadyAt = 0,
        arReadyAt = 0,
        states = {},
        fillerEvents = {},
        nextMS = { found = false, at = 0, timeFromNow = 0, stateId = 0, cycleIndex = 0, absoluteCycleIndex = 0, reason = "not_found" },
        nextAR = { found = false, at = 0, timeFromNow = 0, stateId = 0, cycleIndex = 0, absoluteCycleIndex = 0, reason = "not_found" },
    }

    if not result.classOk then
        result.reason = "not_hunter"
        return result
    end
    if not result.versionOk then
        result.reason = "not_tbc"
        return result
    end

    result.moduleEnabled = (TBCHunterAPI.db and TBCHunterAPI.db.class and TBCHunterAPI.db.class.enabled) and true or false
    if not result.moduleEnabled then
        result.reason = "module_disabled"
        return result
    end

    local now, readyInEffective, readyInBase, queuedEndIn, steadyQueued, rangedTimeToNext, rangedSpeed, windupSeconds, steadyCastSeconds, usedFallbackSnapshot, ok = ResolveTimingInputs(snap)
    result.now = now
    result.readyInBase = readyInBase
    result.queuedEndIn = queuedEndIn
    result.readyInEffective = readyInEffective
    result.steadyQueued = steadyQueued
    result.rangedTimeToNext = rangedTimeToNext
    result.rangedSpeed = rangedSpeed
    result.usedSnapshotFallback = usedFallbackSnapshot == true
    result.windupSeconds = windupSeconds
    result.steadyCastSeconds = steadyCastSeconds
    result.inputsOk = ok
    result.speedOk = rangedSpeed > FILLER_MIN_SWING_SECONDS

    if not ok then
        result.reason = "invalid_inputs"
        return result
    end

    local earlyGapDuration = rangedSpeed - math.max(GCD_SECONDS, steadyCastSeconds)
    if earlyGapDuration < 0 then
        earlyGapDuration = 0
    end
    result.earlyGapDuration = earlyGapDuration

    local msReadyIn = GetSpellReadyIn(MULTI_SHOT_TBC_ID) or 0
    local arReadyIn = GetSpellReadyIn(ARCANE_SHOT_TBC_ID) or 0
    result.msReadyAtInitial = now + msReadyIn
    result.arReadyAtInitial = now + arReadyIn
    result.msReadyAt = result.msReadyAtInitial
    result.arReadyAt = result.arReadyAtInitial

    local actionableAt = now + readyInEffective
    local nextAutoAt = now + rangedTimeToNext
    local previousAutoAt = nextAutoAt - rangedSpeed
    local firstAutoAt = nextAutoAt
    if now <= (previousAutoAt + earlyGapDuration) then
        firstAutoAt = previousAutoAt
    end

    local horizonAt = now + result.horizonSeconds
    local absoluteCycleBase = ResolveAbsoluteCycleBase(firstAutoAt, rangedSpeed, now)
    result.absoluteCycleBase = absoluteCycleBase

    if not StateMachine then
        StateMachine = ns.StateMachine
    end
    if not StateMachine or type(StateMachine.CreateTimelinePredictor) ~= "function" then
        result.reason = "state_machine_unavailable"
        return result
    end

    local predictor = StateMachine.CreateTimelinePredictor({
        maxSteps = MAX_STATE_CYCLES * 2,
        shouldContinue = function(context)
            return context.cycleIndex < MAX_STATE_CYCLES
        end,
        step = function(context)
            return BuildHunterCycleStep(context, {
                now = now,
                horizonAt = horizonAt,
                rangedSpeed = rangedSpeed,
                windupSeconds = windupSeconds,
                steadyCastSeconds = steadyCastSeconds,
                earlyGapDuration = earlyGapDuration,
                absoluteCycleBase = absoluteCycleBase,
            }, result)
        end,
    })

    local timelinePrediction = predictor:predict({
        autoAt = firstAutoAt + rangedSpeed,
        cycleIndex = 0,
        stateStartAt = firstAutoAt,
        stateEndAt = firstAutoAt + rangedSpeed,
        actionableAt = actionableAt,
        gcdReadyAt = actionableAt,
        ssQueuedLastState = steadyQueued == true,
        msReadyAt = result.msReadyAt,
        arReadyAt = result.arReadyAt,
    })

    result.states = timelinePrediction.states or {}
    if timelinePrediction.context then
        result.msReadyAt = tonumber(timelinePrediction.context.msReadyAt or result.msReadyAt) or result.msReadyAt
        result.arReadyAt = tonumber(timelinePrediction.context.arReadyAt or result.arReadyAt) or result.arReadyAt
    end

    if #result.states == 0 then
        result.reason = "no_states_in_horizon"
        return result
    end

    result.activeStateId = tonumber(result.states[1].stateId or 0) or 0
    result.activeCycleIndex = tonumber(result.states[1].absoluteCycleIndex or result.states[1].cycleIndex or 0) or 0
    if not result.nextMS.found then
        result.nextMS.reason = "not_ready_within_horizon"
    end
    if not result.nextAR.found then
        result.nextAR.reason = "not_ready_within_horizon"
    end
    result.reason = "ok"
    result.ok = true
    return result
end

-- ============================ PUBLIC API ============================
--- Returns full state timeline prediction (state-machine model).
--- @param snap table|nil Optional hunter snapshot
--- @param horizonSeconds number|nil Optional prediction horizon
--- @return table result
function TBCHunterAPI:PredictStateTimeline(snap, horizonSeconds)
    return EvaluateStateTimeline(snap, horizonSeconds)
end

--- Convenience predictor using best available snapshot.
--- @param horizonSeconds number|nil Optional prediction horizon
--- @return table result
function TBCHunterAPI:PredictStateTimelineLive(horizonSeconds)
    local snap = BuildBestSnapshot()
    return EvaluateStateTimeline(snap, horizonSeconds)
end

--- Returns next expected Multi-Shot and Arcane Shot from state timeline.
--- @param snap table|nil Optional hunter snapshot
--- @param horizonSeconds number|nil Optional prediction horizon
--- @return table result
function TBCHunterAPI:PredictNextMSAndARByState(snap, horizonSeconds)
    local timeline = EvaluateStateTimeline(snap, horizonSeconds)
    return {
        ok = timeline.ok == true,
        reason = timeline.reason,
        now = timeline.now,
        horizonSeconds = timeline.horizonSeconds,
        activeStateId = timeline.activeStateId,
        nextMS = timeline.nextMS,
        nextAR = timeline.nextAR,
        stateCount = #(timeline.states or {}),
        timeline = timeline,
    }
end

--- Prints one packed state-timeline debug line and returns structured timeline.
--- @param snap table|nil Optional hunter snapshot
--- @param horizonSeconds number|nil Optional prediction horizon
--- @param expectedPrintVersion string|nil Optional expected version marker
--- @return table result
function TBCHunterAPI:DebugPredictStateTimeline(snap, horizonSeconds, expectedPrintVersion)
    local result = EvaluateStateTimeline(snap, horizonSeconds)
    PrintStateTimelineDebug(result, expectedPrintVersion)
    return result
end

--- Prints one packed state-timeline debug line from live snapshot.
--- @param horizonSeconds number|nil Optional prediction horizon
--- @param expectedPrintVersion string|nil Optional expected version marker
--- @return table result
function TBCHunterAPI:DebugPredictStateTimelineLive(horizonSeconds, expectedPrintVersion)
    local snap = BuildBestSnapshot()
    local result = EvaluateStateTimeline(snap, horizonSeconds)
    PrintStateTimelineDebug(result, expectedPrintVersion)
    return result
end

--- Returns current state timeline debug print contract version.
--- @return string
function TBCHunterAPI:GetStateTimelineDebugPrintVersion()
    return STATE_TIMELINE_DEBUG_PRINT_VERSION
end

-- ============================ LIFECYCLE ============================
function TBCHunterAPI:ModuleEnable()
    lastValidRangedSnapshot = nil
    ResetCycleTracker()
    NAG.TBCHunterPredictStateTimeline = function(_, snap, horizonSeconds)
        return self:PredictStateTimeline(snap, horizonSeconds)
    end
    NAG.TBCHunterPredictStateTimelineLive = function(_, horizonSeconds)
        return self:PredictStateTimelineLive(horizonSeconds)
    end
    NAG.TBCHunterPredictNextMSAndARByState = function(_, snap, horizonSeconds)
        return self:PredictNextMSAndARByState(snap, horizonSeconds)
    end
    NAG.TBCHunterDebugPredictStateTimeline = function(_, snap, horizonSeconds, expectedPrintVersion)
        return self:DebugPredictStateTimeline(snap, horizonSeconds, expectedPrintVersion)
    end
    NAG.TBCHunterDebugPredictStateTimelineLive = function(_, horizonSeconds, expectedPrintVersion)
        return self:DebugPredictStateTimelineLive(horizonSeconds, expectedPrintVersion)
    end
    NAG.TBCHunterStateTimelineDebugVersion = function()
        return self:GetStateTimelineDebugPrintVersion()
    end
end

function TBCHunterAPI:ModuleDisable()
    lastValidRangedSnapshot = nil
    ResetCycleTracker()
    NAG.TBCHunterPredictStateTimeline = nil
    NAG.TBCHunterPredictStateTimelineLive = nil
    NAG.TBCHunterPredictNextMSAndARByState = nil
    NAG.TBCHunterDebugPredictStateTimeline = nil
    NAG.TBCHunterDebugPredictStateTimelineLive = nil
    NAG.TBCHunterStateTimelineDebugVersion = nil
end

return TBCHunterAPI
