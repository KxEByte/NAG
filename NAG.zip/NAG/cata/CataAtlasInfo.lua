local _, ns = ...

local AtlasInfo = {}

ns.AtlasInfo = AtlasInfo
