local _, ns = ...
local UnitClass = _G.UnitClass
local UnitClassBase = _G.UnitClassBase
--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local L = ns.AceLocale:GetLocale("NAG", true)
--- @type Version
local Version = ns.Version
--- @type SpellTrackingManager|AceModule|CoreModule

local defaults = ns.InitializeClassDefaults()

-- MoP Priest spec spell locations
defaults.class.specSpellLocations = {
    [1] = { -- Discipline
        -- ABOVE spells
        -- (empty)

        -- BELOW spells
        [34433] = NAG.SPELL_POSITIONS.BELOW,    -- Shadowfiend

        -- RIGHT spells
        -- (empty)

        -- LEFT spells
        [26297] = NAG.SPELL_POSITIONS.LEFT,     -- Berserking
        [87151] = NAG.SPELL_POSITIONS.LEFT,     -- (unknown spell)
        [82174] = NAG.SPELL_POSITIONS.LEFT,     -- (unknown spell)

        -- AOE spells
        -- (empty)
    },
    [2] = { -- Holy
        -- ABOVE spells
        -- (empty)

        -- BELOW spells
        -- (empty)

        -- RIGHT spells
        -- (empty)

        -- LEFT spells
        -- (empty)

        -- AOE spells
        -- (empty)
    },
    [3] = { -- Shadow
        -- ABOVE spells
        -- (empty)

        -- BELOW spells
        [34433] = NAG.SPELL_POSITIONS.BELOW,    -- Shadowfiend

        -- RIGHT spells
        -- (empty)

        -- LEFT spells
        [26297] = NAG.SPELL_POSITIONS.LEFT,     -- Berserking
        [87151] = NAG.SPELL_POSITIONS.LEFT,     -- (unknown spell)
        [82174] = NAG.SPELL_POSITIONS.LEFT,     -- (unknown spell)

        -- AOE spells
        -- (empty)
    }
}

-- Class assignments for raid coordination
defaults.class.classAssignments = {
    {
        id = "power_word_fortitude",
        name = "Power Word: Fortitude",
        description = "Provide stamina buff to raid (coordinate with other Priests)",
        spellIds = {21562, 469}, -- Power Word: Fortitude
        category = "buff",
    },
}

-- ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
-- Leave below as is

if UnitClassBase('player') ~= "PRIEST" then return end

-- START OF GENERATED_ROTATIONS

local disciplineRotation = {
    -- Core identification
    name = "Discipline",
    class = "PRIEST",

    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_MISTS,
    prePull = {
        { time = -1.5, action = "NAG:GetBattlePotion()" }
    },
    rotationString = [[
    ]],

    -- Tracked IDs for optimization
    spells = {},
    items = {},
}

local holyRotation = {
    -- Core identification
    name = "Holy",
    class = "PRIEST",

    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_MISTS,
    prePull = {
        { time = -1.5, action = "NAG:GetBattlePotion()" }
    },
    rotationString = [[
    ]],

    -- Tracked IDs for optimization
    spells = {},
    items = {},
}

local shadowRotation = {
    -- Core identification
    name = "Priest Shadow",
    specIndex = 3,
    class = "PRIEST",

    -- Required parameters
    default = true,
    enabled = true,
    gameType = Version.GAME_TYPES.CLASSIC_MISTS,
    prePull = {
        { time = -2.5, action = "NAG:Cast(120696)" },
        { time = -1.0, action = "NAG:Cast(76093)" },
        { time = -1.0, action = "NAG:Cast(73510)" }
    },
    lastModified = "08/18/2025",
    rotationString = [[
            (not NAG:AuraIsActive(588)) and NAG:Cast(588)
    or (not NAG:AuraIsActive(15473)) and NAG:Cast(15473)
    or NAG:SpellCanCast(26297) and NAG:Cast(26297)
    or NAG:SpellCanCast(126734) and NAG:Cast(126734)
    or NAG:SpellCanCast(76093) and NAG:Cast(76093)
    or NAG:SpellCanCast(34433) and NAG:Cast(34433)
    or (NAG:UnitIsMoving() and NAG:SpellCanCast(120644)) and NAG:Cast(120644)
    or (NAG:UnitIsMoving() and (NAG:DotRemainingTime(589) <= 6)) and NAG:Cast(589)
    or (NAG:NumberTargets() >= 5) and NAG:Cast(48045)
    or (NAG:SpellCanCast(8092) and (NAG:CurrentGenericResource() <= 2)) and NAG:NotSpamCast(8092)
    or (((not NAG:DotIsActive(34914)) or (NAG:DotRemainingTime(34914) <= 2)) and (NAG:RemainingTime() >= 9)) and NAG:Cast(34914)
    or (((not NAG:DotIsActive(589)) or (NAG:DotRemainingTime(589) <= 1)) and (NAG:RemainingTime() >= 12)) and NAG:Cast(589)
    or (NAG:CurrentGenericResource() >= 3) and NAG:Cast(2944)
    or (NAG:SpellCanCast(32379) and NAG:IsExecutePhase(20)) and NAG:Cast(32379)
    or (NAG:NumberTargets() >= 3) and NAG:ChannelSpell(48045, function() return (NAG:GCDTimeToReady() <= NAG:ChannelClipDelay()) end)
    or NAG:ChannelSpell(15407, function() return (NAG:GCDTimeToReady() <= NAG:ChannelClipDelay()) end)
    or ((((NAG:CurrentManaPercent() <= 20) and (NAG:RemainingTimePercent() >= 50)) or ((NAG:CurrentManaPercent() <= 10) and (NAG:RemainingTimePercent() >= 25))) and NAG:SpellCanCast(47585)) and NAG:Cast(47585)

    ]],

    -- Tracked IDs for optimization
    spells = {589, 2944, 8092, 10060, 15407, 32379, 34433, 34914, 73510, 87160, 120696, 122128, 123040, 127632},
    items = {76093},
    auras = {},
    runes = {},

    -- Optional metadata
    glyphs = {},
    author = "Jiw"
}



--- @class Priest : ClassBase
local Priest = NAG:CreateClassModule("PRIEST", defaults)
if not Priest then return end

function Priest:SetupClassDefaults()
    --ns.AddRotationToDefaults(self.defaults, 1, disciplineRotation)  -- Discipline
    --ns.AddRotationToDefaults(self.defaults, 2, holyRotation)  -- Holy
    ns.AddRotationToDefaults(self.defaults, 3, shadowRotation)  -- Shadow
end


function Priest:RegisterSpellTracking()
    local SpellTrackingManager = NAG:GetModule("SpellTrackingManager")
        SpellTrackingManager:RegisterPeriodicDamage({ 34914 }, { tickTime = 3, lastTickTime = nil })
    SpellTrackingManager:RegisterPeriodicDamage({ 589 }, { tickTime = 3, lastTickTime = nil })
    SpellTrackingManager:RegisterPeriodicDamage({ 2944 }, { tickTime = 1, lastTickTime = nil })
end


NAG.Class = Priest
