--- @module "APLValues_AutoAttacks"
--- Auto Attack related APL value functions for the NAG addon
---
--- This module provides utility functions for auto attack timing, swing timers, and melee attack management.
---
--- License: CC BY-NC 4.0 (https://creativecommons.org/licenses/by-nc/4.0/legalcode)
--- Authors: Rakizi, Fonsas
--- Discord: https://discord.gg/ebonhold
---
--- luacheck: ignore GetSpellInfo
---

-- ~~~~~~~~~~ LOCALIZE ~~~~~~~~~~
local _, ns = ...
--- @type NAG
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")

-- ============================ HEADER LOCALS ============================

-- WoW API (compat)
local WoWAPI = ns.WoWAPI
local Version = ns.Version

-- Libraries
local L = ns.AceLocale:GetLocale("NAG", true)
local RC = ns.RC
local swingTimerLib = ns.LibClassicSwingTimerAPI

-- Modules
local SpellbookManager = ns.SpellbookManager

-- Lazy module cache (avoid GetModule cost unless needed)
local SpecCompat



-- Lua APIs (WoW optimized where available)
local GetTime = _G.GetTime
local UnitAttackSpeed = _G.UnitAttackSpeed
local UnitCastingInfo = _G.UnitCastingInfo
local CreateFrame = _G.CreateFrame
local IsUsableSpell = C_Spell and C_Spell.IsSpellUsable or _G.IsUsableSpell
local IsCurrentSpell = C_Spell and C_Spell.IsCurrentSpell or _G.IsCurrentSpell
local UnitCanAttack = _G.UnitCanAttack
local UnitExists = _G.UnitExists


local format = string.format
local min = math.min
local max = math.max
local abs = math.abs



local sort = table.sort
local concat = table.concat
local type = type
local tonumber = tonumber

-- ============================ MODULE CACHING (PERFORMANCE) ============================
-- Cache frequently accessed modules to avoid GetModule overhead in hot paths
local Types = ns.Types
local StateManager = ns.StateManager

-- ~~~~~~~~~~ CONTENT ~~~~~~~~~~

-- ============================ WARRIOR BAR GATE (TBC) ============================
-- Keep gate helpers here so rotation strings can always call them.
if not NAG.IsTBCWarriorBarsEnabled or not NAG.EnableTBCWarriorBars then
    local WARRIOR_BAR_GATE_TTL_SECONDS = 5

    local function getTBCWarriorBarsGate()
        if ns.tbcWarriorBarsGateEnabled == nil then
            ns.tbcWarriorBarsGateEnabled = false
        end
        return ns.tbcWarriorBarsGateEnabled
    end

    local function getTBCWarriorBarsGateLastEnable()
        if ns.tbcWarriorBarsGateLastEnable == nil then
            ns.tbcWarriorBarsGateLastEnable = 0
        end
        return ns.tbcWarriorBarsGateLastEnable
    end

    local function updateTBCWarriorBarsGateLastEnable(timeSeconds)
        ns.tbcWarriorBarsGateLastEnable = timeSeconds or 0
    end

    local function isTBCWarriorBarsGateExpired(now)
        local lastEnable = getTBCWarriorBarsGateLastEnable()
        if lastEnable <= 0 then
            return true
        end
        return (now - lastEnable) > WARRIOR_BAR_GATE_TTL_SECONDS
    end

    --- Returns true when the TBC Warrior slam bars are gated on by a rotation call.
    --- @return boolean
    function NAG:IsTBCWarriorBarsEnabled()
        if not getTBCWarriorBarsGate() then
            return false
        end
        local now = GetTime()
        if isTBCWarriorBarsGateExpired(now) then
            ns.tbcWarriorBarsGateEnabled = false
            return false
        end
        return true
    end

    --- Enable the TBC Warrior slam bars gate (does not override user visibility settings).
    --- @return boolean Always false so it never short-circuits rotation strings
    function NAG:EnableTBCWarriorBars()
        local now = GetTime()
        local wasEnabled = getTBCWarriorBarsGate()
        ns.tbcWarriorBarsGateEnabled = true
        updateTBCWarriorBarsGateLastEnable(now)

        local bar = ns.WarriorSlamWeaveBar
        if bar and bar.UpdateVisibility and not wasEnabled then
            bar:UpdateVisibility()
        end

        local TimerManager = ns.TimerManager
        if TimerManager and TimerManager.Create then
            TimerManager:Cancel(TimerManager.Categories.UI_NOTIFICATION, "tbcWarriorBarsGateExpire")
            TimerManager:Create(
                TimerManager.Categories.UI_NOTIFICATION,
                "tbcWarriorBarsGateExpire",
                function()
                    local expiredNow = GetTime()
                    if isTBCWarriorBarsGateExpired(expiredNow) then
                        ns.tbcWarriorBarsGateEnabled = false
                        if bar and bar.UpdateVisibility then
                            bar:UpdateVisibility()
                        end
                    end
                end,
                WARRIOR_BAR_GATE_TTL_SECONDS,
                false
            )
        end
        return false
    end
end

-- ============================ HUNTER STEADY BAR GATE (TBC) ============================
-- Gate the Hunter Steady weave bar so it only loads when the rotation is active.
-- The rotation string calls EnableTBCHunterSteadyBars() as the first action to keep this alive.
if not NAG.IsTBCHunterSteadyBarsEnabled or not NAG.EnableTBCHunterSteadyBars then
    local HUNTER_STEADY_BAR_GATE_TTL_SECONDS = 5

    local function getTBCHunterSteadyBarsGate()
        if ns.tbcHunterSteadyBarsGateEnabled == nil then
            ns.tbcHunterSteadyBarsGateEnabled = false
        end
        return ns.tbcHunterSteadyBarsGateEnabled
    end

    local function getTBCHunterSteadyBarsGateLastEnable()
        if ns.tbcHunterSteadyBarsGateLastEnable == nil then
            ns.tbcHunterSteadyBarsGateLastEnable = 0
        end
        return ns.tbcHunterSteadyBarsGateLastEnable
    end

    local function updateTBCHunterSteadyBarsGateLastEnable(timeSeconds)
        ns.tbcHunterSteadyBarsGateLastEnable = timeSeconds or 0
    end

    local function isTBCHunterSteadyBarsGateExpired(now)
        local lastEnable = getTBCHunterSteadyBarsGateLastEnable()
        if lastEnable <= 0 then
            return true
        end
        return (now - lastEnable) > HUNTER_STEADY_BAR_GATE_TTL_SECONDS
    end

    --- Returns true when the TBC Hunter Steady bar is gated on by a rotation call.
    --- @return boolean
    function NAG:IsTBCHunterSteadyBarsEnabled()
        if not getTBCHunterSteadyBarsGate() then
            return false
        end
        local now = GetTime()
        if isTBCHunterSteadyBarsGateExpired(now) then
            ns.tbcHunterSteadyBarsGateEnabled = false
            return false
        end
        return true
    end

    --- Enable the TBC Hunter Steady bar gate (does not override user visibility settings).
    --- @return boolean Always false so it never short-circuits rotation strings
    function NAG:EnableTBCHunterSteadyBars()
        local now = GetTime()
        local wasEnabled = getTBCHunterSteadyBarsGate()
        ns.tbcHunterSteadyBarsGateEnabled = true
        updateTBCHunterSteadyBarsGateLastEnable(now)

        local bar = ns.HunterSteadyWeaveBar
        if bar and bar.UpdateVisibility and not wasEnabled then
            bar:UpdateVisibility()
        end

        local TimerManager = ns.TimerManager
        if TimerManager and TimerManager.Create then
            TimerManager:Cancel(TimerManager.Categories.UI_NOTIFICATION, "tbcHunterSteadyBarsGateExpire")
            TimerManager:Create(
                TimerManager.Categories.UI_NOTIFICATION,
                "tbcHunterSteadyBarsGateExpire",
                function()
                    local expiredNow = GetTime()
                    if isTBCHunterSteadyBarsGateExpired(expiredNow) then
                        ns.tbcHunterSteadyBarsGateEnabled = false
                        if bar and bar.UpdateVisibility then
                            bar:UpdateVisibility()
                        end
                    end
                end,
                HUNTER_STEADY_BAR_GATE_TTL_SECONDS,
                false
            )
        end
        return false
    end
end

-- ============================ HUNTER STEADY EARLY GAP GATE (TBC) ============================
-- Gate the Hunter Steady early-gap segment so it only updates when the rotation opts in.
if not NAG.IsTBCHunterSteadyEARLYgapEnabled or not NAG.EnableTBCHunterSteadyEARLYgap then
    local HUNTER_STEADY_EARLY_GAP_GATE_TTL_SECONDS = 5

    local function getTBCHunterSteadyEarlyGapGate()
        if ns.tbcHunterSteadyEarlyGapGateEnabled == nil then
            ns.tbcHunterSteadyEarlyGapGateEnabled = false
        end
        return ns.tbcHunterSteadyEarlyGapGateEnabled
    end

    local function getTBCHunterSteadyEarlyGapGateLastEnable()
        if ns.tbcHunterSteadyEarlyGapGateLastEnable == nil then
            ns.tbcHunterSteadyEarlyGapGateLastEnable = 0
        end
        return ns.tbcHunterSteadyEarlyGapGateLastEnable
    end

    local function updateTBCHunterSteadyEarlyGapGateLastEnable(timeSeconds)
        ns.tbcHunterSteadyEarlyGapGateLastEnable = timeSeconds or 0
    end

    local function isTBCHunterSteadyEarlyGapGateExpired(now)
        local lastEnable = getTBCHunterSteadyEarlyGapGateLastEnable()
        if lastEnable <= 0 then
            return true
        end
        return (now - lastEnable) > HUNTER_STEADY_EARLY_GAP_GATE_TTL_SECONDS
    end

    --- Returns true when the TBC Hunter Steady early-gap segment gate is enabled by rotation.
    --- @return boolean
    function NAG:IsTBCHunterSteadyEARLYgapEnabled()
        if not getTBCHunterSteadyEarlyGapGate() then
            return false
        end
        local now = GetTime()
        if isTBCHunterSteadyEarlyGapGateExpired(now) then
            ns.tbcHunterSteadyEarlyGapGateEnabled = false
            return false
        end
        return true
    end

    --- Enable the TBC Hunter Steady early-gap segment gate.
    --- @return boolean Always false so it never short-circuits rotation strings
    function NAG:EnableTBCHunterSteadyEARLYgap()
        local now = GetTime()
        ns.tbcHunterSteadyEarlyGapGateEnabled = true
        updateTBCHunterSteadyEarlyGapGateLastEnable(now)

        local TimerManager = ns.TimerManager
        if TimerManager and TimerManager.Create then
            TimerManager:Cancel(TimerManager.Categories.UI_NOTIFICATION, "tbcHunterSteadyEarlyGapGateExpire")
            TimerManager:Create(
                TimerManager.Categories.UI_NOTIFICATION,
                "tbcHunterSteadyEarlyGapGateExpire",
                function()
                    local expiredNow = GetTime()
                    if isTBCHunterSteadyEarlyGapGateExpired(expiredNow) then
                        ns.tbcHunterSteadyEarlyGapGateEnabled = false
                    end
                end,
                HUNTER_STEADY_EARLY_GAP_GATE_TTL_SECONDS,
                false
            )
        end
        return false
    end
end

-- ============================ SHARED SWING TIMER INITIALIZATION ============================

--- Initialize swing timer tracking with optional event handler
--- @param eventHandler function|nil Optional custom event handler function
--- @return boolean True if initialized successfully
local function initializeSwingTimer(eventHandler)
    if not swingTimerLib then return false end
    if NAG.swingTimerInitialized then return true end

    local f = CreateFrame("Frame")

    local function SwingTimerEventHandler(event, ...)
        if eventHandler then
            eventHandler(event, ...)
        else
            if event == "UNIT_SWING_TIMER_DELTA" then
                local _, swingDelta = ...
                NAG.lastSwingDelta = swingDelta
            end
        end
    end

    swingTimerLib.RegisterCallback(f, "UNIT_SWING_TIMER_INFO_INITIALIZED", SwingTimerEventHandler)
    swingTimerLib.RegisterCallback(f, "UNIT_SWING_TIMER_START", SwingTimerEventHandler)
    swingTimerLib.RegisterCallback(f, "UNIT_SWING_TIMER_UPDATE", SwingTimerEventHandler)
    swingTimerLib.RegisterCallback(f, "UNIT_SWING_TIMER_DELTA", SwingTimerEventHandler)

    NAG.swingTimerFrame = f
    NAG.swingTimerInitialized = true
    return true
end

-- ~~~~~~~~~~~~~~~~~~~~
-- Autoattack values

--- Returns the time until the next auto attack for the player.
--- @function NAG:AutoTimeToNext
--- @return number The time until the next auto attack (GCD affected).
--- @return number The raw time until the next auto attack (not affected by GCD).
--- @usage NAG:AutoTimeToNext() <= x
function NAG:AutoTimeToNext()
    if not swingTimerLib then return 0, 0 end

    initializeSwingTimer()

    -- Get swing timer info for both hands
    local mhSpeed, mhExpiration = swingTimerLib:UnitSwingTimerInfo("player", "mainhand")
    local ohSpeed, ohExpiration = swingTimerLib:UnitSwingTimerInfo("player", "offhand")
    if not mhExpiration then return 0, 0 end -- No valid swing timer

    local currentTime = NAG:NextTime()
    local mhTimeToNext = mhExpiration - currentTime
    local ohTimeToNext = ohExpiration and (ohExpiration - currentTime) or math.huge

    -- Get the shorter time until next swing
    local timeToNextSwing = min(mhTimeToNext, ohTimeToNext)
    -- If negative, add weapon speed to get next window
    local timeToNextSwingUpdated = timeToNextSwing
    if timeToNextSwing < 0 then
        timeToNextSwingUpdated = timeToNextSwing + mhSpeed
    end

    -- Get GCD time
    local gcd = NAG:GCDTimeToReady() or 0

    -- Return both GCD-affected and raw times
    return max(0, timeToNextSwingUpdated),
        max(0, mhTimeToNext + currentTime - GetTime()) -- Reverted from NAG:NextTime() back to GetTime()
end

--- Gets the auto swing time for the specified weapon type.
--- @function NAG:AutoSwingTime
--- @param weaponType? string "MainHand", "OffHand", or "Ranged". Defaults to MainHand if not provided.
--- @return number The swing time in seconds, or 0 if invalid.
--- @usage NAG:AutoSwingTime("MainHand")
function NAG:AutoSwingTime(weaponType)
    if not weaponType then
        weaponType = Types:GetType("SwingType").MainHand
    end

    local swingTime
    if weaponType == Types:GetType("SwingType").MainHand then
        swingTime = UnitAttackSpeed("player")
    elseif weaponType == Types:GetType("SwingType").OffHand then
        swingTime = select(2, UnitAttackSpeed("player"))
    elseif weaponType == Types:GetType("SwingType").Ranged then
        swingTime = UnitRangedDamage("player")
    else
        self:Warn("AutoSwingTime: Invalid weapon type: %s", weaponType)
    end
    return swingTime or 0
end

--- Returns true when the player should start auto-attacking the current target.
--- Intended to detect the common case where the player is out of 10-yard range and has not started attacking.
--- Logic:
--- - Target must exist and be attackable
--- - Target distance must be > 10 yards
--- - Auto Attack (6603) must NOT be the current spell (i.e., not already attacking)
--- @function NAG:NeedsToStartAttacking
--- @return boolean True if target is >10y and player is not currently auto-attacking; false otherwise.
--- @usage if NAG:NeedsToStartAttacking() then ... end
function NAG:NeedsToStartAttacking()
    if not UnitExists("target") then
        return false
    end
    if not UnitCanAttack("player", "target") then
        return false
    end

    local distance = self:UnitDistance("target")
    if not distance or distance < 0 then
        return false
    end
    if distance <= 5 then
        return false
    end

    if IsCurrentSpell and IsCurrentSpell(6603) then -- Auto Attack
        return false
    end

    return true
end

--- Returns true if the player is currently auto-attacking the target.
--- Intended to detect if the player has started attacking the current target.
--- Logic:
--- - Target must exist and be attackable
--- - Auto Attack (6603) must be the current spell (i.e., currently attacking)
--- @function NAG:IsAttacking
--- @return boolean True if target exists, is attackable, and player is currently auto-attacking; false otherwise.
--- @usage if NAG:IsAttacking() then ... end
function NAG:IsAttacking()
    if not UnitExists("target") then
        return false
    end
    if not UnitCanAttack("player", "target") then
        return false
    end

    if IsCurrentSpell and IsCurrentSpell(6603) then -- Auto Attack
        return true
    end

    return false
end

-- ============================ SHAMAN: MAELSTROM WEAPON CAST-TIME ADJUSTMENT ============================
-- Enhancement Shaman: Maelstrom Weapon reduces cast time of certain spells by 20% per stack (up to 5).
-- We need to reflect this in weave calculations; WoWAPI GetSpellInfo cast time does not include temporary buffs.
local function clampNumber(value, minValue, maxValue)
    if value == nil then return minValue end
    if value < minValue then return minValue end
    if value > maxValue then return maxValue end
    return value
end

local MAELSTROM_WEAPON_AURA_ID = 51530
local MAELSTROM_AFFECTED_SPELLS = {
    [403] = true,    -- Lightning Bolt
    [421] = true,    -- Chain Lightning
    [117014] = true, -- Elemental Blast
}

local function getMaelstromAdjustedCastTime(self, spellId, baseCastTime)
    if not baseCastTime or baseCastTime <= 0 then
        return baseCastTime or 0
    end
    if self.CLASS_FILENAME ~= "SHAMAN" then
        return baseCastTime
    end
    if not MAELSTROM_AFFECTED_SPELLS[spellId] then
        return baseCastTime
    end

    local stacks = clampNumber(tonumber(self:AuraNumStacks(MAELSTROM_WEAPON_AURA_ID)) or 0, 0, 5)
    if stacks <= 0 then
        return baseCastTime
    end

    local multiplier = 1 - (0.20 * stacks)
    if multiplier < 0 then multiplier = 0 end
    return baseCastTime * multiplier
end

--- Checks if a spell can be safely weaved between auto attacks.
--- For instant cast spells, always returns true since they can't clip auto attacks.
--- For non-instant casts, verifies that the total cast time (input delay + cast time)
--- is less than the time left until the next auto attack.
--- @function NAG:CanWeave
--- @param spellId number The spell ID to check.
--- @return boolean True if the spell can be cast, false otherwise.
--- @usage NAG:CanWeave(12345)
function NAG:CanWeave(spellId)
    local castTime = self:SpellCastTime(spellId) -- Cache was perm storing max casttime: getMaelstromAdjustedCastTime(self, spellId, self:SpellCastTime(spellId))

    -- For instant cast spells, always return true since they can't clip auto attacks
    if castTime == 0 then
        return true
    end


    -- For non-instant casts, check total cast time against swing time
    local gcdTimeToReady = self:GCDTimeToReady()

    -- Apply Maelstrom Weapon logic for input delay with latency awareness and fixed buffer
    local userPing = self:GetNetStats()               -- Use cached network stats
    local baseInputDelay = self:InputDelay() or 0.050 -- fallback to 50ms
    local staticPressBuffer = 0.200                   -- 200ms flat buffer for press-to-cast
    local maelstromStacks = self:AuraNumStacks(51530) -- Maelstrom Weapon spell ID

    -- Final delay: input + ping + 200ms fixed buffer
    local adjustedInputDelay = baseInputDelay + userPing + staticPressBuffer
    if maelstromStacks >= 5 then
        adjustedInputDelay = 0                                  -- instant cast, ignore delay
    else
        adjustedInputDelay = math.min(adjustedInputDelay, 0.45) -- cap at 0.45s
    end

    local swingTimeLeft = self:AutoTimeToNext()
    local totalCastTime = adjustedInputDelay + castTime
    local weaponSpeed = self:AutoSwingTime(Types.SwingType.MainHand)

    return totalCastTime < swingTimeLeft
end

-- ============================ SEAL TWISTING HELPERS ============================
--- Returns the time until the next auto attack *after the current GCD completes*.
--- This is intentionally explicit for APL authors who want to reason about "what can I do next"
--- at the moment the player becomes actionable (GCD end), rather than "right now".
---
--- NOTE: `AutoTimeToNext()` returns two values:
--- 1) a value computed against NAG:NextTime() (may effectively be "at next action time")
--- 2) a raw time-to-next-swing using GetTime() (not GCD-adjusted)
--- For seal twisting we want the second one, adjusted by GCDTimeToReady().
---
--- @function NAG:AutoTimeToNextAfterGCD
--- @return number timeToSwingAfterGCD Seconds until next swing at the moment the GCD is ready (clamped >= 0).
--- @return number rawTimeToSwing Seconds until next swing from *now* (raw, clamped >= 0).
--- @usage NAG:AutoTimeToNextAfterGCD() <= 0.4
function NAG:AutoTimeToNextAfterGCD()
    local _, rawTimeToSwing = self:AutoTimeToNext()
    local gcd = self:GCDTimeToReady() or 0
    if not rawTimeToSwing then
        rawTimeToSwing = 0
    end

    rawTimeToSwing = max(0, rawTimeToSwing)
    if gcd < 0 then gcd = 0 end

    -- If the GCD ends after the next swing occurs, project into the next swing cycle.
    -- This avoids collapsing to 0 ("swingReady") when in reality, at GCD end we are
    -- part-way through the next swing (often "preDiv").
    if gcd > rawTimeToSwing then
        local swingSpeed = self:AutoSwingTime() or 0
        if swingSpeed > 0 then
            return max(0, (rawTimeToSwing + swingSpeed) - gcd), rawTimeToSwing
        end
    end

    return max(0, rawTimeToSwing - gcd), rawTimeToSwing
end

--- Returns the time until the "div boundary" (seconds from now), i.e. the point where starting a new GCD
--- risks pushing the next actionable time into (or past) the twist window.
---
--- For TBC Ret seal twisting we approximate the "div boundary" as:
---     timeToDiv = rawTimeToSwing - (twistWindowSeconds + lastGcdDuration)
---
--- This matches the APL notion of: "how long do I have before I must stop spending a full GCD?"
---
--- @param twistWindowSeconds number|nil Default 0.4
--- @return number timeToDivSeconds Seconds until div boundary from now (clamped >= 0).
--- @usage local t = NAG:RetTwistTimeToDivBoundary(0.4)
function NAG:RetTwistTimeToDivBoundary(twistWindowSeconds)
    local window = twistWindowSeconds or 0.4
    if window < 0 then window = 0 end

    local _, rawTimeToSwing = self:AutoTimeToNext()
    rawTimeToSwing = rawTimeToSwing or 0
    rawTimeToSwing = max(0, rawTimeToSwing)

    local gcdVal = self:GCDTimeValue() or 0
    if gcdVal < 0 then gcdVal = 0 end

    return max(0, rawTimeToSwing - (window + gcdVal))
end

--- Returns the raw (unclamped) time to div boundary. This can be negative after crossing div.
--- @param twistWindowSeconds number|nil Default 0.4
--- @return number rawTimeToDiv Seconds to div boundary from now (can be < 0).
function NAG:RetTwistRawTimeToDivBoundary(twistWindowSeconds)
    local window = twistWindowSeconds or 0.4
    if window < 0 then window = 0 end

    local _, rawTimeToSwing = self:AutoTimeToNext()
    rawTimeToSwing = rawTimeToSwing or 0
    rawTimeToSwing = max(0, rawTimeToSwing)

    local gcdVal = self:GCDTimeValue() or 0
    if gcdVal < 0 then gcdVal = 0 end

    return rawTimeToSwing - (window + gcdVal)
end

--- Returns the raw (unclamped) time to div boundary, evaluated at the next actionable moment.
--- If GCD is running, this projects into the swing cycle where the GCD ends (including rolling
--- into the next swing if the GCD ends after the next swing).
--- If GCD is 0, this is equivalent to RetTwistRawTimeToDivBoundary().
--- @param twistWindowSeconds number|nil Default 0.4
--- @return number rawTimeToDivAtAction Seconds to div boundary at action time (can be < 0).
function NAG:RetTwistRawTimeToDivBoundaryAtAction(twistWindowSeconds)
    local window = twistWindowSeconds or 0.4
    if window < 0 then window = 0 end

    local gcdLeft = self:GCDTimeToReady() or 0
    if gcdLeft < 0 then gcdLeft = 0 end

    local gcdVal = self:GCDTimeValue() or 0
    if gcdVal < 0 then gcdVal = 0 end

    -- Project time-to-swing at the moment we can act.
    local swingAfterGcd, rawSwingNow = self:AutoTimeToNextAfterGCD()
    rawSwingNow = rawSwingNow or 0
    if rawSwingNow < 0 then rawSwingNow = 0 end
    swingAfterGcd = swingAfterGcd or 0
    if swingAfterGcd < 0 then swingAfterGcd = 0 end

    local projectedSwing = (gcdLeft > 0) and swingAfterGcd or rawSwingNow

    -- Show both "simple" (same-cycle) and "projected" (includes next-cycle rollover) values.
    local swingAtActionSimple = max(0, (rawSwingNow or 0) - gcdLeft)
    local swingAtActionProjected = swingAfterGcd or 0
    if not swingAtActionSimple then swingAtActionSimple = 0 end
    if not swingAtActionProjected then swingAtActionProjected = 0 end
    return projectedSwing - (window + gcdVal)
end

--- Stable (hysteresis) "are we before div?" helper to prevent 1-tick flicker when rawTimeToDiv hovers near 0.
--- @param twistWindowSeconds number|nil Default 0.4
--- @param hysteresisSeconds number|nil Default 0.05 (50ms)
--- @return boolean isPreDiv True if we're considered pre-div (stable), false otherwise.
function NAG:RetTwistIsPreDivStable(twistWindowSeconds, hysteresisSeconds)
    local hyst = hysteresisSeconds or 0.05
    if hyst < 0 then hyst = 0 end

    local rawTimeToDiv = self:RetTwistRawTimeToDivBoundary(twistWindowSeconds)
    local prev = self._retTwistPreDivStable

    if prev == nil then
        prev = rawTimeToDiv > 0
        self._retTwistPreDivStable = prev
        return prev
    end

    if prev then
        -- Stay pre-div until we are clearly post-div by the hysteresis margin
        if rawTimeToDiv < -hyst then
            self._retTwistPreDivStable = false
        end
    else
        -- Stay post-div until we are clearly pre-div by the hysteresis margin
        if rawTimeToDiv > hyst then
            self._retTwistPreDivStable = true
        end
    end

    return self._retTwistPreDivStable
end

--- Stable (hysteresis) "are we before div?" helper, evaluated at action time (GCD end).
--- This is the correct basis for "wait for X before div" look-ahead, because those clauses
--- are meant to reason about where the player will be able to act next (not strictly 'right now').
--- @param twistWindowSeconds number|nil Default 0.4
--- @param hysteresisSeconds number|nil Default 0.05 (50ms)
--- @return boolean isPreDiv True if we're considered pre-div at action time (stable), false otherwise.
function NAG:RetTwistIsPreDivStableAtAction(twistWindowSeconds, hysteresisSeconds)
    local hyst = hysteresisSeconds or 0.05
    if hyst < 0 then hyst = 0 end

    local rawTimeToDiv = self:RetTwistRawTimeToDivBoundaryAtAction(twistWindowSeconds)
    local prev = self._retTwistPreDivAtActionStable

    if prev == nil then
        prev = rawTimeToDiv > 0
        self._retTwistPreDivAtActionStable = prev
        return prev
    end

    if prev then
        if rawTimeToDiv < -hyst then
            self._retTwistPreDivAtActionStable = false
        end
    else
        if rawTimeToDiv > hyst then
            self._retTwistPreDivAtActionStable = true
        end
    end

    return self._retTwistPreDivAtActionStable
end

--- Computes a stable, clamped tolerance for "wait for X before div" UX.
--- Returns 0 when we are not in the pre-div region at ACTION TIME (stable).
--- @param maxToleranceSeconds number|nil Hard cap for tolerance (e.g. 3)
--- @param twistWindowSeconds number|nil Default 0.4
--- @param hysteresisSeconds number|nil Default 0.05
--- @return number tolSeconds A tolerance to use in NAG:Cast(spell, tolSeconds)
function NAG:RetTwistWaitToleranceBeforeDiv(maxToleranceSeconds, twistWindowSeconds, hysteresisSeconds)
    local maxTol = maxToleranceSeconds or 0
    if maxTol < 0 then maxTol = 0 end

    if maxTol == 0 then
        return 0
    end

    if not self:RetTwistIsPreDivStableAtAction(twistWindowSeconds, hysteresisSeconds) then
        return 0
    end

    local rawTimeToDiv = self:RetTwistRawTimeToDivBoundaryAtAction(twistWindowSeconds)
    if not rawTimeToDiv or rawTimeToDiv <= 0 then
        return 0
    end

    return min(maxTol, rawTimeToDiv)
end

--- Returns true if we are planning a "Judge -> SoC" setup and Judgement will be ready before
--- the safe div boundary at action time (pre-div, with an extra safety margin).
--- This is used to prevent prematurely casting SoC when we intend to keep a SoB/SoM seal up
--- until Judgement becomes available.
--- @param maxToleranceSeconds number|nil Default 3
--- @param twistWindowSeconds number|nil Default 0.4
--- @param hysteresisSeconds number|nil Default 0.05
--- @param safetySeconds number|nil Default 0.2 (200ms extra safety before div)
--- @return boolean
function NAG:RetTwistJudgeSetupIsPlanned(maxToleranceSeconds, twistWindowSeconds, hysteresisSeconds, safetySeconds)
    local now = (_G.GetTime and _G.GetTime()) or 0
    local shouldPrint = false

    local window = twistWindowSeconds or 0.4
    local hyst = hysteresisSeconds or 0.05
    local maxTol = maxToleranceSeconds or 0
    if maxTol < 0 then maxTol = 0 end

    local gcdLeft = self:GCDTimeToReady() or 0
    if gcdLeft < 0 then gcdLeft = 0 end
    local gcdVal = self:GCDTimeValue() or 0
    if gcdVal < 0 then gcdVal = 0 end
    local swingAtAction = self:AutoTimeToNextAfterGCD() or 0
    if swingAtAction < 0 then swingAtAction = 0 end
    local rawDivAtActionNow = self:RetTwistRawTimeToDivBoundaryAtAction(window) or 0
    local swingSpeed = self:AutoSwingTime() or 0
    if swingSpeed < 0 then swingSpeed = 0 end
    local rawDivAtActionNext = (swingSpeed > 0) and (rawDivAtActionNow + swingSpeed) or rawDivAtActionNow
    -- If we're post-div in the CURRENT swing at action time, evaluate the wait window against the NEXT swing instead.
    -- This matches the APL intent: "wait for Judge if it will be ready within the safe gap of the next swing".
    local useNextSwing = rawDivAtActionNow <= 0
    local rawDivUsed = useNextSwing and rawDivAtActionNext or rawDivAtActionNow
    local preDivStable = rawDivUsed > hyst

    local soCActive = (self.RetTwistIsSoCActive and self:RetTwistIsSoCActive()) or false
    local soBActive = (self.RetTwistIsSoBActive and self:RetTwistIsSoBActive()) or false

    local tol = 0
    if preDivStable and rawDivUsed > 0 then
        tol = min(maxTol, rawDivUsed)
    end
    if not tol or tol <= 0 then
        return false
    end

    local safety = safetySeconds or 0.2
    if safety < 0 then safety = 0 end

    local safeTol = tol - safety
    if safeTol <= 0 then
        return false
    end

    local judgeReadyIn = self:SpellTimeToReady(20271) -- Judgement
    if not judgeReadyIn or judgeReadyIn < 0 then
        return false
    end

    -- If it's ready now, we don't consider this a "wait" plan; the APL can just cast it.
    if judgeReadyIn <= 0 then
        return false
    end

    local planned = judgeReadyIn <= safeTol
    return planned
end

--- Returns a tolerance to use for "WAIT for Judgement before div" UX.
--- If the return value is > 0, the APL should recommend Judgement with that tolerance (i.e., show the icon + swipe).
--- If the return value is 0, the APL should NOT wait; it should allow fillers to proceed.
--- Rules:
--- - Only wait if Judgement becomes ready before the safe div boundary at action time.
--- - If we can fit ONE full GCD (+ a buffer) before Judgement, AND still be safely pre-div, do not wait (allow a filler).
--- @param maxToleranceSeconds number|nil Default 3
--- @param twistWindowSeconds number|nil Default 0.4
--- @param hysteresisSeconds number|nil Default 0.05
--- @param safetySeconds number|nil Default 0.2
--- @param fillerBufferSeconds number|nil Default 0.3
--- @return number tolSeconds
function NAG:RetTwistJudgeSetupWaitTolerance(maxToleranceSeconds, twistWindowSeconds, hysteresisSeconds, safetySeconds, fillerBufferSeconds)
    local now = (_G.GetTime and _G.GetTime()) or 0
    local shouldPrint = false

    local window = twistWindowSeconds or 0.4
    local hyst = hysteresisSeconds or 0.05
    local maxTol = maxToleranceSeconds or 0
    if maxTol < 0 then maxTol = 0 end

    local gcdLeft = self:GCDTimeToReady() or 0
    if gcdLeft < 0 then gcdLeft = 0 end
    local gcdVal = self:GCDTimeValue() or 0
    if gcdVal < 0 then gcdVal = 0 end
    local swingAtAction = self:AutoTimeToNextAfterGCD() or 0
    if swingAtAction < 0 then swingAtAction = 0 end
    local rawDivAtActionNow = self:RetTwistRawTimeToDivBoundaryAtAction(window) or 0
    local swingSpeed = self:AutoSwingTime() or 0
    if swingSpeed < 0 then swingSpeed = 0 end
    local rawDivAtActionNext = (swingSpeed > 0) and (rawDivAtActionNow + swingSpeed) or rawDivAtActionNow
    local useNextSwing = rawDivAtActionNow <= 0
    local rawDivUsed = useNextSwing and rawDivAtActionNext or rawDivAtActionNow
    local preDivStable = rawDivUsed > hyst

    local soCActive = (self.RetTwistIsSoCActive and self:RetTwistIsSoCActive()) or false
    local soBActive = (self.RetTwistIsSoBActive and self:RetTwistIsSoBActive()) or false

    local tol = 0
    if preDivStable and rawDivUsed > 0 then
        tol = min(maxTol, rawDivUsed)
    end
    if not tol or tol <= 0 then
        return 0
    end

    local safety = safetySeconds or 0.2
    if safety < 0 then safety = 0 end

    local safeTol = tol - safety
    if safeTol <= 0 then
        return 0
    end

    local judgeReadyIn = self:SpellTimeToReady(20271) -- Judgement
    if not judgeReadyIn or judgeReadyIn < 0 then
        return 0
    end
    if judgeReadyIn <= 0 then
        -- Ready now; no need to "wait recommend" it.
        return 0
    end
    if judgeReadyIn > safeTol then
        -- Won't be ready before safe div; don't block fillers.
        return 0
    end

    -- Decide if we should allow ONE filler GCD before Judgement.
    local buffer = fillerBufferSeconds or 0.3
    if buffer < 0 then buffer = 0 end

    -- Decide if we should allow ONE filler GCD before the planned "Judge -> SoC" setup.
    --
    -- IMPORTANT (TBC Ret): Judgement is OFF-GCD, but SoC is ON-GCD.
    -- If we spend a filler GCD now, the earliest we can press SoC is after that filler GCD ends.
    -- We must also have Judgement available by then (or we can wait a bit for it), since we want:
    --   Judge (off-gcd) -> immediately SoC (on-gcd)
    --
    -- So the relevant timeline for safety is when SoC would be pressed:
    --   soCPressIn = max(gcdVal, judgeReadyIn) + buffer
    -- If that fits within safeTol, a filler can be squeezed in and we should NOT wait-block.
    local soCPressIn = max(gcdVal, judgeReadyIn) + buffer
    local canFitFiller = safeTol >= soCPressIn
    if canFitFiller then
        return 0
    end

    return safeTol
end

--- Returns true if we are in the WA-style "div hold region" at action time (GCD end):
--- windowSeconds < timeToSwingAtAction <= windowSeconds + gcdDurationValue
--- This is used to decide when we must HOLD to avoid spending a full GCD and missing the twist.
--- @param windowSeconds number|nil Default 0.4
--- @return boolean
function NAG:RetTwistIsInHoldRegion(windowSeconds)
    local window = windowSeconds or 0.4
    if window < 0 then window = 0 end

    if not (self.RetTwistIsSoCActive and self:RetTwistIsSoCActive()) then
        return false
    end

    local gcdVal = self:GCDTimeValue() or 0
    if gcdVal < 0 then gcdVal = 0 end

    -- First return from AutoTimeToNextAfterGCD is "timeToSwing at action time" (includes next-cycle projection).
    local timeToSwingAtAction = self:AutoTimeToNextAfterGCD()
    if not timeToSwingAtAction or timeToSwingAtAction <= 0 then
        return false
    end

    return (timeToSwingAtAction > window) and (timeToSwingAtAction <= (window + gcdVal))
end

--- Checks if we can execute a seal twist at GCD end (i.e., the next action time) inside the twist window.
--- This is analogous to `CanWeave`, but for **instant** seal swaps that must land within the
--- last `windowSeconds` before the next auto attack.
---
--- A twist is considered possible if, when the GCD ends:
--- - there is still time before the swing occurs, and
--- - we are within the twist window (time_to_swing <= windowSeconds), and
--- - our estimated press+latency delay fits inside that remaining time.
---
--- @function NAG:CanTwist
--- @param windowSeconds number|nil Twist window size in seconds (default: 0.4)
--- @param extraDelaySeconds number|nil Optional extra delay buffer (e.g., reaction time) to add (default: 0)
--- @return boolean True if we can twist within the upcoming swing window, false otherwise.
--- @usage NAG:CanTwist(0.4)
function NAG:CanTwist(windowSeconds, extraDelaySeconds)
    local window = windowSeconds or 0.4
    if window <= 0 then
        return false
    end

    local timeToSwingAfterGCD = self:AutoTimeToNextAfterGCD()
    if not timeToSwingAfterGCD or timeToSwingAfterGCD <= 0 then
        return false
    end

    if timeToSwingAfterGCD > window then
        return false
    end

    -- Seal twisting is an instant swap inside a very small window (~0.4s).
    -- For this TBC Ret implementation we intentionally IGNORE ping in all twist decisions.
    -- We model only:
    -- - fixed input delay of 0.1s (per project decision)
    -- - optional extraDelaySeconds (reaction/extra buffer)
    local baseInputDelay = 0.1

    local extra = extraDelaySeconds or 0
    if extra < 0 then
        extra = 0
    end

    -- If our estimated delay already exceeds the entire window, twisting is not realistically possible.
    local adjustedInputDelay = baseInputDelay + extra
    if adjustedInputDelay >= window then
        return false
    end

    return adjustedInputDelay <= timeToSwingAfterGCD
end

--- Debug helper for Ret seal twisting.
--- Prints the current swing timing state AND the projected state at GCD end:
--- - "preDiv": enough time for a full GCD before the twist window
--- - "postDiv": inside the sensitive region (a full GCD would push into/past twist window)
--- - "twist": inside the actual twist window (<= windowSeconds)
---
--- This function intentionally returns false so it can be inserted into an APL as:
--- `or (NAG:InCombat() and NAG:RetTwistDebugTick())`
--- without affecting the chosen action.
--- @return boolean Always returns false.
function NAG:RetTwistDebugTick()
    -- Debug prints disabled (was used for investigating HOLD<->CS flicker).
    -- Intentionally keep this function as a no-op so APLs that still reference it won't break.
    return false
end

--- Returns the predicted "hold until" time (seconds from now) for the next twist window to open.
--- This is a minimal, timing-only analogue of the WA's `predictionHold` concept:
--- we model the next twist opportunity as `max(0, rawTimeToSwing - windowSeconds)`.
--- @param windowSeconds number|nil Twist window size in seconds (default: 0.4)
--- @return number holdSeconds Seconds from now until the twist window opens (clamped >= 0).
--- @usage local hold = NAG:RetTwistTimeToTwistWindow(0.4)
function NAG:RetTwistTimeToTwistWindow(windowSeconds)
    local window = windowSeconds or 0.4
    -- Time-until-gap is a UI hint: "how long until the twist window opens?"
    -- If the current GCD would finish AFTER the next swing, count down to the NEXT swing cycle's window.
    local _, rawTimeToSwing = self:AutoTimeToNext()
    rawTimeToSwing = rawTimeToSwing or 0
    rawTimeToSwing = max(0, rawTimeToSwing)

    local gcdLeft = self:GCDTimeToReady() or 0
    if gcdLeft < 0 then gcdLeft = 0 end

    if rawTimeToSwing <= 0 then
        return 0
    end

    if gcdLeft > rawTimeToSwing then
        -- We won't be able to act before this swing; use the next swing cycle.
        local swingSpeed = self:AutoSwingTime() or 0
        if swingSpeed <= 0 then
            return 0
        end
        local holdIn = max(0, (rawTimeToSwing + swingSpeed) - window)
        return holdIn
    end

    -- We can act before the next swing; count down to the current cycle's twist window.
    return max(0, rawTimeToSwing - window)
end

-- ============================ STARTATTACK SPAM DETECTION ============================

--- Record a user "attack pressed" signal.
--- Intended to be called from a macro via `/nagattack`.
---
--- Behavior:
--- - Sets a short-lived flag for 0.30s (extended on repeated calls)
--- - Records press timestamps into a small ring buffer for rate/interval checks
---
--- Runtime-only: stored in `NAG.state` (no AceDB writes).
function NAG:AttackPressed()
    local now = GetTime()

    self.state = self.state or {}
    self.state.attackSpam = self.state.attackSpam or {}
    local st = self.state.attackSpam

    -- "Pressed recently" window (resets on every press)
    st.attackPressedUntil = now + 0.30

    -- Ring buffer of recent press times
    st.pressTimes = st.pressTimes or {}
    st.pressCount = st.pressCount or 0
    st.pressIndex = st.pressIndex or 0

    local maxSamples = 12
    st.pressIndex = (st.pressIndex % maxSamples) + 1
    st.pressTimes[st.pressIndex] = now
    if st.pressCount < maxSamples then
        st.pressCount = st.pressCount + 1
    end
end

--- Return current attack spam statistics.
--- @return table stats
function NAG:GetAttackSpamStats()
    local now = GetTime()

    self.state = self.state or {}
    local st = self.state.attackSpam
    if not st or not st.pressTimes or not st.pressCount or st.pressCount <= 0 then
        return {
            pressesLast1s = 0,
            lastPressAt = nil,
            lastPressAgo = nil,
            avgInterval = nil,
        }
    end

    local cutoff = now - 1.0
    local times = {}
    local lastPressAt = nil

    local maxSamples = 12
    local limit = min(st.pressCount, maxSamples)
    for i = 1, limit do
        local t = st.pressTimes[i]
        if t and t >= cutoff and t <= now then
            times[#times + 1] = t
            if not lastPressAt or t > lastPressAt then
                lastPressAt = t
            end
        end
    end

    local pressesLast1s = #times
    local lastPressAgo = lastPressAt and (now - lastPressAt) or nil

    local avgInterval = nil
    if pressesLast1s >= 2 then
        table.sort(times)
        local sum = 0
        local n = 0
        for i = 2, pressesLast1s do
            local dt = times[i] - times[i - 1]
            if dt > 0 and dt < 1.0 then
                sum = sum + dt
                n = n + 1
            end
        end
        if n > 0 then
            avgInterval = sum / n
        end
    end

    return {
        pressesLast1s = pressesLast1s,
        lastPressAt = lastPressAt,
        lastPressAgo = lastPressAgo,
        avgInterval = avgInterval,
    }
end

--- True if the user is currently spamming attack at or above the configured cadence.
--- Definition (per project request):
--- - >= 3 presses in the last 1.0s
--- - and last press was within the last 0.30s (so it's "currently" happening)
--- @return boolean
function NAG:IsSpammingAttack()
    local stats = self:GetAttackSpamStats()
    if not stats then
        return false
    end
    if (stats.pressesLast1s or 0) < 3 then
        return false
    end
    if not stats.lastPressAgo or stats.lastPressAgo > 0.30 then
        return false
    end
    return true
end

-- ============================ SHAMAN: SHOULD SPAM AUTO (TBC ENH) ============================

local function isTBCEnhancementShaman(self)
    if not (Version and Version.IsTBC and Version:IsTBC()) then
        return false
    end
    if (self.CLASS_FILENAME or "") ~= "SHAMAN" then
        return false
    end

    if not SpecCompat then
        -- AceAddon GetModule supports silent=true as 2nd arg.
        SpecCompat = self:GetModule("SpecCompat", true)
    end
    if not SpecCompat then
        -- If spec detection isn't available, don't hard-block.
        -- We only want to block if we can positively identify a non-Enhancement spec.
        return true
    end

    local specStatus = SpecCompat:GetSpecializationStatus()
    if not specStatus or not specStatus.available or not specStatus.specIndex then
        -- Spec not known yet (common briefly during login/updates). Don't hard-block.
        return true
    end

    return specStatus.specIndex == 2
end

--- Returns true if the user (TBC Enhancement Shaman only) should be spamming the AutoAttack macro
--- to enforce a usable MH/OH swing relationship.
---
--- Historically this helper only fired while we were desynced (not effectively synchronized).
--- Per updated expectations, it should also fire when we are "too perfectly synced" and need to
--- re-introduce some stagger (perfect syncs are not acceptable).
---
--- This is driven by the runtime state computed by `TBCEnhancementShamanWeaponSync`.
--- @return boolean
function NAG:ShamanShouldSpamAuto()
    if not isTBCEnhancementShaman(self) then
        return false
    end

    local mod = self:GetModule("TBCEnhancementShamanWeaponSync", true)
    if not mod then
        return false
    end
    if mod.IsEnabled and (not mod:IsEnabled()) then
        return false
    end

    local st = mod._debugState
    if not st then
        return false
    end

    -- Only meaningful when swing timers are stable (avoid idle ttn=0/p=1 state).
    if not st.lastHasStableSwingTimers then
        return false
    end

    local diff = st.lastSyncDifference

    -- If we're effectively synced, we generally don't want to spam...
    -- ...except when we're "too perfectly synced" and we want to re-stagger.
    if st.lastIsEffectivelySynchronized then
        -- Use the module's MH lead bias as a practical "too perfect" threshold: if the swings are
        -- closer than this, treat it as needing stagger.
        local perfectSyncMaxSeconds = 0.05
        if mod.db and mod.db.class and mod.db.class.mhLeadTimeSeconds ~= nil then
            perfectSyncMaxSeconds = mod.db.class.mhLeadTimeSeconds
        end
        if perfectSyncMaxSeconds < 0 then
            perfectSyncMaxSeconds = 0
        end

        if diff and diff >= 0 and diff <= perfectSyncMaxSeconds then
            return true
        end
        return false
    end

    -- Desired default stagger behavior:
    -- - MH should be slightly ahead (ties are not acceptable)
    -- - Accept MH-leading stagger up to 0.49s
    local leader = st.lastLeaderHand
    if diff and leader == "MH" then
        if diff <= 0.49 then
            return false
        end
    end

    return true
end

--- Implements the WA-style "CS delay analyzer" rule for seal twisting:
--- only force Crusader Strike if following the current twist plan (holding until the next twist window)
--- would delay CS beyond the configured maximum.
---
--- This is intentionally an additive support helper for APL authors; it does not change any
--- existing consolidated casting/rotation semantics.
---
--- @param csMaxDelaySeconds number|nil Default 1.7 (1700ms)
--- @param reactionSeconds number|nil Default 0.1 (100ms)
--- @param windowSeconds number|nil Default 0.4
--- @return boolean True if CS should be forced now (or held as primary) to avoid over-delaying it.
--- @usage if NAG:RetTwistShouldForceCrusaderStrike(1.7, 0.1, 0.4) then ...
function NAG:RetTwistShouldForceCrusaderStrike(csMaxDelaySeconds, reactionSeconds, windowSeconds)
    local GetTime = _G.GetTime
    local now = GetTime and GetTime() or 0

    -- Debug snapshot fields (written on all exits so RetTwistDebugTick can print the exact math inputs/outputs)
    self._retTwistForceCs_dbgReason = nil
    self._retTwistForceCs_dbgActIn = nil
    self._retTwistForceCs_dbgCsUsableIn = nil
    self._retTwistForceCs_dbgCsReadyIn = nil
    self._retTwistForceCs_dbgCsMaxDelay = nil
    self._retTwistForceCs_dbgUsableFor = nil

    local window = windowSeconds or 0.4
    local reaction = reactionSeconds or 0
    if reaction < 0 then reaction = 0 end

    local csMaxDelay = csMaxDelaySeconds or 1.7
    if csMaxDelay < 0 then csMaxDelay = 0 end
    self._retTwistForceCs_dbgCsMaxDelay = csMaxDelay

    -- SpellTimeToReady can occasionally return -1 (missing cooldown info) for a single tick.
    -- That causes visible flicker in "force CS" decisions. Use a short cache of the last good
    -- value to make the behavior stable.
    local csReadyIn = self:SpellTimeToReady(35395)
    if csReadyIn and csReadyIn >= 0 then
        self._retTwistCsReadyInCache = csReadyIn
        self._retTwistCsReadyInCacheTime = now
    else
        local cached = self._retTwistCsReadyInCache
        local cachedAt = self._retTwistCsReadyInCacheTime or 0
        if cached ~= nil and (now - cachedAt) <= 0.50 then
            csReadyIn = cached
        else
            self._retTwistForceCs_dbgReason = "no_cs_cdinfo"
            return false
        end
    end
    self._retTwistForceCs_dbgCsReadyIn = csReadyIn

    -- ============================ CORE DELAY MATH ONLY (NO PREDICTIVE ENFORCEMENT) ============================
    -- Desired behavior:
    --   "CS cannot be pushed over csMaxDelay *after it becomes ACTUALLY usable*."
    -- That means we only start counting once BOTH are true:
    --   - CS cooldown is ready
    --   - GCD is ready
    -- and we do NOT use any predictive 'holdIn' / 'csWhen' inequality that can flip mid-GCD.
    local actIn = self:GCDTimeToReady() or 0
    if actIn < 0 then actIn = 0 end
    self._retTwistForceCs_dbgActIn = actIn

    local csUsableIn = max(0, csReadyIn)
    if csUsableIn < actIn then
        csUsableIn = actIn
    end
    self._retTwistForceCs_dbgCsUsableIn = csUsableIn

    if csUsableIn <= 0 then
        if not self._retTwistCsReadySince then
            self._retTwistCsReadySince = now
        end
    else
        self._retTwistCsReadySince = nil
    end

    if self._retTwistCsReadySince then
        local usableFor = now - self._retTwistCsReadySince
        self._retTwistForceCs_dbgUsableFor = usableFor
        if usableFor >= csMaxDelay then
            self._retTwistForceCs_dbgReason = "delay_enforce"
            return true
        end
        self._retTwistForceCs_dbgReason = "delay_wait"
        return false
    end

    self._retTwistForceCs_dbgReason = "not_usable_yet"
    self._retTwistForceCs_dbgUsableFor = 0
    return false
end

--- Debug helper to understand why the CS override is (or isn't) active in the Ret twist APL.
--- @param csMaxDelaySeconds number|nil
--- @param reactionSeconds number|nil
--- @param windowSeconds number|nil
--- @return boolean Always returns false so it can be used as `NAG:RetTwistCSDebugTick(...) or ...` in an APL.
function NAG:RetTwistCSDebugTick(csMaxDelaySeconds, reactionSeconds, windowSeconds)
    -- Debug prints disabled (was used for investigating HOLD<->CS flicker).
    -- Intentionally keep this function as a no-op so APLs that still reference it won't break.
    return false
end

--- Returns the predicted "hold until" time (seconds from now) for the next twist window to open
--- using the raw (non-GCD-adjusted) time-to-next-swing.
--- @param windowSeconds number|nil Twist window size in seconds (default: 0.4)
--- @return number holdSeconds Seconds from now until the twist window opens (clamped >= 0).
function NAG:RetTwistTimeToTwistWindowNow(windowSeconds)
    local window = windowSeconds or 0.4
    local _, rawNow = self:AutoTimeToNext()
    if not rawNow then
        return 0
    end
    return max(0, rawNow - window)
end

--- Returns true if it is safe (timing-wise) to spend a GCD on `spellId` and still reach the next twist window.
--- This is an APL support helper for fillers; it is intentionally conservative.
--- @param spellId number
--- @param windowSeconds number|nil Default: 0.4
--- @param reactionSeconds number|nil Default: 0.1
--- @return boolean
function NAG:RetTwistCanCastFillerBeforeTwist(spellId, windowSeconds, reactionSeconds)
    if not spellId then
        return false
    end

    local window = windowSeconds or 0.4
    local reaction = reactionSeconds or 0.1
    if reaction < 0 then reaction = 0 end

    -- Must be usable for current target/context (prevents Exorcism on invalid targets, etc.)
    if IsUsableSpell and not IsUsableSpell(spellId) then
        return false
    end

    -- If spell will not be ready by the time the GCD ends, don't suggest it as a filler.
    local gcd = self:GCDTimeToReady() or 0
    local ttr = self:SpellTimeToReady(spellId)
    if ttr and ttr > 0 and ttr > gcd then
        return false
    end

    -- Ensure there is enough time before the twist window opens to spend a GCD on the filler.
    local timeToWindow = self:RetTwistTimeToTwistWindowNow(window)
    local fillerGcd = self:SpellGCDHastedDuration(spellId) or 1.5
    if fillerGcd < 0 then fillerGcd = 0 end

    -- Small fixed buffer (matches WA-style conservatism, avoids cutting it too close)
    local safety = 0.05
    if (fillerGcd + reaction + safety) > timeToWindow then
        return false
    end

    -- Also avoid swing clipping for non-instant casts.
    return self:CanWeave(spellId)
end

-- ============================ WARRIOR: SLAM WEAVING HELPERS (TBC ARMS 2H) ============================
-- These helpers intentionally mirror the Ret twist design:
-- - Evaluate timing at ACTION TIME (GCD end) where relevant
-- - Provide a stable HOLD-region decision (hysteresis) to avoid 1-tick flicker
-- - Use a runtime module for last swing impact timing (for the post-swing Slam window)

local function getWarriorSlamWeaveModule(self)
    if not self or not self.GetModule then
        return nil
    end
    local mod = self:GetModule("WarriorSlamWeaveModule", true)
    if not mod then
        return nil
    end
    if mod.IsEnabled and (not mod:IsEnabled()) then
        return nil
    end
    if mod.db and mod.db.class and mod.db.class.enabled == false then
        return nil
    end
    return mod
end

local function getWarriorSlamWeaveConfig(self)
    local mod = getWarriorSlamWeaveModule(self)
    local defaults = {
        slamWindowSeconds = 0.25,
        slamLatencySeconds = 0.10,
        slamGcdDelaySeconds = 0.40,
        slamMsWwDelaySeconds = 2.00,
        holdReactionSeconds = 0.10,
    }

    if not mod or not mod.db or not mod.db.class then
        return defaults
    end

    local db = mod.db.class
    return {
        slamWindowSeconds = db.slamWindowSeconds or defaults.slamWindowSeconds,
        slamLatencySeconds = db.slamLatencySeconds or defaults.slamLatencySeconds,
        slamGcdDelaySeconds = db.slamGcdDelaySeconds or defaults.slamGcdDelaySeconds,
        slamMsWwDelaySeconds = db.slamMsWwDelaySeconds or defaults.slamMsWwDelaySeconds,
        holdReactionSeconds = db.holdReactionSeconds or defaults.holdReactionSeconds,
    }
end

--- Returns the last observed player melee swing impact time (seconds, GetTime()).
--- @return number
function NAG:WarriorSlamWeaveLastSwingTime()
    local mod = getWarriorSlamWeaveModule(self)
    if not mod then
        return 0
    end
    mod:InitializeState()
    return (mod.state and mod.state.lastSwingTime) or 0
end

--- Returns seconds since last swing impact. Returns math.huge if unknown.
--- @return number
function NAG:WarriorSlamWeaveTimeSinceLastSwing()
    local last = self:WarriorSlamWeaveLastSwingTime() or 0
    if last <= 0 then
        return math.huge
    end
    local now = GetTime and GetTime() or 0
    local dt = now - last
    if dt < 0 then dt = 0 end
    return dt
end

--- Returns true if we are inside the post-swing \"Slam now\" window.
--- This is a *player UX* helper: it answers \"did a swing just land recently?\".
--- @param nowWindowSeconds number|nil Default 0.25
--- @return boolean
function NAG:WarriorSlamWeaveIsInSlamNowWindow(nowWindowSeconds)
    local window = nowWindowSeconds or 0.25
    if window < 0 then window = 0 end
    local dt = self:WarriorSlamWeaveTimeSinceLastSwing()
    if not dt or dt == math.huge then
        return false
    end
    return dt <= window
end

--- Returns true if we should queue Slam NOW based on sim-style timing gates.
--- Respects slam window, GCD delay gate, and MS/WW delay budget.
--- @param msSpellId number|nil Mortal Strike ID
--- @param wwSpellId number|nil Whirlwind ID
--- @return boolean
function NAG:WarriorSlamWeaveShouldSlamNow(msSpellId, wwSpellId)
    local config = getWarriorSlamWeaveConfig(self)
    local window = config.slamWindowSeconds or 0.25
    if window < 0 then window = 0 end

    local dt = self:WarriorSlamWeaveTimeSinceLastSwing()
    if not dt or dt == math.huge or dt > window then
        return false
    end

    local slamLatency = config.slamLatencySeconds or 0.10
    if slamLatency < 0 then slamLatency = 0 end
    local slamGcdDelay = config.slamGcdDelaySeconds or 0.40
    if slamGcdDelay < 0 then slamGcdDelay = 0 end

    local gcdLeft = self:GCDTimeToReady() or 0
    if gcdLeft < 0 then gcdLeft = 0 end
    if gcdLeft > slamLatency and (gcdLeft - slamLatency) > slamGcdDelay then
        return false
    end

    local slamAt = slamLatency
    if gcdLeft > slamLatency then
        slamAt = gcdLeft
    end

    local slamGcd = self:GCDTimeValue() or 1.5
    if slamGcd < 0 then slamGcd = 0 end
    local gcdReadyAgainAt = slamAt + slamGcd

    local msDelay = 0
    if msSpellId and self:SpellIsKnown(msSpellId) then
        local ttr = self:SpellTimeToReady(msSpellId) or 0
        if ttr < 0 then ttr = 0 end
        msDelay = math.max(0, gcdReadyAgainAt - ttr)
    end

    local wwDelay = 0
    if wwSpellId and self:SpellIsKnown(wwSpellId) then
        local ttr = self:SpellTimeToReady(wwSpellId) or 0
        if ttr < 0 then ttr = 0 end
        wwDelay = math.max(0, gcdReadyAgainAt - ttr)
    end

    local delayBudget = config.slamMsWwDelaySeconds or 2.00
    if delayBudget > 0 and (msDelay + wwDelay) > delayBudget then
        return false
    end

    return true
end

--- Returns raw time-to-hold boundary at ACTION TIME (GCD end):
--- positive => safe to spend another full GCD and still be free at the next swing
--- <= 0 => starting a full GCD would overlap the next swing (should HOLD)
--- @param reactionSeconds number|nil Default 0.10
--- @return number
function NAG:WarriorSlamWeaveRawTimeToHoldBoundary(reactionSeconds)
    local reaction = reactionSeconds or 0.10
    if reaction < 0 then reaction = 0 end

    local gcdVal = self:GCDTimeValue() or 0
    if gcdVal < 0 then gcdVal = 0 end

    -- Time to next swing evaluated at ACTION TIME (GCD end).
    local timeToSwingAtAction = self:AutoTimeToNextAfterGCD() or 0
    if timeToSwingAtAction < 0 then timeToSwingAtAction = 0 end

    return timeToSwingAtAction - (gcdVal + reaction)
end

--- Stable (hysteresis) HOLD region helper to avoid flicker at the boundary.
--- @param reactionSeconds number|nil Default 0.10
--- @param hysteresisSeconds number|nil Default 0.05
--- @return boolean
function NAG:WarriorSlamWeaveIsInHoldRegion(reactionSeconds, hysteresisSeconds)
    local hyst = hysteresisSeconds or 0.05
    if hyst < 0 then hyst = 0 end

    local raw = self:WarriorSlamWeaveRawTimeToHoldBoundary(reactionSeconds)
    local prev = self._warriorSlamWeaveHoldStable

    if prev == nil then
        prev = raw <= 0
        self._warriorSlamWeaveHoldStable = prev
        return prev
    end

    if prev then
        -- Stay in HOLD until we are clearly safe by hysteresis margin
        if raw > hyst then
            self._warriorSlamWeaveHoldStable = false
        end
    else
        -- Stay out of HOLD until we are clearly unsafe by hysteresis margin
        if raw < -hyst then
            self._warriorSlamWeaveHoldStable = true
        end
    end

    return self._warriorSlamWeaveHoldStable
end

--- Returns true if it is safe (timing-wise) to spend a GCD on `spellId` and still be free at the next swing.
--- Intended for mid-cycle fillers like Mortal Strike / Whirlwind in a Slam-weaving rotation.
--- @param spellId number
--- @param reactionSeconds number|nil Default 0.10
--- @return boolean
function NAG:WarriorSlamWeaveCanCastFillerBeforeHold(spellId, reactionSeconds)
    if not spellId then
        return false
    end

    local reaction = reactionSeconds or 0.10
    if reaction < 0 then reaction = 0 end

    -- Must be usable for current target/context.
    if IsUsableSpell and not IsUsableSpell(spellId) then
        return false
    end

    -- If spell won't be ready by action time, don't suggest it as filler.
    local gcdLeft = self:GCDTimeToReady() or 0
    if gcdLeft < 0 then gcdLeft = 0 end
    local ttr = self:SpellTimeToReady(spellId)
    if ttr and ttr > 0 and ttr > gcdLeft then
        return false
    end

    -- Project time-to-swing at ACTION TIME (GCD end).
    local timeToSwingAtAction = self:AutoTimeToNextAfterGCD() or 0
    if timeToSwingAtAction <= 0 then
        return false
    end

    local fillerGcd = self:SpellGCDHastedDuration(spellId) or (self:GCDTimeValue() or 1.5)
    if fillerGcd < 0 then fillerGcd = 0 end

    -- Small fixed buffer (avoid cutting it too close)
    local safety = 0.05
    if (fillerGcd + reaction + safety) > timeToSwingAtAction then
        return false
    end

    -- Also avoid swing clipping for non-instant casts.
    return self:CanWeave(spellId)
end

--- Estimates the time until the next opportunity to weave a spell.
--- Returns 0 for instant casts, math.huge if weaving is impossible, or the time until the next gap.
--- @function NAG:TimeToNextWeaveGap
--- @param spellId number The spell ID to check.
--- @return number The estimated time in seconds until the next weave gap, or math.huge if weaving is impossible.
--- @usage NAG:TimeToNextWeaveGap(12345)
--- @local This function is used to estimate the time until the next opportunity to weave a spell.
function NAG:TimeToNextWeaveGap(spellId)
    local castTime = getMaelstromAdjustedCastTime(self, spellId, self:SpellCastTime(spellId))

    -- For instant cast spells, return 0 since they can always be weaved
    if castTime == 0 then
        return 0
    end


    -- Check if we're currently casting or channeling
    local name = UnitCastingInfo("player")
    if name or StateManager.state.casting then
        return math.huge
    end

    -- Apply Maelstrom Weapon logic for input delay with latency awareness and fixed buffer
    local userPing = self:GetNetStats()               -- Use cached network stats
    local baseInputDelay = self:InputDelay() or 0.050 -- fallback to 50ms
    local staticPressBuffer = 0.200                   -- 200ms flat buffer for press-to-cast
    local maelstromStacks = self:AuraNumStacks(51530) -- Maelstrom Weapon spell ID

    -- Final delay: input + ping + 200ms fixed buffer
    local adjustedInputDelay = baseInputDelay + userPing + staticPressBuffer
    if maelstromStacks >= 5 then
        adjustedInputDelay = 0                                  -- instant cast, ignore delay
    else
        adjustedInputDelay = math.min(adjustedInputDelay, 0.45) -- cap at 0.45s
    end

    local totalCastTime = adjustedInputDelay + castTime
    local weaponSpeed = self:AutoSwingTime(Types.SwingType.MainHand)
    local currentSwingTime = self:AutoTimeToNext()

    -- If total cast time is greater than weapon speed, weaving is impossible
    if totalCastTime >= weaponSpeed then
        return math.huge
    end

    -- If we can't weave now but it's theoretically possible (totalCastTime < weaponSpeed)
    if totalCastTime >= currentSwingTime then
        -- Return the actual remaining time before the next auto-attack
        return currentSwingTime + NAG:GCDTimeToReady()
    end

    -- If we can weave now, return 0
    return 0
end

--- Calculates the difference between mainhand and offhand swing times.
--- Returns the phase difference in seconds, or 0 if unavailable.
--- @function NAG:SwingTimeDifference
--- @return number The difference in swing times.
--- @usage local diff = NAG:SwingTimeDifference()
function NAG:SwingTimeDifference()
    if not swingTimerLib then return 0 end

    -- Initialize swing timer tracking with custom handler for mainhand swing tracking
    initializeSwingTimer(function(event, ...)
        if event == "UNIT_SWING_TIMER_DELTA" then
            local _, swingDelta = ...
            NAG.lastSwingDelta = abs(swingDelta) -- Ensure positive value
        elseif event == "UNIT_SWING_TIMER_START" then
            local _, hand = ...
            if hand == "mainhand" then
                NAG.lastMainHandSwing = GetTime()
            end
        end
    end)

    local mhSpeed, mhExpiration, mhLastSwing = swingTimerLib:UnitSwingTimerInfo("player", "mainhand")
    local ohSpeed, ohExpiration, ohLastSwing = swingTimerLib:UnitSwingTimerInfo("player", "offhand")

    if not mhSpeed or not ohSpeed then
        --self:Debug("SwingTimeDifference: Missing weapon speeds")
        return 0
    end

    -- Calculate current swing positions
    local currentTime = GetTime()
    local mhPosition = mhExpiration and (mhExpiration - currentTime) or 0
    local ohPosition = ohExpiration and (ohExpiration - currentTime) or 0

    -- Calculate the phase difference between the swings
    local difference = abs(mhPosition - ohPosition)

    -- If the difference is more than half the swing time, adjust it
    local minSwingTime = min(mhSpeed, ohSpeed)
    if difference > (minSwingTime / 2) then
        difference = minSwingTime - difference
    end

    -- Use cached delta if available
    if self.lastSwingDelta then
        difference = self.lastSwingDelta
    end

    return difference
end
