--- @module "Common"
--- Handles common functionality for the NAG addon.
--- License: CC BY-NC 4.0 (https://creativecommons.org/licenses/by-nc/4.0/legalcode)
--- Authors: @Rakizi: farendil2020@gmail.com, @Fonsas
--- Discord: https://discord.gg/ebonhold

-- ~~~~~~~~~~ LOCALIZE ~~~~~~~~~~
local _, ns = ...
local UnitCastingInfo = _G.UnitCastingInfo
local GetSpellTexture = C_Spell and C_Spell.GetSpellTexture or _G.GetSpellTexture
local GetItemIcon = C_Item and C_Item.GetItemIconByID or _G.GetItemIcon

local EMPTY_TABLE = {}

-- Reusable icon data table pool (10 should be enough for most rotations)
local ICON_DATA_POOL = {}
for i = 1, 12 do
    ICON_DATA_POOL[i] = { texture = nil, spellId = nil, itemId = nil }
end
local iconDataPoolIndex = 0

-- Helper to get next icon data from pool with overflow protection
local function getNextIconData()
    iconDataPoolIndex = iconDataPoolIndex + 1
    if iconDataPoolIndex > #ICON_DATA_POOL then
        -- Create additional objects if needed instead of wrapping
        local newObj = { texture = nil, spellId = nil, itemId = nil }
        table.insert(ICON_DATA_POOL, newObj)
        iconDataPoolIndex = #ICON_DATA_POOL
    end
    local iconData = ICON_DATA_POOL[iconDataPoolIndex]
    iconData.texture = nil
    iconData.spellId = nil
    iconData.itemId = nil
    return iconData
end

--- @type NAG|AceAddon
local NAG = LibStub("AceAddon-3.0"):GetAddon("NAG")
local WoWAPI = ns.WoWAPI
local Version = ns.Version

-- ============================ GCD PROBE (VERSION-AWARE) ============================
-- We use a "probe spell" to query the global cooldown via GetSpellCooldown().
-- Different clients expose different probe spell IDs reliably.
-- - Retail / Cata / Mists: 61304 (global cooldown spell)
-- - Vanilla / SoD / TBC / Wrath: 29515 (TEST Scorch, used as probe in this project)
local function getGcdProbeSpellId()
    if Version:IsRetail() or Version:IsCata() or Version:IsMists() then
        return 61304
    end
    return 29515
end

-- AST system for visitor pattern execution
-- NOTE: ASTVisitor is accessed via ns.ASTVisitor at runtime to avoid initialization order issues

local AceConfigDialog = ns.AceConfigDialog

-- Lua APIs (using WoW's optimized versions where available)
local GetTime = _G.GetTime
local GetGlyphSocketInfo = _G.GetGlyphSocketInfo
local format = string.format
local max = math.max


local strfind = strfind
local wipe = wipe


-- Enhanced error handling
local pcall = ns.pcall
local xpcall = xpcall
local ExtractErrorMessage = ns.ExtractErrorMessage

-- Rotation error handling context (avoids per-call closure allocation)
local rotationErrorContext = {}

-- Rotation execution guard flag (prevents concurrent execution)
local isRotationExecuting = false

local function touchUIElementsGate()
    if not NAG.CallUIElements then
        return
    end
    NAG:CallUIElements()
end

-- Helper to classify and handle rotation errors consistently
local function HandleRotationError(self, useVisitorPattern, err)
    -- Use ExtractErrorMessage to properly handle both string and enhanced error table formats
    local errorMsg = ExtractErrorMessage(err)

    -- Use DevTools_Dump to inspect the error table if available
    if type(err) == "table" and DevTools_Dump then
        self:Error("Error executing rotation: Table error detected. Dumping error table:")
        DevTools_Dump(err, "error")
    end

    -- Always log the error - this is critical for debugging silent failures
    self:Error(format("Error executing rotation: %s (useVisitorPattern=%s, hasAST=%s, hasFunc=%s)",
        errorMsg, tostring(useVisitorPattern), tostring(self.cachedRotationAST ~= nil), tostring(self.cachedRotationFunc ~= nil)))

    -- Log enhanced error details if available (for debugging)
    if type(err) == "table" and err.stack then
        self:Debug("Rotation error stack trace:\n%s", err.stack)
    end

    local isDisplayError = errorMsg and (
        strfind(errorMsg, "DisplayManager") or
        strfind(errorMsg, "UpdateIcons") or
        strfind(errorMsg, "UpdateGroupIcons") or
        strfind(errorMsg, "UpdateSequenceGroupIcons") or
        strfind(errorMsg, "SetTexture") or
        strfind(errorMsg, "Show()") or
        strfind(errorMsg, "Hide()") or
        strfind(errorMsg, "ShowOverlay") or
        strfind(errorMsg, "UpdateBorder")
    )

    if isDisplayError then
        self:Warn("Display error detected, preserving rotation cache")
        return true
    end

    -- Clear cache based on execution pattern
    if useVisitorPattern then
        self:Warn("Clearing cached rotation AST due to error in ExecuteRotationBody - rotation will attempt to reload on next execution")
        self.cachedRotationAST = nil
    else
        self:Warn("Clearing cached rotation function due to error in ExecuteRotationBody - rotation will attempt to reload on next execution")
        self.cachedRotationFunc = nil
    end
    return false
end

-- Core rotation execution without per-call closure allocation
local function ExecuteRotationBody(self, useVisitorPattern)
    local rotationExecuted = false

    if useVisitorPattern then
        if self.cachedRotationAST then
            local updateSuccess = self:Update(self.cachedRotationAST)
            if updateSuccess then
                rotationExecuted = true
            end
        else
            self:Error("Rotation: Visitor pattern enabled but no cached AST available - rotation will not execute")
        end
    elseif self.cachedRotationFunc then
        local updateSuccess = self:Update(self.cachedRotationFunc)
        if updateSuccess then
            rotationExecuted = true
        end
    else
        self:Error("Rotation: No cached rotation available - rotation will not execute")
    end

    return rotationExecuted
end

local function RotationErrorHandler(err)
    -- Use captured context to preserve logging and cache semantics
    return HandleRotationError(rotationErrorContext.self, rotationErrorContext.useVisitorPattern, err)
end

--File

-- ======= GLOBALIZE =======

-- ~~~~~~~~~~ CONTENT ~~~~~~~~~~

-- ============================ PRE-PULL/ROTATION/THROTTLER FUNCTIONS ============================

do
    --- Generic Rotation Function that handles the rotation logic.
    --- @param self NAG The NAG addon object
    --- @return boolean success Returns false if rotation setup fails
    --- @usage NAG:Rotation() -- Handles the main rotation logic and spell suggestions
    function NAG:Rotation()
        -- Prevent concurrent execution - if a previous rotation is still running, skip this call
        if isRotationExecuting then
            return false
        end

        -- Set execution guard flag
        isRotationExecuting = true

        if self.isLoadScreenRecent then
            isRotationExecuting = false
            return false
        end
        if self:IsAnyEditMode() then
            isRotationExecuting = false
            return false
        end
        if not self.hasEnabledModule then
            isRotationExecuting = false
            return false
        end
        -- Check schema availability to determine which cache to check
        local APLExecutor = NAG:GetModule("APLExecutor", true)
        local useVisitorPattern = APLExecutor and APLExecutor:ShouldUseVisitorPattern()

        -- Only get/initialize rotation if we don't have cached data
        local hasCachedRotation = (useVisitorPattern and self.cachedRotationAST) or
                                  (not useVisitorPattern and self.cachedRotationFunc)
        if not hasCachedRotation then
            local rotationManager = NAG:GetModule("RotationManager")
            if not rotationManager then
                self:Error("Rotation: RotationManager module not available - rotation will not execute and display may become stuck")
                isRotationExecuting = false
                return false
            end

            -- Suppress noisy warnings when spec/data not ready (e.g., fresh low-level toon, no spec)
            local SpecCompat = NAG:GetModule("SpecCompat", true)
            local specIndex = SpecCompat and SpecCompat:GetCurrentSpecIndex()
            local EventManager = ns.EventManager
            local DataManager = NAG:GetModule("DataManager", true)
            local startupIncomplete = EventManager and EventManager.currentPhase and EventManager.currentPhase < ns.StartupPhase.COMPLETE
            local dataNotReady = DataManager and (not DataManager:IsDataReady())

            if not specIndex or startupIncomplete or dataNotReady then
                isRotationExecuting = false
                return false
            end

            -- CRITICAL: EnsureRotationReady may error (e.g., during combat/encounter transitions)
            -- Always guard it so we never leave isRotationExecuting stuck true, which would freeze rotations until /reload.
            local okEnsure, ensureResultOrErr = pcall(function()
                return rotationManager:EnsureRotationReady()
            end)
            if not okEnsure then
                -- Only surface during combat and only if we had a valid rotation at combat start
                if UnitAffectingCombat("player") and rotationManager.hadValidRotationAtCombatStart then
                    self:Error("Rotation: EnsureRotationReady threw an error - rotation will not execute and display may become stuck: %s",
                        tostring(ensureResultOrErr))
                end
                isRotationExecuting = false
                return false
            end
            if not ensureResultOrErr then
                local now = GetTime()
                self._lastEnsureWarn = self._lastEnsureWarn or 0
                if UnitAffectingCombat("player") and rotationManager.hadValidRotationAtCombatStart and (now - self._lastEnsureWarn) > 10 then
                    self._lastEnsureWarn = now
                    self:Error("Rotation: EnsureRotationReady failed - rotation will not execute and display may become stuck")
                end
                isRotationExecuting = false
                return false
            end
        end

        -- NOTE: Automatic rotation switching now handled via event-driven messages
        -- See ClassBase message handlers: OnMobCountChanged, OnCombatStateChanged,
        -- OnGroupRosterUpdated, and OnEquipmentChanged

        -- TRACK ROTATION EXECUTION TIME for smart throttling
        local currentTime = GetTime()
        self.lastRotationTime = currentTime

        -- Execute rotation with centralized error handler (no per-call closures)
        rotationErrorContext.self = self
        rotationErrorContext.useVisitorPattern = useVisitorPattern
        local success, result = xpcall(ExecuteRotationBody, RotationErrorHandler, self, useVisitorPattern)
        rotationErrorContext.self = nil
        rotationErrorContext.useVisitorPattern = nil

        -- Always clear execution guard flag before returning
        isRotationExecuting = false

        if not success then
            -- RotationErrorHandler already logged and returned appropriate status
            return result
        end

        local rotationExecuted = result

        -- Return false if no rotation was actually executed
        if not rotationExecuted then
            -- CRITICAL: Rotation execution returned false - could be early return (expected) or execution failure (problem)
            -- This happens when Update() returns false despite having cached rotation (options dialog, load screen, shouldReturn check, etc.)
            -- If this persists, it could indicate rotation is stuck
            return false
        end

        return true
    end

    --- Updates the rotation logic based on the current time and input delay.
    --- Routes to appropriate execution path based on schema availability
    --- @param self NAG The NAG addon object
    --- @param rotation function|table The rotation function (legacy) or AST (visitor pattern)
    --- @return boolean|nil Returns true if rotation executed successfully, false/nil if early return
    function NAG:Update(rotation)
        -- Determine execution mode
        local APLExecutor = NAG:GetModule("APLExecutor", true)
        local useVisitorPattern = APLExecutor and APLExecutor:ShouldUseVisitorPattern()

        if useVisitorPattern then
            -- Schema-aware visitor pattern execution
            -- Use passed rotation parameter if it's a table (AST), otherwise fall back to cached
            local rotationAST = (rotation and type(rotation) == "table") and rotation or self.cachedRotationAST
            if rotationAST then
                return self:UpdateWithVisitor(rotationAST)
            end
        end

        -- Legacy function-based execution
        if rotation and type(rotation) == "function" then
            return self:UpdateWithFunction(rotation)
        end

        self:Error("Update: No valid rotation available - display may become stuck (useVisitorPattern=%s, hasAST=%s, hasFunc=%s)",
            tostring(useVisitorPattern), tostring(self.cachedRotationAST ~= nil), tostring(type(rotation) == "function"))
        return false
    end

    --- Updates rotation using visitor pattern execution (schema-aware)
    --- TODO: This is not functional yet
    --- @param self NAG The NAG addon object
    --- @param rotationAST table The proto AST rotation node
    --- @return boolean Returns true if rotation executed successfully, false if early return
    function NAG:UpdateWithVisitor(rotationAST)
        self:Debug("[UpdateWithVisitor] Starting execution")
        if not rotationAST or type(rotationAST) ~= "table" then
            self:Error("UpdateWithVisitor: Invalid rotation AST - expected table, got %s - display may become stuck", type(rotationAST))
            self.cachedRotationAST = nil
            return false
        end

        -- Ensure proto AST has type field for ASTVisitor.Walk
        -- Proto AST from RotationConversionService should have priority_list/groups structure
        -- but might not have explicit type field - ASTVisitor.Walk needs it to route correctly
        -- NOTE: We set the type on the AST directly since it's cached and will be reused
        -- This is safe because the type field is only used for routing, not data integrity
        if not rotationAST.type then
            -- Proto AST rotations have priority_list or groups, so set type to ROTATION
            if rotationAST.priority_list or rotationAST.groups then
                local ASTCore = ns.ASTCore
                if ASTCore and ASTCore.NodeType then
                    rotationAST.type = ASTCore.NodeType.ROTATION
                else
                    rotationAST.type = "rotation"
                end
                -- Mark that we've set the type to avoid redundant checks
                rotationAST._typeSetByNAG = true
            else
                self:Error("UpdateWithVisitor: Proto AST missing type field and no priority_list/groups found - display may become stuck")
                self.cachedRotationAST = nil
                return false
            end
        end

        -- Pause updates if options are open
        if AceConfigDialog and AceConfigDialog.OpenFrames and AceConfigDialog.OpenFrames["NAG"] then
            self:Debug("[UpdateWithVisitor] Early return: Options dialog is open")
            return false
        end
        if self.isLoadScreenRecent then
            self:Debug("[UpdateWithVisitor] Early return: Load screen is recent")
            return false
        end

        local chk = ns.check()
        local DisplayManager = NAG:GetModule("DisplayManager")
        local shouldShowDisplayResult = DisplayManager:ShouldShowDisplay()
        local shouldReturn = not chk or not shouldShowDisplayResult

        self:Debug("[UpdateWithVisitor] chk=%s, ShouldShowDisplay=%s, shouldReturn=%s",
            tostring(chk), tostring(shouldShowDisplayResult), tostring(shouldReturn))

        if shouldReturn then
            self:Debug("[UpdateWithVisitor] Early return: chk=%s, ShouldShowDisplay=%s", tostring(chk), tostring(shouldShowDisplayResult))

            local showGroup = DisplayManager.IsGroupDisplayMode and DisplayManager:IsGroupDisplayMode()
            local showLegacy = DisplayManager.IsLegacyFrameEnabled and DisplayManager:IsLegacyFrameEnabled()
            if showGroup then
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.MAIN, EMPTY_TABLE)
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.AOE, EMPTY_TABLE)
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.COOLDOWNS, EMPTY_TABLE)
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.INTERRUPTS, EMPTY_TABLE)
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.DEFENSIVES, EMPTY_TABLE)
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.SEQUENCE, EMPTY_TABLE)
            end
            if showLegacy then
                DisplayManager:UpdateIcons(nil, EMPTY_TABLE)
            end
            -- Sync anchor visibility so NAG.Frame/GroupDisplayFrame hide when we are not updating icons
            if DisplayManager.UpdateFrameVisibility then
                DisplayManager:UpdateFrameVisibility()
            end
            return false
        end

        touchUIElementsGate()

        local StateManager = NAG:GetModule("StateManager")
        if not StateManager then
            self:Error("[UpdateWithVisitor] Early return: StateManager not available")
            return false
        end

        -- Validate StateManager state structure exists
        if not StateManager.state or not StateManager.state.next then
            self:Error("[UpdateWithVisitor] Early return: StateManager.state.next not initialized")
            return false
        end

        local timeNow = GetTime()
        local gcdProbeSpellId = getGcdProbeSpellId()
        local cdInfo = WoWAPI.GetSpellCooldown(gcdProbeSpellId)
        if not cdInfo then
            self:Error(format("[UpdateWithVisitor] Early return: Failed to get GCD cooldown info for spell %s", tostring(gcdProbeSpellId)))
            StateManager.state.next.nextTime = timeNow + NAG.db.global.inputDelay
            return false
        end

        -- Validate cdInfo fields exist (may be incomplete on some game versions)
        local gcdStart = cdInfo.startTime or 0
        local gcdDuration = cdInfo.duration or 0

        local spell, _, _, _, endTime = UnitCastingInfo("player")
        if not spell then endTime = 0 end
        StateManager.state.next.nextTime = max(timeNow + NAG.db.global.inputDelay, gcdStart + gcdDuration,
            (endTime / 1000))

        -- Clear overlay text for old nextSpell before clearing
        if self.nextSpell then
            self:ClearCastOverlayText(self.nextSpell)
        end

        -- Clear overlay text for all secondary spells before clearing
        if self.secondarySpells and type(self.secondarySpells) == "table" then
            for _, entry in ipairs(self.secondarySpells) do
                self:ClearCastOverlayText(entry.spellId)
            end
        end

        self.nextSpell = nil
        wipe(self.secondarySpells)
        self:Debug("[UpdateWithVisitor] Cleared nextSpell, secondarySpells, and position overrides before execution")

        -- Update sequence displays
        local showGroup = DisplayManager.IsGroupDisplayMode and DisplayManager:IsGroupDisplayMode()
        local showLegacy = DisplayManager.IsLegacyFrameEnabled and DisplayManager:IsLegacyFrameEnabled()
        self:Debug("[UpdateWithVisitor] Display modes: showGroup=%s, showLegacy=%s", tostring(showGroup), tostring(showLegacy))

        -- Update sequence displays with error protection
        local seqSuccess, seqErr = pcall(function()
            NAG:UpdateActiveSequenceDisplay()

            if showGroup and DisplayManager.UpdateSequenceGroupIcons then
                DisplayManager:UpdateSequenceGroupIcons()
            end
        end)

        if not seqSuccess then
            self:Error("Error updating sequence display: %s", tostring(seqErr))
        end

        local APLEvaluationCache = NAG:GetModule("APLEvaluationCache", true)
        -- Check if module exists and cache is enabled (direct db access for hotpath performance)
        if APLEvaluationCache and APLEvaluationCache.db.global.enableCache then
            local cacheIterations = APLEvaluationCache.db.global.cacheIterations or 1
            if cacheIterations == 1 then
                APLEvaluationCache:StartEvaluation(true)
            else
                self.cacheIterationCount = (self.cacheIterationCount or 0) + 1
                local shouldClearCache = (self.cacheIterationCount % cacheIterations == 1)
                APLEvaluationCache:StartEvaluation(shouldClearCache)
            end
        end

        -- Execute rotation using visitor pattern
        local APLExecutor = NAG:GetModule("APLExecutor", true)
        if not APLExecutor then
            NAG:Error("[UpdateWithVisitor] Early return: APLExecutor module not available")
            return false
        end

        -- Access ASTVisitor at runtime to avoid initialization order issues
        local ASTVisitor = ns.ASTVisitor
        if not ASTVisitor then
            NAG:Error("[UpdateWithVisitor] Early return: ASTVisitor not available")
            return false
        end

        self:Debug("[UpdateWithVisitor] About to execute rotation AST")
        local executorVisitor = APLExecutor:CreateExecutionVisitor()

        -- Use ns.pcall for enhanced error reporting (consistent with UpdateWithFunction)
        local success, result = pcall(function()
            ASTVisitor.Walk(executorVisitor, rotationAST, {
                executionContext = {
                    stateManager = StateManager,
                    displayManager = DisplayManager,
                }
            })
        end)

        self:Debug("[UpdateWithVisitor] Rotation execution completed: success=%s, nextSpell=%s, secondarySpells count=%d",
            tostring(success), tostring(self.nextSpell), #self.secondarySpells)

        if not success then
            -- Use ExtractErrorMessage to properly handle both string and enhanced error table formats
            local errorMsg = ExtractErrorMessage(result)

            -- Use DevTools_Dump to inspect the error table if available
            if type(result) == "table" and DevTools_Dump then
                self:Error("Error executing rotation AST: Table error detected. Dumping error table:")
                DevTools_Dump(result, "error")
            end

            -- Always log the error - this is critical for debugging silent failures
            self:Error(format("Error executing rotation AST: %s", errorMsg))

            -- Log enhanced error details if available (for debugging)
            if type(result) == "table" and result.stack then
                self:Debug("Rotation AST error stack trace:\n%s", result.stack)
            end

            -- CRITICAL FIX: Check if error is display-related before clearing cache
            local isDisplayError = errorMsg and (
                strfind(errorMsg, "DisplayManager") or
                strfind(errorMsg, "UpdateIcons") or
                strfind(errorMsg, "UpdateGroupIcons") or
                strfind(errorMsg, "UpdateSequenceGroupIcons") or
                strfind(errorMsg, "SetTexture") or
                strfind(errorMsg, "Show()") or
                strfind(errorMsg, "Hide()") or
                strfind(errorMsg, "ShowOverlay") or
                strfind(errorMsg, "UpdateBorder")
            )

            if not isDisplayError then
                -- Only clear cache for non-display errors
                self:Warn("Clearing cached rotation AST due to error - rotation will attempt to reload on next execution")
                self.cachedRotationAST = nil
            else
                -- Display error - log but preserve cache
                self:Error("Display error in UpdateWithVisitor, preserving cache - this may cause stuck display: %s", errorMsg)
            end
        end

        -- Always end evaluation
        if APLEvaluationCache and APLEvaluationCache.db.global.enableCache then
            APLEvaluationCache:EndEvaluation()
        end

        self:Debug("[UpdateWithVisitor] About to update display: nextSpell=%s, secondarySpells count=%d",
            tostring(self.nextSpell), #self.secondarySpells)

        -- Update display (reuse existing display update code) with error protection
        local displaySuccess, displayErr = pcall(function()
            if showGroup then
                self:Debug("[UpdateWithVisitor] Updating group display")
                local groupIconData = self:GetDisplayGroupIconData()
                self:Debug("[UpdateWithVisitor] Group icon data: MAIN=%d, AOE=%d, COOLDOWNS=%d, INTERRUPTS=%d, DEFENSIVES=%d",
                    #(groupIconData[ns.FRAME_GROUPS.MAIN] or {}),
                    #(groupIconData[ns.FRAME_GROUPS.AOE] or {}),
                    #(groupIconData[ns.FRAME_GROUPS.COOLDOWNS] or {}),
                    #(groupIconData[ns.FRAME_GROUPS.INTERRUPTS] or {}),
                    #(groupIconData[ns.FRAME_GROUPS.DEFENSIVES] or {}))
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.AOE, groupIconData[ns.FRAME_GROUPS.AOE])
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.COOLDOWNS, groupIconData[ns.FRAME_GROUPS.COOLDOWNS])
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.INTERRUPTS, groupIconData[ns.FRAME_GROUPS.INTERRUPTS])
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.DEFENSIVES, groupIconData[ns.FRAME_GROUPS.DEFENSIVES])
            end
            if showLegacy then
                self:Debug("[UpdateWithVisitor] Updating legacy display: nextSpell=%s", tostring(self.nextSpell))
                DisplayManager:UpdateIcons(self.nextSpell, self.secondarySpells)
            end
        end)

        if not displaySuccess then
            self:Error("[UpdateWithVisitor] Critical error updating display icons - display may become stuck: %s", tostring(displayErr))
        end

        -- Prediction queue integration (reuse existing code)
        local predictionSettings = NAG.db.char.predictionQueue
        local RotationManager = NAG:GetModule("RotationManager")

        self:Debug("[UpdateWithVisitor] Prediction queue: RotationManager=%s, predictionSettings=%s, IsGroupDisplayMode=%s",
            tostring(RotationManager ~= nil), tostring(predictionSettings ~= nil), tostring(DisplayManager:IsGroupDisplayMode()))

        -- Skip prediction queue if RotationManager not available
        if not RotationManager then
            self:Debug("[UpdateWithVisitor] Returning early: RotationManager not available (skipping prediction queue)")
            return true  -- Rotation executed successfully, just skipping prediction queue
        end

        -- Update prediction queue with error protection
        local predSuccess, predErr = pcall(function()
            if DisplayManager:IsGroupDisplayMode() then
                self:Debug("[UpdateWithVisitor] Updating MAIN group with predictions")
                if predictionSettings and predictionSettings.enabled then
                    local numPredictions = predictionSettings.numPredictions or 3
                    local predictions = RotationManager:GeneratePredictionQueue(numPredictions)
                    if predictions and #predictions > 0 then
                        if DisplayManager:IsLegacyFrameEnabled() then
                            DisplayManager:UpdatePredictionQueue(predictions)
                        end
                        DisplayManager:UpdateMainGroupWithPredictions(NAG.nextSpell, predictions)
                    else
                        if DisplayManager:IsLegacyFrameEnabled() then
                            DisplayManager:HidePredictionQueue()
                        end
                        DisplayManager:UpdateMainGroupWithPredictions(NAG.nextSpell, nil)
                    end
                else
                    self:Debug("[UpdateWithVisitor] Predictions disabled, updating MAIN group with current spell only: nextSpell=%s", tostring(NAG.nextSpell))
                    DisplayManager:UpdateMainGroupWithPredictions(NAG.nextSpell, nil)
                end
            elseif DisplayManager:IsLegacyFrameEnabled() then
                self:Debug("[UpdateWithVisitor] Legacy frame enabled, updating prediction queue")
                if predictionSettings and predictionSettings.enabled then
                    local numPredictions = predictionSettings.numPredictions or 3
                    local predictions = RotationManager:GeneratePredictionQueue(numPredictions)
                    if predictions and #predictions > 0 then
                        DisplayManager:UpdatePredictionQueue(predictions)
                    else
                        DisplayManager:HidePredictionQueue()
                    end
                end
            end
        end)

        if not predSuccess then
            self:Error("[UpdateWithVisitor] Critical error updating prediction queue - MAIN group display may become stuck: %s", tostring(predErr))
        end

        self:Debug("[UpdateWithVisitor] Execution completed successfully, returning true")
        return true  -- Rotation executed successfully
    end

    --- Updates rotation using function-based execution (legacy/TBC)
    --- @param self NAG The NAG addon object
    --- @param rotation function The rotation function that determines the next spell
    --- @return boolean Returns true if rotation executed successfully, false if early return
    function NAG:UpdateWithFunction(rotation)
        -- Safety check: ensure rotation is a valid function
        if not rotation or type(rotation) ~= "function" then
            self:Error("UpdateWithFunction: Invalid rotation parameter - expected function, got %s - display may become stuck", type(rotation))
            self.cachedRotationFunc = nil
            return false
        end

        -- Pause updates if options are open
        if AceConfigDialog and AceConfigDialog.OpenFrames and AceConfigDialog.OpenFrames["NAG"] then
            return false
        end
        if self.isLoadScreenRecent then
            self:Debug("UpdateWithFunction: Early return - load screen is recent")
            return false
        end
        --if PullTimer:GetTimeToZero() then return end
        local chk = ns.check()
        local DisplayManager = NAG:GetModule("DisplayManager")
        if not DisplayManager then
            -- CRITICAL: DisplayManager missing would cause errors on all DisplayManager calls
            self:Error(format("UpdateWithFunction: CRITICAL - DisplayManager module not available - rotation execution will fail and display may become stuck"))
            return false
        end
        local shouldShowDisplayResult = DisplayManager:ShouldShowDisplay()
        local shouldReturn = not chk or not shouldShowDisplayResult

        if shouldReturn then
            -- Log why we're returning early (for debugging rotation stops)
            if not chk then
                self:Debug("UpdateWithFunction: Early return - check() returned false (may indicate combat/invalid state)")
            elseif not shouldShowDisplayResult then
                self:Debug("UpdateWithFunction: Early return - ShouldShowDisplay() returned false (display hidden/disabled)")
            end

            local showGroup = DisplayManager.IsGroupDisplayMode and DisplayManager:IsGroupDisplayMode()
            local showLegacy = DisplayManager.IsLegacyFrameEnabled and DisplayManager:IsLegacyFrameEnabled()
            if showGroup then
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.MAIN, EMPTY_TABLE)
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.AOE, EMPTY_TABLE)
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.COOLDOWNS, EMPTY_TABLE)
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.INTERRUPTS, EMPTY_TABLE)
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.DEFENSIVES, EMPTY_TABLE)
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.SEQUENCE, EMPTY_TABLE)
            end
            if showLegacy then
                DisplayManager:UpdateIcons(nil, EMPTY_TABLE)
            end
            -- Sync anchor visibility so NAG.Frame/GroupDisplayFrame hide when we are not updating icons
            if DisplayManager.UpdateFrameVisibility then
                DisplayManager:UpdateFrameVisibility()
            end
            return false
        end

        touchUIElementsGate()

        local StateManager = NAG:GetModule("StateManager")
        if not StateManager then
            -- CRITICAL: StateManager missing would cause errors on state access
            self:Error(format("UpdateWithFunction: CRITICAL - StateManager module not available - rotation execution will fail and display may become stuck"))
            return false
        end
        if not StateManager.state or not StateManager.state.next then
            -- CRITICAL: State structure missing would cause errors on state.next access
            self:Error(format("UpdateWithFunction: CRITICAL - StateManager.state.next not initialized - rotation execution will fail and display may become stuck"))
            return false
        end
        local timeNow = GetTime()
        local gcdProbeSpellId = getGcdProbeSpellId()
        local cdInfo = WoWAPI.GetSpellCooldown(gcdProbeSpellId)
        if not cdInfo then
            self:Error(format("Critical: Failed to get GCD cooldown info for spell %s", tostring(gcdProbeSpellId)))
            -- Fallback to basic timing
            StateManager.state.next.nextTime = timeNow + NAG.db.global.inputDelay
            return false
        end

        -- CRITICAL: Validate cdInfo structure to prevent nil access errors
        local gcdStart = cdInfo.startTime or 0
        local gcdDuration = cdInfo.duration or 0

        local spell, _, _, _, endTime = UnitCastingInfo("player")
        if not spell then endTime = 0 end
        -- Get input delay setting with direct database access
        StateManager.state.next.nextTime = max(timeNow + NAG.db.global.inputDelay, gcdStart + gcdDuration,
            (endTime / 1000))

        self.nextSpell = nil
        --self.secondarySpells = {}
        wipe(self.secondarySpells)

        -- Update sequence displays based on active display system(s)
        -- NOTE: Sequences are updated separately from the main group icon update cycle
        -- because they use NAG.RightSlots.sequence data directly (from APLSequences.lua)
        -- rather than going through GetDisplayGroupIconData() mapping
        local showGroup = DisplayManager.IsGroupDisplayMode and DisplayManager:IsGroupDisplayMode()
        local showLegacy = DisplayManager.IsLegacyFrameEnabled and DisplayManager:IsLegacyFrameEnabled()

        -- Update sequence displays with error protection
        local seqSuccess, seqErr = pcall(function()
            NAG:UpdateActiveSequenceDisplay()

            -- UpdateSequenceGroupIcons is only used by group system
            if showGroup and DisplayManager.UpdateSequenceGroupIcons then
                DisplayManager:UpdateSequenceGroupIcons()
            end
        end)

        if not seqSuccess then
            self:Error("Error updating sequence display: %s", tostring(seqErr))
        end
        local APLEvaluationCache = NAG:GetModule("APLEvaluationCache", true)
        -- APL evaluation cache (function-based path; direct db access for hotpath performance)
        if APLEvaluationCache and APLEvaluationCache.db.global.enableCache then
            local cacheIterations = APLEvaluationCache.db.global.cacheIterations or 1

            -- CRITICAL: Wrap StartEvaluation in pcall to prevent errors from breaking rotation execution
            local cacheStartSuccess, cacheStartErr = pcall(function()
                if cacheIterations == 1 then
                    -- Fast path: clear every iteration (no tracking overhead)
                    APLEvaluationCache:StartEvaluation(true)
                else
                    -- Multi-iteration caching: track and cycle
                    self.cacheIterationCount = (self.cacheIterationCount or 0) + 1
                    local shouldClearCache = (self.cacheIterationCount % cacheIterations == 1)
                    APLEvaluationCache:StartEvaluation(shouldClearCache)
                end
            end)
            if not cacheStartSuccess then
                self:Error(format("UpdateWithFunction: CRITICAL - APLEvaluationCache:StartEvaluation() failed: %s - rotation execution may be affected", tostring(cacheStartErr)))
            end
        end

        -- Execute rotation with error handling
        local success, foundSpell = pcall(rotation)
        if not success then
            -- Use ExtractErrorMessage to properly handle both string and enhanced error table formats
            local errorMsg = ExtractErrorMessage(foundSpell)
            -- Always log the error - this is critical for debugging silent failures
            self:Error(format("Error executing rotation: %s", errorMsg))

            -- Log enhanced error details if available (for debugging)
            if type(foundSpell) == "table" and foundSpell.stack then
                self:Debug("Rotation error stack trace:\n%s", foundSpell.stack)
            end

            -- CRITICAL FIX: Check if error is display-related before clearing cache
            local isDisplayError = errorMsg and (
                strfind(errorMsg, "DisplayManager") or
                strfind(errorMsg, "UpdateIcons") or
                strfind(errorMsg, "UpdateGroupIcons") or
                strfind(errorMsg, "UpdateSequenceGroupIcons") or
                strfind(errorMsg, "SetTexture") or
                strfind(errorMsg, "Show()") or
                strfind(errorMsg, "Hide()") or
                strfind(errorMsg, "ShowOverlay") or
                strfind(errorMsg, "UpdateBorder")
            )

            if not isDisplayError then
                -- Only clear cache for non-display errors
                self:Warn("Clearing cached rotation function due to error - rotation will attempt to reload on next execution")
                self.cachedRotationFunc = nil
            else
                -- Display error - log but preserve cache
                self:Error("Display error in UpdateWithFunction, preserving cache - this may cause stuck display: %s", errorMsg)
            end
        end

        -- Always end evaluation (but cache persists unless cycling)
        if APLEvaluationCache and APLEvaluationCache.db.global.enableCache then
            -- CRITICAL: Wrap EndEvaluation in pcall to prevent errors from breaking rotation execution
            local cacheEndSuccess, cacheEndErr = pcall(function()
                APLEvaluationCache:EndEvaluation()
            end)
            if not cacheEndSuccess then
                self:Error(format("UpdateWithFunction: CRITICAL - APLEvaluationCache:EndEvaluation() failed: %s - rotation execution may be affected", tostring(cacheEndErr)))
            end
        end

        -- Update display icons with error protection
        local displaySuccess, displayErr = pcall(function()
            if showGroup then
                local groupIconData = self:GetDisplayGroupIconData()
                -- MAIN group is handled separately below with predictions integration
                -- DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.MAIN, groupIconData[ns.FRAME_GROUPS.MAIN])
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.AOE, groupIconData[ns.FRAME_GROUPS.AOE])
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.COOLDOWNS, groupIconData[ns.FRAME_GROUPS.COOLDOWNS])
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.INTERRUPTS, groupIconData[ns.FRAME_GROUPS.INTERRUPTS])
                DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.DEFENSIVES, groupIconData[ns.FRAME_GROUPS.DEFENSIVES])

                -- NOTE: SEQUENCE group is updated separately by UpdateSequenceGroupIcons() above
                -- Do NOT call UpdateGroupIcons for SEQUENCE group as it will clear sequence icons
                -- DisplayManager:UpdateGroupIcons(ns.FRAME_GROUPS.SEQUENCE, groupIconData[ns.FRAME_GROUPS.SEQUENCE])
            end
            if showLegacy then
                DisplayManager:UpdateIcons(self.nextSpell, self.secondarySpells)
            end
        end)

        if not displaySuccess then
            -- CRITICAL: Display update pcall failure causes permanent freeze
            self:Error(format("UpdateWithFunction: Critical error updating display icons - display may become stuck: %s (nextSpell=%s, secondarySpells count=%d)",
                tostring(displayErr), tostring(self.nextSpell), #self.secondarySpells))
        elseif success and not showGroup and not showLegacy then
            -- CRITICAL: Rotation executed but UpdateIcons() was never called (would cause permanent freeze)
            self:Error(format("UpdateWithFunction: Rotation executed successfully but UpdateIcons() was not called - display may become stuck (showGroup=%s, showLegacy=%s, nextSpell=%s, secondarySpells count=%d)",
                tostring(showGroup), tostring(showLegacy), tostring(self.nextSpell), #self.secondarySpells))
        end

        -- ============================ PREDICTION QUEUE SYSTEM INTEGRATION ============================
        -- Update prediction queue and GroupDisplay main container
        local predictionSettings = NAG.db.char.predictionQueue
        local RotationManager = NAG:GetModule("RotationManager")

        -- Skip prediction queue if RotationManager not available
        if not RotationManager then
            self:Debug("UpdateWithFunction: RotationManager not available - skipping prediction queue (rotation executed successfully)")
            return true  -- Rotation executed successfully, just skipping prediction queue
        end

        -- Update prediction queue with error protection
        local predSuccess, predErr = pcall(function()
            if DisplayManager:IsGroupDisplayMode() then
                -- Always update MAIN group: with predictions if enabled, or just current spell if disabled
                if predictionSettings and predictionSettings.enabled then
                    -- Generate prediction queue
                    local numPredictions = predictionSettings.numPredictions or 3
                    local predictions = RotationManager:GeneratePredictionQueue(numPredictions)

                    -- Update prediction queue display
                    if predictions and #predictions > 0 then
                        -- Update standalone prediction queue frames only if legacy display is enabled
                        if DisplayManager:IsLegacyFrameEnabled() then
                            DisplayManager:UpdatePredictionQueue(predictions)
                        end
                        -- Update GroupDisplay main container with predictions
                        DisplayManager:UpdateMainGroupWithPredictions(NAG.nextSpell, predictions)
                    else
                        -- Hide standalone prediction queue frames only if legacy display is enabled
                        if DisplayManager:IsLegacyFrameEnabled() then
                            DisplayManager:HidePredictionQueue()
                        end
                        -- Still show current spell in main group frame 1
                        DisplayManager:UpdateMainGroupWithPredictions(NAG.nextSpell, nil)
                    end
                else
                    -- Predictions disabled: show current spell only
                    DisplayManager:UpdateMainGroupWithPredictions(NAG.nextSpell, nil)
                end
            elseif DisplayManager:IsLegacyFrameEnabled() then
                -- Legacy-only: update standalone prediction queue if enabled
                if predictionSettings and predictionSettings.enabled then
                    local numPredictions = predictionSettings.numPredictions or 3
                    local predictions = RotationManager:GeneratePredictionQueue(numPredictions)
                    if predictions and #predictions > 0 then
                        DisplayManager:UpdatePredictionQueue(predictions)
                    else
                        DisplayManager:HidePredictionQueue()
                    end
                end
            end
        end)

        if not predSuccess then
            self:Error("UpdateWithFunction: Critical error updating prediction queue - MAIN group display may become stuck: %s", tostring(predErr))
        end

        return true  -- Rotation executed successfully
    end
end

function NAG:HasGlyph(glyphId)
    local StateManager = NAG:GetModule("StateManager")
    if not glyphId or not _G.GetNumGlyphSockets then return false end

    return StateManager:HasGlyph(glyphId)
end

function NAG:HasPrimeGlyph(glyphId)
    if not glyphId or not _G.GetNumGlyphSockets then return false end

    -- Check prime glyph slots (type 0)
    for i = 1, GetNumGlyphSockets() do
        local enabled, glyphType, _, glyphSpellId = GetGlyphSocketInfo(i)
        if enabled and glyphType == 3 and glyphSpellId == glyphId then
            return true
        end
    end

    return false
end

function NAG:HasMajorGlyph(glyphId)
    if not glyphId or not _G.GetNumGlyphSockets then return false end

    -- Check major glyph slots (type 1)
    for i = 1, GetNumGlyphSockets() do
        local enabled, glyphType, _, glyphSpellId = GetGlyphSocketInfo(i)
        if enabled and glyphType == 1 and glyphSpellId == glyphId then
            return true
        end
    end

    return false
end

function NAG:HasMinorGlyph(glyphId)
    if not glyphId or not _G.GetNumGlyphSockets then return false end

    -- Check minor glyph slots (type 2)
    for i = 1, GetNumGlyphSockets() do
        local enabled, glyphType, _, glyphSpellId = GetGlyphSocketInfo(i)
        if enabled and glyphType == 2 and glyphSpellId == glyphId then
            return true
        end
    end

    return false
end

local CACHED_GROUP_ICON_DATA = {
    [ns.FRAME_GROUPS.MAIN] = {},
    [ns.FRAME_GROUPS.AOE] = {},
    [ns.FRAME_GROUPS.COOLDOWNS] = {},
    [ns.FRAME_GROUPS.INTERRUPTS] = {},
    [ns.FRAME_GROUPS.DEFENSIVES] = {},
    [ns.FRAME_GROUPS.SEQUENCE] = {},
}
local CACHED_INSERT_TO_GROUP_FUNC

--- Resolve an icon + classify whether the id should be treated as an item.
--- This is used by GroupDisplay mode which does not use DisplayManager's legacy GetCachedEntity() path.
--- @param id number
--- @param dataManager DataManager|nil
--- @return number|nil texture
--- @return boolean isItem
local function ResolveGroupDisplayIcon(id, dataManager)
    if not id then
        return nil, false
    end

    local entity = nil
    if dataManager then
        entity = dataManager:Get(id, dataManager.EntityTypes.SPELL) or dataManager:Get(id, dataManager.EntityTypes.ITEM)
    end

    local treatAsItem = (entity and entity.IsItem) == true

    -- Hardcoded Synapse Springs fix (legacy behavior parity):
    -- Paladin MoP Ret had collisions where glove item ID (87100) must be treated as an item for icon/cooldown resolution.
    if not treatAsItem and id == 87100 then
        local _, playerClass = _G.UnitClass("player")
        if playerClass == "PALADIN" then
            treatAsItem = true
        end
    end

    if entity and entity.icon then
        return entity.icon, treatAsItem
    end

    -- Fallback: if WoW recognizes it as an item, use item icon; else spell texture.
    if treatAsItem or (WoWAPI.GetItemInfo(id) ~= nil) then
        local icon = GetItemIcon(id)
        if icon then
            return icon, true
        end
    end

    local texture = GetSpellTexture(id)
    if texture then
        return texture, false
    end

    -- Last resort: try both (covers odd IDs used by CastPlaceholder / legacy tinker wiring).
    local icon = GetItemIcon(id)
    if icon then
        return icon, true
    end

    return nil, treatAsItem
end

function NAG:GetDisplayGroupIconData()
    for _, groupTable in pairs(CACHED_GROUP_ICON_DATA) do
        wipe(groupTable)
    end

    -- Reset icon data pool index
    iconDataPoolIndex = 0

    -- Create cached insert function if not exists
    if not CACHED_INSERT_TO_GROUP_FUNC then
        CACHED_INSERT_TO_GROUP_FUNC = function(groupKey, icon)
            if CACHED_GROUP_ICON_DATA[groupKey] then
                table.insert(CACHED_GROUP_ICON_DATA[groupKey], icon)
            end
        end
    end

    -- Main: nextSpell (PRIMARY position → main group)
    if self.nextSpell then
        local DataManager = NAG:GetModule("DataManager")
        local texture, isItem = ResolveGroupDisplayIcon(self.nextSpell, DataManager)
        local iconData = getNextIconData()
        iconData.texture = texture
        if isItem then
            iconData.itemId = self.nextSpell
        else
            iconData.spellId = self.nextSpell
        end
        CACHED_INSERT_TO_GROUP_FUNC(ns.FRAME_GROUPS.MAIN, iconData)
    end

    -- Secondary spells: use SpellbookManager for position determination (consolidated from CacheManager)
    if self.secondarySpells and type(self.secondarySpells) == "table" then
        local DataManager = NAG:GetModule("DataManager")
        local SpellbookManager = NAG:GetModule("SpellbookManager")
        local DisplayManager = NAG:GetModule("DisplayManager")
        for _, entry in ipairs(self.secondarySpells) do
            local id = entry.spellId
            local icon, isItem = ResolveGroupDisplayIcon(id, DataManager)

            local iconData = getNextIconData()
            iconData.texture = icon
            if isItem then
                iconData.itemId = id
            else
                iconData.spellId = id
            end
            local effectivePosition = SpellbookManager:GetSpellPosition(id)

            -- Use standardized position constants (no string manipulation needed)
            local spellPosition = effectivePosition or ns.SPELL_POSITIONS.PRIMARY

            -- Use configurable mapping from DisplayManager instead of hardcoded logic
            local targetGroup = DisplayManager:PositionToGroup(spellPosition)
            CACHED_INSERT_TO_GROUP_FUNC(targetGroup, iconData)
        end
    end

    return CACHED_GROUP_ICON_DATA
end

--- Ensures the UI is ready for display
--- @param self NAG
function NAG:EnsureUIIsReady()
    local DisplayManager = NAG:GetModule("DisplayManager")
    --TODO add new frame support GroupFrame
    if not self.Frame.iconFrames then
        self:Info("Frame not initialized, initializing...")
        DisplayManager:InitializeParentFrame()
    end
end
